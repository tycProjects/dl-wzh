# NOVA DOWNLOAD

A mobile-first, ad-free PWA starter for recognizing social links, opening original posts, organizing link history, and previewing local media.

## Important capability and platform limits

NOVA recognizes links from TikTok, YouTube, Instagram, Facebook, X, Pinterest, Reddit, Threads, Snapchat, Likee, Vimeo, and Dailymotion. Recognition is not the same as permission or technical ability to download a hosted post.

This version intentionally does **not** scrape social sites, bypass private-account controls, remove DRM, circumvent paywalls, or download platform-hosted posts through unofficial extraction. Those methods can violate platform terms, copyright, or privacy. For social posts, NOVA opens the original post. For direct media URLs (for example, a public `.mp4` or `.mp3` URL), it offers the browser's normal open/save behavior; the host may restrict downloads or cross-origin access.

The project has no advertisements, tracking SDK, analytics, or account requirement. The only external request in the stylesheet is Google Fonts; remove the `@import` line for a fully offline/self-contained font setup. The app itself remains usable without that font.

## Run locally

Requirements: Node.js 18+ (or any static web server).

```bash
npm start
```

Open `http://localhost:8080`.

You can also open `index.html` directly, but PWA installation and service workers require HTTPS or localhost.

## Deploy online

Deploy the folder to any static host that supports HTTPS (Netlify, Cloudflare Pages, GitHub Pages, etc.). For Netlify, the included `_redirects` file is not required for this static app. Set the publish directory to the project root.

For the optional Node server, use a host that supports Node.js and run `npm start`.

## Install on Android

1. Deploy to an HTTPS URL.
2. Open the URL in Chrome on Android.
3. Open the browser menu and choose **Install app** or **Add to Home screen**.
4. Launch NOVA from the home screen.

## Features in this build

- Premium dark bubble UI with light-mode toggle
- Responsive mobile layout and bottom navigation
- Social platform URL recognition
- Safe URL validation (HTTP/HTTPS only)
- Open original social post
- Direct media URL open/save link
- Copy link action
- Local link history with clear-history control
- Local image/video/audio file import and preview
- PWA manifest, service worker, offline app shell
- Ad-free; no telemetry or account setup

## Suggested next integration phase

For legitimate online integrations, register for each platform's official developer program and use its approved API / embed flow. Add only the permissions and scopes needed. Platform APIs often provide metadata or embeds rather than downloadable original media. For files hosted by your own service, add an authenticated upload/storage API and issue short-lived download URLs. Do not expose private API keys in `app.js`; keep secrets on a trusted backend.

## Project structure

```text
NOVA-DOWNLOAD/
  index.html
  style.css
  app.js
  manifest.webmanifest
  sw.js
  server.js
  package.json
  assets/
    icon.svg
```
