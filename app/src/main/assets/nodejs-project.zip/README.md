# MyHostingMC (Phase 1)

Minecraft Java Edition hosting platform. Phase 1 = foundation: accounts, dashboard UI, database, server records.
It does NOT start or run Minecraft servers yet.

## Requirements
- Node.js 18+ (LTS recommended). Java is not needed until Phase 2.

## Install
    npm install
    cp .env.example .env        # Windows: copy .env.example .env
    node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
Paste the output into `JWT_SECRET=` in `.env`.

## Run
    npm start          # or: npm run dev (auto-restart)
Open http://localhost:3000

## Structure
    backend/   Express API, SQLite, auth (serves the frontend too)
    frontend/  Static HTML/CSS/JS
    data/      SQLite file (created on first run, git-ignored)
