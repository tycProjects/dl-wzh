# Nova WhatsApp Bot — Starter ZIP

A starter project with a premium pairing page and a small WhatsApp command bot.

## Requirements
- Node.js 20+
- A phone and WhatsApp account that you own or are authorized to manage
- A local server or trusted host

## Run locally
1. Extract the ZIP.
2. Open a terminal in this folder.
3. Run `npm install`
4. Run `npm start`
5. Open `http://localhost:3000`

## Pair your own account
- Select a service and enter your number in international format (digits only).
- Confirm the consent checkbox.
- Generate the pairing code.
- On your own WhatsApp: Linked devices → Link a device → Link with phone number.
- Enter the code before it expires.

## Starter commands
Send these messages to the linked bot account from another chat:
- `.menu` or `.help`
- `.ping`
- `.about`
- `.privacy`

The starter currently provides a basic command handler. Music/video search and media features are intentionally marked as coming soon; add them only with lawful sources, respect platform terms and copyright, and avoid collecting other people's login codes or sessions.

## Important security and platform notes
- This uses the unofficial Baileys WhatsApp Web library, not the official WhatsApp Business Cloud API. WhatsApp may change compatibility or restrict accounts using unofficial automation.
- Linking grants the server access to the linked WhatsApp session. Only link your own account after reading and understanding this.
- Session credentials are stored under `sessions/`. Never publish, share, or upload this folder. Protect server backups and restrict filesystem access.
- This is a development starter, **not production-ready**. Before public hosting, add HTTPS, authentication, CAPTCHA/abuse controls, persistent rate limiting, per-user authorization, monitoring, secure session encryption, and a verified disconnect/account deletion flow.
- The current pairing endpoint is a demo and does not include identity verification beyond the user's explicit consent and WhatsApp's own pairing confirmation. Do not expose it publicly as-is.
- Never ask users to send you their WhatsApp OTP, password, or pairing code. The code should be entered only in their own WhatsApp app.
- WhatsApp commands appear in chats with the bot account; they do not automatically appear in the WhatsApp profile's three-dot menu.

## Project layout
- `server.js` — Express API and WhatsApp session/command handler
- `public/` — premium pairing page
- `sessions/` — local session files (private; do not share)
