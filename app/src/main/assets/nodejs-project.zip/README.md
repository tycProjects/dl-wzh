# Online server
Run `npm install` then `npm start`. Exposes HTTP `/health` and WebSocket `/match`. Production deployment should use TLS/WSS, authentication tokens, authoritative match simulation, rate limits and regional matchmaking.
