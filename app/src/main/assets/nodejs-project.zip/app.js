const $ = (s) => document.querySelector(s);
const linkInput = $("#linkInput");
const resultSection = $("#resultSection");
const resultCard = $("#resultCard");
const historyKey = "nova-download-history-v1";
let toastTimer;
const platforms = [
  ["TikTok", /tiktok\.com/i, "♪"], ["YouTube", /youtube\.com|youtu\.be/i, "▶"],
  ["Instagram", /instagram\.com/i, "◎"], ["Facebook", /facebook\.com|fb\.watch/i, "f"],
  ["X", /(^|\.)x\.com|twitter\.com/i, "𝕏"], ["Pinterest", /pinterest\./i, "P"],
  ["Reddit", /reddit\.com|redd\.it/i, "▣"], ["Threads", /threads\.net/i, "@"],
  ["Snapchat", /snapchat\.com/i, "◉"], ["Likee", /likee\.video/i, "♡"],
  ["Vimeo", /vimeo\.com/i, "V"], ["Dailymotion", /dailymotion\.com/i, "D"]
];
function toast(message){const el=$("#toast");el.textContent=message;el.classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove("show"),2600)}
function validUrl(raw){try{const u=new URL(raw);return ["https:","http:"].includes(u.protocol)?u:null}catch{return null}}
function detect(url){return platforms.find(p=>p[1].test(url.hostname))||null}
function directMedia(url){return /\.(mp4|webm|mov|m4v|mp3|m4a|wav|ogg|jpg|jpeg|png|gif|webp)(\?.*)?$/i.test(url.href)}
function getHistory(){try{return JSON.parse(localStorage.getItem(historyKey)||"[]")}catch{return []}}
function saveHistory(item){const list=getHistory().filter(x=>x.url!==item.url);list.unshift(item);localStorage.setItem(historyKey,JSON.stringify(list.slice(0,60)));renderHistory()}
function safeText(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function renderResult(url,platform){
  const direct=directMedia(url), name=platform?platform[0]:"Direct media link";
  resultSection.classList.remove("hidden");
  resultCard.innerHTML=`<div class="result-icon">${platform?platform[2]:"⇩"}</div><div class="result-main"><b>${safeText(name)} ${direct?"· Direct file":"· Social link"}</b><p>${safeText(url.href)}</p><div class="result-actions"><a class="small-action primary" href="${safeText(url.href)}" target="_blank" rel="noopener noreferrer">${direct?"Open media file":"Open original post"} ↗</a><button class="small-action" id="copyLink">Copy link</button>${direct?'<a class="small-action" href="'+safeText(url.href)+'" download>Save file ↓</a>':""}</div><p>${direct?"If your browser permits it, use Save file. Some hosts may open the media instead of downloading it.":"This platform link is recognized. NOVA can open the original post; it cannot extract or bypass platform-controlled media delivery."}</p></div>`;
  $("#copyLink").addEventListener("click",async()=>{try{await navigator.clipboard.writeText(url.href);toast("Link copied")}catch{toast("Copy isn't available in this browser")}});
}
$("#linkForm").addEventListener("submit",e=>{e.preventDefault();const url=validUrl(linkInput.value.trim());if(!url){toast("Please enter a valid http or https link.");return}const p=detect(url);renderResult(url,p);saveHistory({url:url.href,platform:p?p[0]:"Direct link",date:new Date().toISOString()});resultSection.scrollIntoView({behavior:"smooth",block:"nearest"});});
$("#pasteBtn").addEventListener("click",async()=>{try{linkInput.value=await navigator.clipboard.readText();linkInput.focus();toast("Pasted from clipboard")}catch{linkInput.focus();toast("Tap and hold the field to paste")}});
$("#clearResult").addEventListener("click",()=>{resultSection.classList.add("hidden");linkInput.value=""});
function renderHistory(){const list=getHistory(),host=$("#historyList");if(!list.length){host.innerHTML='<div class="empty-state"><span>◌</span><b>Nothing here yet</b><small>Your recent link activity will appear here.</small></div>';return}host.innerHTML=list.map(x=>`<div class="history-row"><div class="row-icon">↗</div><div class="row-copy"><b>${safeText(x.platform)}</b><small>${safeText(x.url)}</small></div><button class="text-btn" data-open="${encodeURIComponent(x.url)}">OPEN</button></div>`).join("");host.querySelectorAll("[data-open]").forEach(b=>b.addEventListener("click",()=>window.open(decodeURIComponent(b.dataset.open),"_blank","noopener,noreferrer")))}
$("#clearHistory").addEventListener("click",()=>{localStorage.removeItem(historyKey);renderHistory();toast("History cleared")});
function showView(view){$("#downloadsView").classList.toggle("hidden",view!=="downloads");$("#toolsView").classList.toggle("hidden",view!=="tools");document.querySelectorAll(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.nav===view));if(view!=="home")document.querySelector("#"+(view==="downloads"?"downloadsView":"toolsView")).scrollIntoView({behavior:"smooth",block:"start"});else window.scrollTo({top:0,behavior:"smooth"})}
document.querySelectorAll("[data-view]").forEach(b=>b.addEventListener("click",()=>showView(b.dataset.view)));
document.querySelectorAll("[data-nav]").forEach(b=>b.addEventListener("click",()=>showView(b.dataset.nav)));
$("#themeBtn").addEventListener("click",()=>{document.body.classList.toggle("light");localStorage.setItem("nova-theme",document.body.classList.contains("light")?"light":"dark")});
if(localStorage.getItem("nova-theme")==="light")document.body.classList.add("light");
$("#filePicker").addEventListener("change",e=>{const host=$("#localFiles");host.innerHTML="";[...e.target.files].forEach(file=>{const url=URL.createObjectURL(file),card=document.createElement("div");card.className="local-file";let media;if(file.type.startsWith("image/")){media=document.createElement("img");media.src=url}else if(file.type.startsWith("video/")){media=document.createElement("video");media.src=url;media.controls=true}else{media=document.createElement("div");media.textContent="♫";media.style.cssText="height:85px;display:grid;place-items:center;font-size:30px"}const name=document.createElement("span");name.textContent=file.name;card.append(media,name);host.append(card)})});
renderHistory();
if("serviceWorker" in navigator && location.protocol.startsWith("http"))window.addEventListener("load",()=>navigator.serviceWorker.register("/sw.js").catch(()=>{}));
