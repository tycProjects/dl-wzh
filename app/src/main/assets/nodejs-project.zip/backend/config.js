const path = require('path');
const root = path.join(__dirname, '..');
require('dotenv').config({ path: path.join(root, '.env') });

const secret = process.env.JWT_SECRET;
if (!secret || secret.length < 32) {
  console.error('JWT_SECRET is missing or shorter than 32 characters. Set it in .env (see .env.example).');
  process.exit(1);
}

module.exports = {
  port: Number(process.env.PORT) || 3000,
  isProd: process.env.NODE_ENV === 'production',
  jwtSecret: secret,
  jwtExpiresIn: '7d',
  cookieMaxAgeMs: 7 * 24 * 60 * 60 * 1000,
  dbPath: path.resolve(root, process.env.DB_PATH || './data/myhostingmc.db'),
  bcryptRounds: 12,
  maxServersPerUser: Number(process.env.MAX_SERVERS_PER_USER) || 3,
};
