const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');
const config = require('../config');

fs.mkdirSync(path.dirname(config.dbPath), { recursive: true });

const db = new Database(config.dbPath);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    username      TEXT NOT NULL UNIQUE COLLATE NOCASE,
    email         TEXT NOT NULL UNIQUE COLLATE NOCASE,
    password_hash TEXT NOT NULL,
    created_at    TEXT NOT NULL DEFAULT (datetime('now'))
  );

  -- A row here is a server *record*. Phase 1 never starts a Minecraft process,
  -- so status stays 'not_provisioned'. The other values are reserved for later phases.
  CREATE TABLE IF NOT EXISTS servers (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name         TEXT NOT NULL,
    server_type  TEXT NOT NULL CHECK (server_type IN ('vanilla','paper','fabric','forge')),
    mc_version   TEXT NOT NULL,
    ram_mb       INTEGER NOT NULL CHECK (ram_mb BETWEEN 512 AND 16384),
    port         INTEGER UNIQUE,
    status       TEXT NOT NULL DEFAULT 'not_provisioned'
                 CHECK (status IN ('not_provisioned','offline','starting','running','stopping','error')),
    created_at   TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE (user_id, name)
  );
  CREATE INDEX IF NOT EXISTS idx_servers_user ON servers(user_id);
`);

module.exports = db;
