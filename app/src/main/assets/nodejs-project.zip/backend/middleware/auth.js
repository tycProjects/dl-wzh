const jwt = require('jsonwebtoken');
const config = require('../config');
const db = require('../db/database');

const findUser = db.prepare('SELECT id, username, email, created_at FROM users WHERE id = ?');

function requireAuth(req, res, next) {
  const token = req.cookies && req.cookies.token;
  if (!token) return res.status(401).json({ error: 'Not authenticated.' });
  try {
    const payload = jwt.verify(token, config.jwtSecret, { algorithms: ['HS256'] });
    const user = findUser.get(payload.sub);
    if (!user) return res.status(401).json({ error: 'Not authenticated.' });
    req.user = user;
    next();
  } catch {
    res.status(401).json({ error: 'Not authenticated.' });
  }
}

module.exports = { requireAuth };
