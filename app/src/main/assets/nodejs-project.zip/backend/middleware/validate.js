// Small, dependency-free validators. Each returns { value } or { error }.
const SERVER_TYPES = ['vanilla', 'paper', 'fabric', 'forge'];

function isObject(b) { return b && typeof b === 'object' && !Array.isArray(b); }

function validateRegistration(body) {
  if (!isObject(body)) return { error: 'Invalid request body.' };
  const { username, email, password } = body;
  if (typeof username !== 'string' || !/^[A-Za-z0-9_]{3,20}$/.test(username))
    return { error: 'Username must be 3-20 characters: letters, numbers, underscore.' };
  if (typeof email !== 'string' || email.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email))
    return { error: 'Enter a valid email address.' };
  if (typeof password !== 'string' || password.length < 8 || Buffer.byteLength(password) > 72)
    return { error: 'Password must be 8-72 characters.' };
  return { value: { username, email: email.toLowerCase(), password } };
}

function validateLogin(body) {
  if (!isObject(body)) return { error: 'Invalid request body.' };
  const { email, password } = body;
  if (typeof email !== 'string' || typeof password !== 'string' || !email || !password ||
      email.length > 254 || password.length > 200)
    return { error: 'Email and password are required.' };
  return { value: { email: email.toLowerCase(), password } };
}

function validateServer(body) {
  if (!isObject(body)) return { error: 'Invalid request body.' };
  const { name, serverType, mcVersion, ramMb } = body;
  if (typeof name !== 'string' || !/^[A-Za-z0-9 _-]{3,32}$/.test(name.trim()))
    return { error: 'Server name must be 3-32 characters: letters, numbers, spaces, - and _.' };
  if (!SERVER_TYPES.includes(serverType))
    return { error: 'Choose a valid server type.' };
  if (typeof mcVersion !== 'string' || !/^1\.\d{1,2}(\.\d{1,2})?$/.test(mcVersion))
    return { error: 'Minecraft version must look like 1.21 or 1.20.4.' };
  if (!Number.isInteger(ramMb) || ramMb < 512 || ramMb > 16384 || ramMb % 512 !== 0)
    return { error: 'RAM must be between 512 and 16384 MB, in steps of 512.' };
  return { value: { name: name.trim(), serverType, mcVersion, ramMb } };
}

module.exports = { validateRegistration, validateLogin, validateServer };
