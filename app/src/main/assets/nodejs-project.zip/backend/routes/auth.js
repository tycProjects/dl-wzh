const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const rateLimit = require('express-rate-limit');
const config = require('../config');
const db = require('../db/database');
const { requireAuth } = require('../middleware/auth');
const { validateRegistration, validateLogin } = require('../middleware/validate');

const router = express.Router();

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 30,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many attempts. Try again in a few minutes.' },
});

const cookieOptions = {
  httpOnly: true,
  sameSite: 'strict',
  secure: config.isProd,
  maxAge: config.cookieMaxAgeMs,
  path: '/',
};

function startSession(res, userId) {
  const token = jwt.sign({ sub: userId }, config.jwtSecret, {
    algorithm: 'HS256',
    expiresIn: config.jwtExpiresIn,
  });
  res.cookie('token', token, cookieOptions);
}

// Used so a login for an unknown email takes about as long as a real one.
const DUMMY_HASH = bcrypt.hashSync('not-a-real-password', config.bcryptRounds);

const insertUser = db.prepare('INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)');
const findByEmail = db.prepare('SELECT id, username, email, password_hash FROM users WHERE email = ?');

router.post('/register', limiter, async (req, res, next) => {
  try {
    const { value, error } = validateRegistration(req.body);
    if (error) return res.status(400).json({ error });
    const hash = await bcrypt.hash(value.password, config.bcryptRounds);
    let info;
    try {
      info = insertUser.run(value.username, value.email, hash);
    } catch (e) {
      if (String(e.code).startsWith('SQLITE_CONSTRAINT'))
        return res.status(409).json({ error: 'That username or email is already in use.' });
      throw e;
    }
    startSession(res, info.lastInsertRowid);
    res.status(201).json({ user: { id: info.lastInsertRowid, username: value.username, email: value.email } });
  } catch (e) { next(e); }
});

router.post('/login', limiter, async (req, res, next) => {
  try {
    const { value, error } = validateLogin(req.body);
    if (error) return res.status(400).json({ error });
    const user = findByEmail.get(value.email);
    const ok = await bcrypt.compare(value.password, user ? user.password_hash : DUMMY_HASH);
    if (!user || !ok) return res.status(401).json({ error: 'Incorrect email or password.' });
    startSession(res, user.id);
    res.json({ user: { id: user.id, username: user.username, email: user.email } });
  } catch (e) { next(e); }
});

router.post('/logout', (req, res) => {
  res.clearCookie('token', { ...cookieOptions, maxAge: undefined });
  res.json({ ok: true });
});

router.get('/me', requireAuth, (req, res) => res.json({ user: req.user }));

module.exports = router;
