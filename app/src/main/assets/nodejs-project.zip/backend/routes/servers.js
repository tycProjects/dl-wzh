const express = require('express');
const config = require('../config');
const db = require('../db/database');
const { requireAuth } = require('../middleware/auth');
const { validateServer } = require('../middleware/validate');

const router = express.Router();
router.use(requireAuth);

const COLUMNS = `id, name, server_type AS serverType, mc_version AS mcVersion,
                 ram_mb AS ramMb, port, status, created_at AS createdAt`;

const list = db.prepare(`SELECT ${COLUMNS} FROM servers WHERE user_id = ? ORDER BY id DESC`);
const count = db.prepare('SELECT COUNT(*) AS n FROM servers WHERE user_id = ?');
const insert = db.prepare(
  'INSERT INTO servers (user_id, name, server_type, mc_version, ram_mb) VALUES (?, ?, ?, ?, ?)'
);
const getOne = db.prepare(`SELECT ${COLUMNS} FROM servers WHERE id = ? AND user_id = ?`);
const remove = db.prepare('DELETE FROM servers WHERE id = ? AND user_id = ?');

function parseId(raw) {
  return /^\d{1,9}$/.test(raw) ? Number(raw) : null;
}

router.get('/', (req, res) => {
  res.json({ servers: list.all(req.user.id), limit: config.maxServersPerUser });
});

router.post('/', (req, res, next) => {
  try {
    const { value, error } = validateServer(req.body);
    if (error) return res.status(400).json({ error });
    if (count.get(req.user.id).n >= config.maxServersPerUser)
      return res.status(403).json({ error: `Server limit reached (${config.maxServersPerUser}).` });
    let info;
    try {
      info = insert.run(req.user.id, value.name, value.serverType, value.mcVersion, value.ramMb);
    } catch (e) {
      if (String(e.code).startsWith('SQLITE_CONSTRAINT'))
        return res.status(409).json({ error: 'You already have a server with that name.' });
      throw e;
    }
    res.status(201).json({ server: getOne.get(info.lastInsertRowid, req.user.id) });
  } catch (e) { next(e); }
});

router.get('/:id', (req, res) => {
  const id = parseId(req.params.id);
  const server = id && getOne.get(id, req.user.id);
  if (!server) return res.status(404).json({ error: 'Server not found.' });
  res.json({ server });
});

router.delete('/:id', (req, res) => {
  const id = parseId(req.params.id);
  if (!id || remove.run(id, req.user.id).changes === 0)
    return res.status(404).json({ error: 'Server not found.' });
  res.json({ ok: true });
});

module.exports = router;
