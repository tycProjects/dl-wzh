const countries = [
  { code: 'ID', name: 'Indonesia', flag: '🇮🇩' },
  { code: 'MY', name: 'Malaysia', flag: '🇲🇾' },
  { code: 'SG', name: 'Singapura', flag: '🇸🇬' },
  { code: 'US', name: 'Amerika Serikat', flag: '🇺🇸' },
  { code: 'GB', name: 'Inggris', flag: '🇬🇧' },
  { code: 'JP', name: 'Jepang', flag: '🇯🇵' },
];

const services = [
  { id: 'wa', name: 'WhatsApp', icon: '💬', price: 3500 },
  { id: 'tg', name: 'Telegram', icon: '✈️', price: 2500 },
  { id: 'google', name: 'Google', icon: '🔍', price: 4000 },
  { id: 'ig', name: 'Instagram', icon: '📸', price: 3000 },
  { id: 'tiktok', name: 'TikTok', icon: '🎵', price: 2800 },
  { id: 'fb', name: 'Facebook', icon: '👤', price: 3200 },
];

// Simulasi order di memori (nanti ganti ke database / API provider)
const orders = new Map();

module.exports = { countries, services, orders };