const form = document.getElementById('auth-form');
const msg = document.getElementById('msg');
const mode = form.dataset.mode; // 'login' | 'register'

// Already signed in? Skip straight to the dashboard.
api('/auth/me').then(() => { location.replace('/dashboard.html'); }).catch(() => {});

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  msg.textContent = '';
  const btn = form.querySelector('button[type=submit]');
  const body = Object.fromEntries(new FormData(form).entries());
  btn.disabled = true;
  try {
    await api('/auth/' + mode, { method: 'POST', body });
    location.href = '/dashboard.html';
  } catch (err) {
    msg.textContent = err.message;
    btn.disabled = false;
  }
});
