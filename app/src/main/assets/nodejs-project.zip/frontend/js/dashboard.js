const view = document.getElementById('view');
let user = null;
let state = { servers: [], limit: 0 };

// Build DOM safely: user-supplied text is only ever set via textContent.
function h(tag, attrs = {}, ...children) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === 'class') el.className = v;
    else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
    else el.setAttribute(k, v);
  }
  for (const c of children.flat()) el.append(c instanceof Node ? c : document.createTextNode(c));
  return el;
}

const STATUS_LABELS = { not_provisioned: 'Not provisioned', offline: 'Offline', starting: 'Starting',
  running: 'Running', stopping: 'Stopping', error: 'Error' };
const TYPE_LABELS = { vanilla: 'Vanilla', paper: 'Paper', fabric: 'Fabric', forge: 'Forge' };

async function loadServers() {
  state = await api('/servers');
}

function stat(num, label) {
  return h('div', { class: 'card stat' }, h('div', { class: 'num' }, String(num)), h('div', { class: 'lbl' }, label));
}

function renderOverview() {
  const running = state.servers.filter((s) => s.status === 'running').length;
  return h('div', { class: 'view' },
    h('h1', {}, `Welcome, ${user.username}`),
    h('p', { class: 'sub' }, 'Your hosting overview.'),
    h('div', { class: 'grid' },
      stat(state.servers.length, 'Servers created'),
      stat(running, 'Servers running'),
      stat(Math.max(state.limit - state.servers.length, 0), 'Server slots left')),
    h('div', { class: 'notice' },
      'Server records are saved to your account, but starting and running Minecraft servers is not available yet. ',
      'Status will show "Not provisioned" until that feature is released.'));
}

function serverCard(s) {
  return h('div', { class: 'card server row' },
    h('div', {},
      h('h3', {}, s.name, h('span', { class: 'badge' }, STATUS_LABELS[s.status] || s.status)),
      h('div', { class: 'meta' }, `${TYPE_LABELS[s.serverType]} ${s.mcVersion} \u00b7 ${s.ramMb} MB RAM`)),
    h('button', { class: 'btn btn-sm btn-danger', type: 'button', onclick: () => removeServer(s) }, 'Delete'));
}

function renderServers() {
  const body = state.servers.length
    ? state.servers.map(serverCard)
    : h('div', { class: 'card empty' }, h('p', {}, 'You have no servers yet.'),
        h('a', { class: 'btn btn-primary', href: '#create' }, 'Create your first server'));
  return h('div', { class: 'view' },
    h('h1', {}, 'My servers'),
    h('p', { class: 'sub' }, `${state.servers.length} of ${state.limit} servers used.`),
    body);
}

function renderCreate() {
  const msg = h('p', { class: 'msg', role: 'alert' });
  const field = (label, input, hint) => h('div', { class: 'field' }, h('label', { for: input.id }, label), input, hint ? h('div', { class: 'hint' }, hint) : '');
  const type = h('select', { id: 'serverType' }, Object.entries(TYPE_LABELS).map(([v, l]) => h('option', { value: v }, l)));
  const ver = h('input', { id: 'mcVersion', placeholder: '1.21.4', required: '', autocomplete: 'off' });
  const name = h('input', { id: 'name', placeholder: 'My Survival World', required: '', autocomplete: 'off', maxlength: '32' });
  const ram = h('select', { id: 'ramMb' }, [1024, 2048, 4096, 6144, 8192].map((m) => h('option', { value: m }, `${m / 1024} GB`)));
  const btn = h('button', { class: 'btn btn-primary', type: 'submit' }, 'Create server');

  const form = h('form', { novalidate: '', onsubmit: async (e) => {
    e.preventDefault();
    msg.textContent = '';
    btn.disabled = true;
    try {
      await api('/servers', { method: 'POST', body: {
        name: name.value, serverType: type.value, mcVersion: ver.value.trim(), ramMb: Number(ram.value) } });
      location.hash = '#servers';
    } catch (err) {
      msg.textContent = err.message;
      btn.disabled = false;
    }
  } },
    h('div', { class: 'form-grid' },
      field('Server name', name), field('Server type', type),
      field('Minecraft version', ver, 'Example: 1.21.4'), field('Memory', ram)),
    msg, btn);

  return h('div', { class: 'view' },
    h('h1', {}, 'Create server'),
    h('p', { class: 'sub' }, 'This saves a server record to your account. It does not start a server yet.'),
    h('div', { class: 'card' }, form));
}

function renderAccount() {
  return h('div', { class: 'view' },
    h('h1', {}, 'Account'),
    h('p', { class: 'sub' }, 'Your account details.'),
    h('div', { class: 'card' },
      h('p', {}, h('strong', {}, 'Username: '), user.username),
      h('p', {}, h('strong', {}, 'Email: '), user.email),
      h('p', { class: 'meta' }, `Member since ${user.created_at} (UTC)`)));
}

async function removeServer(s) {
  if (!confirm(`Delete "${s.name}"? This cannot be undone.`)) return;
  try { await api('/servers/' + s.id, { method: 'DELETE' }); } catch (err) { alert(err.message); }
  await render();
}

const views = { overview: renderOverview, servers: renderServers, create: renderCreate, account: renderAccount };

async function render() {
  const name = location.hash.slice(1);
  const key = views[name] ? name : 'overview';
  document.querySelectorAll('.nav-link').forEach((a) => a.classList.toggle('active', a.dataset.view === key));
  try { await loadServers(); } catch (err) { if (err.status === 401) return location.replace('/login.html'); }
  view.replaceChildren(views[key]());
}

document.getElementById('logout').addEventListener('click', async () => {
  try { await api('/auth/logout', { method: 'POST' }); } finally { location.replace('/login.html'); }
});
window.addEventListener('hashchange', render);

(async () => {
  try {
    user = (await api('/auth/me')).user;
  } catch { return location.replace('/login.html'); }
  document.getElementById('who').textContent = user.email;
  render();
})();
