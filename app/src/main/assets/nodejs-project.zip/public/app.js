const $ = (id) => document.getElementById(id);
const button = $("generate");
const result = $("result");

button.addEventListener("click", async () => {
  const phone = $("phone").value.trim();
  const consent = $("consent").checked;
  result.className = "result show";
  result.textContent = "";
  if (!consent) {
    result.textContent = "Please confirm account ownership and understand the access before continuing.";
    return;
  }
  if (!phone) {
    result.textContent = "Enter your WhatsApp number with country code.";
    return;
  }
  button.disabled = true;
  button.textContent = "Generating securely…";
  try {
    const response = await fetch("/api/pair", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ phone, consent })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Could not generate a code.");
    result.innerHTML = "";
    const msg = document.createElement("div");
    msg.textContent = data.message;
    const code = document.createElement("div");
    code.className = "code";
    code.textContent = data.code;
    const copy = document.createElement("button");
    copy.className = "copy";
    copy.textContent = "Copy code";
    copy.addEventListener("click", async () => {
      await navigator.clipboard.writeText(data.code.replace(/-/g, ""));
      copy.textContent = "Copied";
    });
    result.append(msg, code, copy);
  } catch (error) {
    result.textContent = error.message;
  } finally {
    button.disabled = false;
    button.innerHTML = 'Generate pairing code <span>↗</span>';
  }
});
