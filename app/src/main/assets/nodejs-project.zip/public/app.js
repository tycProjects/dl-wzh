const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const store = {
  get(k, fallback){try{return JSON.parse(localStorage.getItem("nexus_"+k)) ?? fallback}catch{return fallback}},
  set(k,v){localStorage.setItem("nexus_"+k,JSON.stringify(v))}
};
let conversations=store.get("conversations",[]), activeId=null, mode="general", busy=false;
let quickReplies=store.get("replies",[
  {id:1,title:"ترحيب",text:"أهلاً بك! كيف يمكنني مساعدتك اليوم؟"},
  {id:2,title:"طلب تفاصيل",text:"هل يمكنك توضيح المطلوب أكثر حتى أساعدك بدقة؟"},
  {id:3,title:"مساعدة Roblox",text:"أرسل فكرة النظام أو السكربت، وسأساعدك في بنائه باستخدام Luau."},
  {id:4,title:"تأكيد الاستلام",text:"تم استلام طلبك. سأرتب الحل إلى خطوات واضحة."}
]);
const labels={chat:"المحادثة",roblox:"Roblox AI",map:"Map Builder",replies:"الردود الجاهزة",projects:"المشاريع",settings:"الإعدادات"};
const style=()=>$("#responseStyle")?.value||"balanced";
function toast(t){const el=$("#toast");el.textContent=t;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),2500)}
function save(){store.set("conversations",conversations);renderHistory();renderProjects()}
function newId(){return Date.now().toString(36)+Math.random().toString(36).slice(2,7)}
function active(){return conversations.find(c=>c.id===activeId)}
function switchView(name){$$(".view").forEach(v=>v.classList.toggle("active",v.id==="view-"+name));$$(".nav-item[data-view]").forEach(b=>b.classList.toggle("active",b.dataset.view===name));$("#pageName").textContent=labels[name]||name;$("#sidebar").classList.remove("open");if(name==="replies")renderReplies();if(name==="projects")renderProjects()}
function renderHistory(){const box=$("#historyList");box.innerHTML="";if(!conversations.length){box.innerHTML='<div class="empty-history">لا توجد محادثات بعد</div>';return}conversations.slice().reverse().slice(0,18).forEach(c=>{const b=document.createElement("button");b.className="history-entry";b.textContent=c.title||"محادثة جديدة";b.onclick=()=>loadConversation(c.id);box.append(b)})}
function renderProjects(){const box=$("#projectGrid");if(!box)return;box.innerHTML="";if(!conversations.length){box.innerHTML='<div class="empty-projects">لا توجد مشاريع أو محادثات محفوظة حتى الآن.</div>';return}conversations.slice().reverse().forEach(c=>{const d=document.createElement("div");d.className="project-card";const p=document.createElement("p");p.textContent=(c.messages?.length||0)+" رسالة · "+new Date(c.updated).toLocaleString();const h=document.createElement("h3");h.textContent=c.title;const b=document.createElement("button");b.textContent="فتح المحادثة";b.onclick=()=>{loadConversation(c.id);switchView("chat")};d.append(h,p,b);box.append(d)})}
function loadConversation(id){activeId=id;$("#welcome").style.display="none";renderFeed()}
function renderFeed(){const feed=$("#chatFeed");feed.innerHTML="";const c=active();if(!c){$("#welcome").style.display="block";return}$("#welcome").style.display="none";c.messages.forEach((m,i)=>addMessage(m.role,m.content,false,i))}
function addMessage(role,content,saveIt=true,index=null){const feed=$("#chatFeed");const row=document.createElement("div");row.className="message "+(role==="user"?"user":"assistant");const av=document.createElement("div");av.className="msg-avatar";av.textContent=role==="user"?"U":"N";const wrap=document.createElement("div");wrap.className="msg-wrap";const body=document.createElement("div");body.className="msg-content";body.textContent=content;wrap.append(body);if(role==="assistant"){const actions=document.createElement("div");actions.className="msg-actions";const copy=document.createElement("button");copy.textContent="نسخ الرد";copy.onclick=()=>navigator.clipboard?.writeText(content).then(()=>toast("تم نسخ الرد"));actions.append(copy);wrap.append(actions)}row.append(av,wrap);feed.append(row);feed.scrollTop=feed.scrollHeight;return row}
function ensureConversation(text){let c=active();if(!c){c={id:newId(),title:text.slice(0,42),messages:[],updated:Date.now()};conversations.push(c);activeId=c.id}return c}
async function sendMessage(text,customMode=mode){if(!text.trim()||busy)return;const c=ensureConversation(text);c.messages.push({role:"user",content:text});c.updated=Date.now();$("#welcome").style.display="none";addMessage("user",text);save();busy=true;$("#sendBtn").disabled=true;const pending=addMessage("assistant","NEXUS AI يفكر الآن...");pending.querySelector(".msg-content").classList.add("typing");
 try{const response=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({messages:c.messages,mode:customMode,style:style()})});const data=await response.json();if(!response.ok)throw new Error(data.error||"تعذر إكمال الطلب.");pending.remove();c.messages.push({role:"assistant",content:data.reply});c.updated=Date.now();addMessage("assistant",data.reply);save();if(data.model)$("#modelLabel").textContent=data.model;
 }catch(e){pending.remove();addMessage("assistant","تعذر إكمال الطلب: "+e.message);toast("تحقق من إعدادات AI Engine");}finally{busy=false;$("#sendBtn").disabled=false;$("#messageInput").focus()}}
$("#chatForm").addEventListener("submit",e=>{e.preventDefault();const v=$("#messageInput").value.trim();if(v){$("#messageInput").value="";$("#messageInput").style.height="auto";sendMessage(v)}});
$("#messageInput").addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();$("#chatForm").requestSubmit()}});
$("#messageInput").addEventListener("input",e=>{e.target.style.height="auto";e.target.style.height=Math.min(e.target.scrollHeight,180)+"px"});
$("#newChat").onclick=()=>{activeId=null;$("#chatFeed").innerHTML="";$("#welcome").style.display="block";switchView("chat")};
$("#clearHistory").onclick=()=>{if(confirm("حذف جميع المحادثات؟")){conversations=[];activeId=null;save();renderFeed()}};
$$("[data-view]").forEach(b=>b.addEventListener("click",()=>switchView(b.dataset.view)));
$$(".cap-card").forEach(b=>b.onclick=()=>{if(b.dataset.view)switchView(b.dataset.view);else{$("#messageInput").value=b.dataset.prompt;$("#messageInput").focus()}});
$("#mobileMenu").onclick=()=>$("#sidebar").classList.toggle("open");
$("#themeBtn").onclick=()=>document.body.classList.toggle("light");

$$(".choice").forEach(b=>b.onclick=()=>{$$(".choice").forEach(x=>x.classList.remove("selected"));b.classList.add("selected")});
$("#generateRoblox").onclick=()=>{const p=$("#robloxPrompt").value.trim();if(!p)return toast("اكتب وصف السكربت أولاً");const kind=$(".choice.selected")?.dataset.value||"إنشاء سكربت كامل";mode="roblox";$("#modeIndicator").textContent="▣ وضع Roblox AI";switchView("chat");sendMessage(`${kind} في Roblox Studio:\n${p}`, "roblox");};
$$(".template").forEach(b=>b.onclick=()=>{$$(".template").forEach(x=>x.classList.remove("selected"));b.classList.add("selected");$("#mapPrompt").value=b.dataset.template+" — "});
$("#buildMap").onclick=()=>{const p=$("#mapPrompt").value.trim();if(!p)return toast("اكتب وصف الماب أو اختر قالباً");mode="map";$("#modeIndicator").textContent="⌘ وضع Map Builder";switchView("chat");sendMessage("صمّم لي هذا الماب في Roblox Studio: "+p+"\nأريد: تصوراً للمناطق، قائمة العناصر، خطة بناء، وسكربتات Luau أولية مع أماكن وضعها وخطوات الاختبار.", "map")};

function renderReplies(){const box=$("#replyGrid");box.innerHTML="";quickReplies.forEach(r=>{const d=document.createElement("div");d.className="reply-card";const h=document.createElement("h3");h.textContent=r.title;const p=document.createElement("p");p.textContent=r.text;const cp=document.createElement("button");cp.textContent="نسخ";cp.onclick=()=>navigator.clipboard?.writeText(r.text).then(()=>toast("تم نسخ الرد"));const del=document.createElement("button");del.textContent="حذف";del.onclick=()=>{quickReplies=quickReplies.filter(x=>x.id!==r.id);store.set("replies",quickReplies);renderReplies()};d.append(h,p,cp,del);box.append(d)})}
$("#addReply").onclick=()=>{const title=$("#replyTitle").value.trim(),text=$("#replyText").value.trim();if(!title||!text)return toast("أدخل عنوان الرد ونصه");quickReplies.push({id:Date.now(),title,text});store.set("replies",quickReplies);$("#replyTitle").value="";$("#replyText").value="";renderReplies();toast("تمت إضافة الرد")};
$("#wipeData").onclick=()=>{if(confirm("سيتم حذف المحادثات والردود المخصصة من هذا المتصفح. متابعة؟")){localStorage.removeItem("nexus_conversations");localStorage.removeItem("nexus_replies");conversations=[];quickReplies=[];save();renderReplies();renderFeed();toast("تم حذف البيانات المحلية")}};
async function health(){try{const r=await fetch("/api/health");const d=await r.json();$("#statusDot").classList.toggle("ok",d.configured);$("#statusText").textContent=d.configured?"AI Engine متصل بالإعدادات":"يلزم إعداد API";$("#connectionDetails").textContent=d.configured?`تم إعداد الخادم. النموذج: ${d.model}`:"لم يتم ضبط مفتاح API واسم النموذج. أضفهما إلى ملف .env على الخادم.";if(d.model)$("#modelLabel").textContent=d.model;else $("#modelLabel").textContent="AI Engine"}catch{$("#statusText").textContent="الخادم غير متاح";$("#connectionDetails").textContent="تعذر الوصول إلى Backend. شغّل npm start وافتح التطبيق عبر localhost."}}
$("#recheck").onclick=health;
renderHistory();renderProjects();renderReplies();health();
