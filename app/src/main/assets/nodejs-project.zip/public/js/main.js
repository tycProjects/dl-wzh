// Kalau di halaman status, cek kode verifikasi tiap 3 detik
const card = document.querySelector("[data-order-id]");
if (card) {
  const orderId = card.dataset.orderId;
  const codeBox = document.getElementById("codeBox");
  const statusText = document.getElementById("statusText");

  const timer = setInterval(async() => {
    try {
      const res = await fetch(`/api/order/${orderId}`);
      const data = await res.json();
      if (data.status == // Kalau di halaman status, cek kode verifikasi tiap 3 detik
        const card = document.querySelector("[data-order-id]");
        if (card) {
          const orderId = card.dataset.orderId;
          const codeBox = document.getElementById("codeBox");
          const statusText = document.getElementById("statusText");

          const timer = setInterval(async() => {
            try {
              const res = await fetch(`/api/order/${orderId}`);
              const data = await res.json();
              if (data.status === "received") {
                codeBox.textContent = data.code;
                statusText.textContent = "Kode diterima";
                clearInterval(timer);
              }
            } catch (e) {
              // diamkan saja
            }
            }, 3000);
        }
        = "received") {
        codeBox.textContent = data.code;
        statusText.textContent = "Kode diterima";
        clearInterval(timer);
      }
    } catch (e) {
      // diamkan saja
    }
    }, 3000);
}
