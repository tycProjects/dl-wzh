const express = require('express');
const router = express.Router();
const provider = require('../services/provider');
const { countries, services } = require('../data/dummy');

router.get('/countries', (req, res) => res.json(countries));
router.get('/services', (req, res) => res.json(services));

router.get('/order/:id', (req, res) => {
  const order = provider.getOrder(req.params.id);
  if (!order) return res.status(404).json({ error: 'not found' });
  res.json(order);
});

module.exports = router;