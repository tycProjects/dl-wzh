const express = require('express');
const router = express.Router();
const { countries, services } = require('../data/dummy');
const provider = require('../services/provider');

router.get('/', (req, res) => {
  res.render('home', { title: 'Beranda', countries, services });
});

router.get('/order', (req, res) => {
  res.render('order', {
    title: 'Buat Pesanan',
    countries,
    services,
    order: null,
    error: null,
  });
});

router.post('/order', (req, res) => {
  const { countryCode, serviceId } = req.body;
  const svc = services.find((s) => s.id === serviceId);
  if (!svc || !countryCode) {
    return res.render('order', {
      title: 'Buat Pesanan',
      countries,
      services,
      order: null,
      error: 'Pilih negara dan aplikasi dulu ya.',
    });
  }
  const order = provider.createOrder({ countryCode, serviceId, price: svc.price });
  res.redirect(`/status/${order.id}`);
});

router.get('/status/:id', (req, res) => {
  const order = provider.getOrder(req.params.id);
  if (!order) {
    return res.status(404).render('status', {
      title: 'Pesanan',
      order: null,
      error: 'Pesanan tidak ditemukan.',
    });
  }
  res.render('status', { title: 'Status Pesanan', order, error: null });
});

router.get('/saldo', (req, res) => {
  res.render('saldo', { title: 'Isi Saldo' });
});

module.exports = router;