// Optional tiny static server. No social-platform scraping or download bypass is implemented.
const http = require("http");
const fs = require("fs");
const path = require("path");
const root = __dirname;
const types = {".html":"text/html; charset=utf-8",".css":"text/css; charset=utf-8",".js":"text/javascript; charset=utf-8",".webmanifest":"application/manifest+json",".svg":"image/svg+xml",".png":"image/png"};
const server = http.createServer((req,res)=>{
  const pathname = decodeURIComponent(new URL(req.url,"http://localhost").pathname);
  let file = path.join(root, pathname === "/" ? "index.html" : pathname.replace(/^\/+/,""));
  if(!file.startsWith(root)){res.writeHead(403);return res.end("Forbidden")}
  fs.stat(file,(err,st)=>{
    if(err || !st.isFile()){res.writeHead(404);return res.end("Not found")}
    res.writeHead(200,{"Content-Type":types[path.extname(file)]||"application/octet-stream","X-Content-Type-Options":"nosniff","Referrer-Policy":"strict-origin-when-cross-origin"});
    fs.createReadStream(file).pipe(res);
  });
});
const port = process.env.PORT || 8080;
server.listen(port,()=>console.log(`NOVA Download running at http://localhost:${port}`));
