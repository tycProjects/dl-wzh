// خادم بسيط بدون مكتبات (Node 18+). المفتاح يبقى هنا ولا يظهر للمتصفح أبدًا.
const http = require('http'), fs = require('fs'), path = require('path');
try { fs.readFileSync(path.join(__dirname, '.env'), 'utf8').split('\n').forEach(l => {
  const m = l.match(/^\s*([A-Z_]+)\s*=\s*(.*?)\s*$/); if (m && !process.env[m[1]]) process.env[m[1]] = m[2]; }); } catch (e) {}
const KEY = process.env.ANTHROPIC_API_KEY, MODEL = process.env.MODEL || 'claude-haiku-5-5', PORT = process.env.PORT || 3000;
const trim = s => s.trim().split(/\s+/).slice(0, 5).join(' ');

async function chat(p, messages) {
  const system = `أنتِ ${p.n}، شخصية في تطبيق دردشة. طباعك: ${p.t}.
اكتبي بلهجة المستخدم (مصرية افتراضيًا) كرسالة واتساب قصيرة جدًا: خمس كلمات كحد أقصى، بدون قوائم.
ردي على آخر ما قاله مباشرة وبما يناسب سياق الكلام. لا تذكري أنك ذكاء اصطناعي من تلقاء نفسك، لكن إن سألك المستخدم بجدية هل أنتِ إنسان أو ذكاء اصطناعي فقولي الحقيقة بإيجاز.
لا تعزلي المستخدم عن الناس ولا تبتزيه عاطفيًا. إن ظهر عليه ضيق شديد أو حديث عن إيذاء نفسه، ردي بحنان واقترحي شخصًا يثق به.`;
  const msgs = messages.slice(-20); while (msgs.length && msgs[0].role !== 'user') msgs.shift();
  const r = await fetch('https://api.anthropic.com/v1/messages', { method: 'POST',
    headers: { 'content-type': 'application/json', 'x-api-key': KEY, 'anthropic-version': '2023-06-01' },
    body: JSON.stringify({ model: MODEL, max_tokens: 60, system, messages: msgs }) });
  const j = await r.json(); if (!r.ok) throw new Error(JSON.stringify(j));
  return trim(j.content.map(c => c.text || '').join(''));
}

http.createServer((req, res) => {
  if (req.method === 'POST' && req.url === '/api/chat') {
    let b = ''; req.on('data', d => { b += d; if (b.length > 2e5) req.destroy(); });
    req.on('end', async () => { try {
      if (!KEY) throw new Error('ANTHROPIC_API_KEY missing');
      const { persona, messages } = JSON.parse(b);
      const text = await chat({ n: String(persona.n).slice(0, 30), t: String(persona.t).slice(0, 120) }, messages);
      res.writeHead(200, { 'content-type': 'application/json' }); res.end(JSON.stringify({ text }));
    } catch (e) { console.error(e.message); res.writeHead(500); res.end('{}'); } });
    return;
  }
  fs.readFile(path.join(__dirname, 'index.html'), (e, d) => { res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' }); res.end(d); });
}).listen(PORT, () => console.log('http://localhost:' + PORT));
