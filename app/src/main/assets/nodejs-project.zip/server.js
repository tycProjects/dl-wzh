require("dotenv").config();
const express = require("express");
const path = require("path");

const app = express();
app.use(express.json({ limit: "12mb" }));
app.use(express.static(path.join(__dirname, "public")));

app.get("/api/health", (_req, res) => {
  res.json({
    ok: true,
    configured: Boolean(process.env.AI_API_KEY && process.env.AI_MODEL),
    model: process.env.AI_MODEL || null
  });
});

app.post("/api/chat", async (req, res) => {
  const { messages, mode = "general", style = "balanced" } = req.body || {};
  if (!Array.isArray(messages) || messages.length === 0) {
    return res.status(400).json({ error: "أرسل رسالة واحدة على الأقل." });
  }
  if (!process.env.AI_API_KEY || !process.env.AI_MODEL) {
    return res.status(503).json({
      error: "لم يتم إعداد مزود الذكاء الاصطناعي بعد. أضف AI_API_KEY وAI_MODEL في ملف .env ثم أعد تشغيل التطبيق."
    });
  }

  const base = (process.env.AI_BASE_URL || "https://api.openai.com/v1").replace(/\/$/, "");
  const styleText = {
    concise: "اجعل الإجابة مختصرة ومباشرة.",
    detailed: "قدّم شرحاً مفصلاً ومنظماً مع أمثلة عند الحاجة.",
    professional: "استخدم أسلوباً احترافياً واضحاً ومنظماً.",
    technical: "استخدم الدقة التقنية والمصطلحات المناسبة واشرح الافتراضات."
  }[style] || "وازن بين الوضوح والتفصيل.";

  const modePrompts = {
    general: "أنت NEXUS AI، مساعد عام دقيق. لا تختلق معلومات، وصرّح بعدم اليقين عند الحاجة.",
    roblox: "أنت مهندس Roblox Studio متخصص في Luau. اكتب حلولاً كاملة وآمنة، واذكر نوع السكربت ومكان وضعه داخل Explorer، ومتطلبات RemoteEvents/RemoteFunctions، وخطوات الاختبار. لا تستخدم استغلالات أو تجاوزات أمنية.",
    map: "أنت مصمم Roblox map builder. حوّل وصف المستخدم إلى خطة بناء منظمة ثم سكربتات Luau قابلة للتشغيل في Roblox Studio. وضّح ما الذي ينشئه السكربت ومكان تشغيله، وراعِ الأداء."
  };

  const system = `${modePrompts[mode] || modePrompts.general}\n${styleText}\nأجب بلغة المستخدم ما لم يطلب لغة أخرى.`;
  try {
    const upstream = await fetch(`${base}/chat/completions`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.AI_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: process.env.AI_MODEL,
        messages: [{ role: "system", content: system }, ...messages.slice(-24)],
        temperature: 0.7
      })
    });
    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      return res.status(upstream.status).json({
        error: data.error?.message || `فشل مزود النموذج (HTTP ${upstream.status}).`
      });
    }
    const reply = data.choices?.[0]?.message?.content;
    if (!reply) return res.status(502).json({ error: "لم يرجع مزود النموذج نصاً صالحاً." });
    res.json({ reply, model: process.env.AI_MODEL });
  } catch (err) {
    res.status(500).json({ error: "تعذر الاتصال بمزود الذكاء الاصطناعي. تحقق من الاتصال وإعدادات الخادم." });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`NEXUS AI running at http://localhost:${port}`));
