// سيرفر أونلاين لبلوك كرافت - بدون أي مكتبات خارجية: node server.js
const http=require('http'),fs=require('fs'),crypto=require('crypto'),path=require('path');
const PORT=process.env.PORT||3000,DB=path.join(__dirname,'users.json');
let users={};try{users=JSON.parse(fs.readFileSync(DB))}catch(e){}
const save=()=>fs.writeFileSync(DB,JSON.stringify(users)),hash=(p,s)=>crypto.scryptSync(p,s,32).toString('hex'),rooms={};let nid=1;
const srv=http.createServer((q,r)=>{try{r.writeHead(200,{'Content-Type':'text/html;charset=utf-8'});r.end(fs.readFileSync(path.join(__dirname,'index.html')))}catch(e){r.end('index.html missing')}});
const send=(c,o)=>{if(c.s.destroyed)return;const d=Buffer.from(JSON.stringify(o)),n=d.length;let h;if(n<126)h=Buffer.from([129,n]);else if(n<65536){h=Buffer.alloc(4);h[0]=129;h[1]=126;h.writeUInt16BE(n,2)}else{h=Buffer.alloc(10);h[0]=129;h[1]=127;h.writeBigUInt64BE(BigInt(n),2)}c.s.write(Buffer.concat([h,d]))};
const bc=(rm,o,ex)=>rm.pl.forEach(c=>c!==ex&&send(c,o));
function leave(c){const rm=c.rm;if(!rm)return;rm.pl.delete(c);bc(rm,{t:'pl',id:c.id,u:c.u});c.rm=null;if(!rm.pl.size&&!rm.pub)delete rooms[rm.id]}
function parse(c,data){c.buf=Buffer.concat([c.buf,data]);if(c.buf.length>9e6){c.s.destroy();return}
for(;;){const b=c.buf;if(b.length<2)return;let n=b[1]&127,o=2;if(n==126){if(b.length<4)return;n=b.readUInt16BE(2);o=4}else if(n==127){if(b.length<10)return;n=Number(b.readBigUInt64BE(2));o=10}
const m=b[1]&128;if(b.length<o+(m?4:0)+n)return;const mk=m?b.slice(o,o+4):null;o+=m?4:0;const p=Buffer.from(b.slice(o,o+n));if(mk)for(let i=0;i<n;i++)p[i]^=mk[i&3];c.buf=b.slice(o+n);
const op=b[0]&15;if(op==8){c.s.end();return}if(op==1)try{handle(c,JSON.parse(p.toString()))}catch(e){}}}
function auth(c,u,k){c.u=u;send(c,{t:'auth',ok:1,u,k})}
function handle(c,m){
if(m.t=='reg'||m.t=='login'){const u=String(m.u||'').trim(),p=String(m.p||'');
if(m.t=='reg'){if(!/^[\w\u0600-\u06FF]{2,16}$/.test(u)||p.length<4)return send(c,{t:'auth',ok:0,err:'الاسم 2-16 حرف وكلمة السر 4 على الأقل'});if(users[u])return send(c,{t:'auth',ok:0,err:'الاسم مستخدم'});
const s=crypto.randomBytes(8).toString('hex'),k=crypto.randomBytes(16).toString('hex');users[u]={s,h:hash(p,s),k};save();return auth(c,u,k)}
const x=users[u];if(!x||x.h!=hash(p,x.s))return send(c,{t:'auth',ok:0,err:'اسم أو كلمة سر غلط'});return auth(c,u,x.k)}
if(m.t=='tok'){const u=Object.keys(users).find(n=>users[n].k==m.k);if(u)auth(c,u,m.k);return}
if(!c.u)return send(c,{t:'err',err:'سجّل دخول أول'});
if(m.t=='rooms')return send(c,{t:'rooms',list:Object.values(rooms).filter(r=>r.pub).map(r=>({id:r.id,name:r.name,mode:r.mode,n:r.pl.size}))});
if(m.t=='create'||m.t=='join'){let rm;if(m.t=='create'){const id=crypto.randomBytes(3).toString('hex').toUpperCase();rm=rooms[id]={id,name:String(m.name||'غرفة').slice(0,24),mode:m.mode=='c'?'c':'s',seed:String(m.seed||'1').slice(0,24),wn:String(m.wn||'').slice(0,24),pub:!!m.pub,ed:{},accs:[],pl:new Set()}}
else{rm=rooms[m.code||m.id];if(!rm||(!m.code&&!rm.pub))return send(c,{t:'err',err:'ما لقيت الغرفة'})}
leave(c);c.rm=rm;const others=[...rm.pl];rm.pl.add(c);
send(c,{t:'joined',room:{id:rm.id,name:rm.name,mode:rm.mode,seed:rm.seed,wn:rm.wn,code:rm.pub?'':rm.id},ed:rm.ed,accs:rm.accs,pl:others.map(o=>({id:o.id,u:o.u,sk:o.sk}))});
bc(rm,{t:'pj',id:c.id,u:c.u,sk:c.sk},c);return}
const rm=c.rm;if(!rm)return;
if(m.t=='p')bc(rm,{t:'p',id:c.id,x:m.x,y:m.y,z:m.z,yw:m.yw},c);
else if(m.t=='b'){rm.ed[m.x+','+m.y+','+m.z]=m.v;bc(rm,{t:'b',x:m.x,y:m.y,z:m.z,v:m.v},c)}
else if(m.t=='c')bc(rm,{t:'c',u:c.u,m:String(m.m).slice(0,200)});
else if(m.t=='sk'){c.sk=String(m.d).slice(0,60000);bc(rm,{t:'sk',id:c.id,d:c.sk},c)}
else if(m.t=='a'&&rm.accs.length<30){rm.accs.push(m);bc(rm,m,c)}
else if(m.t=='ar'){rm.accs=rm.accs.filter(a=>a.id!=m.id);bc(rm,{t:'ar',id:m.id},c)}}
srv.on('upgrade',(q,s)=>{const k=q.headers['sec-websocket-key'];if(!k)return s.destroy();
s.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: '+crypto.createHash('sha1').update(k+'258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64')+'\r\n\r\n');
const c={s,id:nid++,buf:Buffer.alloc(0),u:null,rm:null};s.on('data',d=>parse(c,d));s.on('close',()=>leave(c));s.on('error',()=>{})});
srv.listen(PORT,()=>console.log('BlockCraft server: http://localhost:'+PORT));
