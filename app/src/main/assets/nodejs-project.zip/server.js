// Zero-dependency test server for WZH 2 APK Node.js builds.
const http = require('http');
const fs = require('fs');
const path = require('path');

const dataDir = process.env.WZH_DATA_DIR || path.join(__dirname, 'data');
fs.mkdirSync(dataDir, { recursive: true });
const counterFile = path.join(dataDir, 'visits.json');

function readVisits() {
  try { return JSON.parse(fs.readFileSync(counterFile, 'utf8')).visits || 0; } catch (e) { return 0; }
}

function send(res, code, type, body) {
  res.writeHead(code, { 'Content-Type': type });
  res.end(body);
}

const server = http.createServer((req, res) => {
  if (req.url === '/api/info') {
    const addr = server.address();
    return send(res, 200, 'application/json', JSON.stringify({
      node: process.version,
      platform: process.platform,
      arch: process.arch,
      port: addr && addr.port,
      host: addr && addr.address,
      dataDir,
      visits: readVisits()
    }));
  }
  if (req.url === '/api/visit' && req.method === 'POST') {
    const visits = readVisits() + 1;
    fs.writeFileSync(counterFile, JSON.stringify({ visits }));
    return send(res, 200, 'application/json', JSON.stringify({ visits }));
  }
  const file = req.url === '/' ? '/index.html' : req.url.split('?')[0];
  const full = path.join(__dirname, 'public', path.normalize(file));
  if (!full.startsWith(path.join(__dirname, 'public'))) return send(res, 403, 'text/plain', 'Forbidden');
  fs.readFile(full, (err, buf) => {
    if (err) return send(res, 404, 'text/plain', 'Not found');
    send(res, 200, 'text/html; charset=utf-8', buf);
  });
});

// Port 3000 is hardcoded on purpose: inside the app it should be redirected to the real port.
server.listen(3000, () => console.log('test server listening'));
