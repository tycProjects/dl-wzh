const express = require("express");
const rateLimit = require("express-rate-limit");
const path = require("path");
const fs = require("fs");
const pino = require("pino");
const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason
} = require("@whiskeysockets/baileys");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const SESSION_DIR = path.join(__dirname, "sessions");
const active = new Map();

app.use(express.json({ limit: "20kb" }));
app.use(express.static(path.join(__dirname, "public")));
app.use("/api/", rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 8,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { error: "Too many requests. Please wait and try again." }
}));

function cleanPhone(value) {
  return String(value || "").replace(/\D/g, "");
}
function sessionPath(phone) {
  return path.join(SESSION_DIR, phone);
}
function safeReplyText(text) {
  return String(text || "").slice(0, 3500);
}

async function startSession(phone) {
  const dir = sessionPath(phone);
  fs.mkdirSync(dir, { recursive: true });
  const { state, saveCreds } = await useMultiFileAuthState(dir);

  const sock = makeWASocket({
    auth: state,
    logger: pino({ level: "silent" }),
    printQRInTerminal: false,
    browser: ["Community Bot", "Chrome", "1.0.0"]
  });

  sock.ev.on("creds.update", saveCreds);
  sock.ev.on("messages.upsert", async ({ messages, type }) => {
    if (type !== "notify") return;
    for (const msg of messages) {
      if (!msg.message || msg.key.fromMe || msg.key.remoteJid === "status@broadcast") continue;
      const jid = msg.key.remoteJid;
      const raw = msg.message.conversation ||
        msg.message.extendedTextMessage?.text || "";
      const command = raw.trim().toLowerCase();

      let reply = "";
      if (command === ".menu" || command === ".help") {
        reply = [
          "✨ *COMMUNITY BOT — MENU*",
          "",
          "`.menu` — Show commands",
          "`.ping` — Check bot status",
          "`.about` — About this bot",
          "`.privacy` — Privacy and session info",
          "",
          "More features can be added safely in `server.js`."
        ].join("\\n");
      } else if (command === ".ping") {
        reply = "🏓 Pong! Your bot is online.";
      } else if (command === ".about") {
        reply = "A community-made WhatsApp assistant. Use it respectfully and only message people who expect to hear from you.";
      } else if (command === ".privacy") {
        reply = "This starter stores WhatsApp session files on the server so the bot can stay connected. The server owner must protect these files and provide a way to disconnect/delete a session.";
      }

      if (reply) {
        await sock.sendMessage(jid, { text: safeReplyText(reply) });
      }
    }
  });

  sock.ev.on("connection.update", ({ connection, lastDisconnect }) => {
    if (connection === "close") {
      const code = lastDisconnect?.error?.output?.statusCode;
      active.delete(phone);
      if (code !== DisconnectReason.loggedOut) {
        // A production deployment should use a supervised reconnect queue.
        console.log(`Session ${phone.slice(-4)} disconnected; reconnect it from the dashboard.`);
      } else {
        console.log(`Session ${phone.slice(-4)} logged out.`);
      }
    }
    if (connection === "open") {
      console.log(`WhatsApp session connected: ••••${phone.slice(-4)}`);
    }
  });

  active.set(phone, sock);
  return sock;
}

app.post("/api/pair", async (req, res) => {
  const phone = cleanPhone(req.body?.phone);
  const consent = req.body?.consent === true;

  if (!consent) return res.status(400).json({ error: "Please confirm that this is your own WhatsApp account and you understand the access being granted." });
  if (phone.length < 8 || phone.length > 15) {
    return res.status(400).json({ error: "Enter a valid phone number with country code, digits only." });
  }
  if (active.has(phone)) return res.status(409).json({ error: "A session for this number is already starting or connected." });

  try {
    const sock = await startSession(phone);
    // Pairing code is shown only to the person who submitted the number.
    const code = await sock.requestPairingCode(phone);
    res.json({ code: code.match(/.{1,4}/g)?.join("-") || code, message: "On your own phone, open WhatsApp → Linked devices → Link a device → Link with phone number, then enter this code." });
  } catch (err) {
    active.delete(phone);
    console.error("Pairing error:", err?.message || err);
    res.status(500).json({ error: "Could not create a pairing code. Check the number and server logs, then try again." });
  }
});

app.post("/api/disconnect", async (req, res) => {
  const phone = cleanPhone(req.body?.phone);
  if (phone.length < 8 || phone.length > 15) return res.status(400).json({ error: "Invalid phone number." });
  const sock = active.get(phone);
  if (sock) {
    try { await sock.logout(); } catch (_) {}
    active.delete(phone);
  }
  fs.rmSync(sessionPath(phone), { recursive: true, force: true });
  res.json({ message: "Local session data removed. If the device remains linked, also remove it from WhatsApp → Linked devices." });
});

app.get("/api/status", (req, res) => {
  const phone = cleanPhone(req.query.phone);
  res.json({ connectedOrStarting: active.has(phone) });
});

app.listen(PORT, () => {
  fs.mkdirSync(SESSION_DIR, { recursive: true });
  console.log(`Community Bot running at http://localhost:${PORT}`);
});
