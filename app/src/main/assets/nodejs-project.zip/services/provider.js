// File ini yang nanti kamu ganti dengan integrasi penyedia asli
// (SMS-Activate, OtpGet, dll.)

const { orders } = require('../data/dummy');

function randomNumber(countryCode) {
  const prefix = { ID: '+62', MY: '+60', SG: '+65', US: '+1', GB: '+44', JP: '+81' };
  const p = prefix[countryCode] || '+00';
  const rand = Math.floor(100000000 + Math.random() * 900000000);
  return `${p}${rand}`;
}

function createOrder({ countryCode, serviceId, price }) {
  const id = 'ORD-' + Date.now();
  const order = {
    id,
    countryCode,
    serviceId,
    price,
    number: randomNumber(countryCode),
    code: null,
    status: 'waiting', // waiting | received | expired
    createdAt: new Date(),
  };
  orders.set(id, order);

  // Simulasi kode masuk setelah 8 detik
  setTimeout(() => {
    const o = orders.get(id);
    if (o && o.status === 'waiting') {
      o.code = String(Math.floor(100000 + Math.random() * 900000));
      o.status = 'received';
    }
  }, 8000);

  return order;
}

function getOrder(id) {
  return orders.get(id);
}

module.exports = { createOrder, getOrder };