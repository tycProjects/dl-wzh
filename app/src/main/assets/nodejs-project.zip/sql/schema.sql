create table if not exists accounts(id uuid primary key,nickname text unique not null,level int not null default 1,experience int not null default 0,rank text not null default 'Novice',rating int not null default 0,created_at timestamptz default now());
create table if not exists inventory_items(instance_id uuid primary key,owner_id uuid not null,definition_id text not null,skin_id text,rarity text,created_at timestamptz default now());
create table if not exists transactions(id uuid primary key,idempotency_key text unique not null,owner_id uuid,kind text not null,payload jsonb not null,created_at timestamptz default now());
create table if not exists matches(id uuid primary key,mode text not null,map text not null,result jsonb,created_at timestamptz default now());
create table if not exists reports(id uuid primary key,reporter_id uuid,target_id uuid,kind text not null,payload jsonb,created_at timestamptz default now());
