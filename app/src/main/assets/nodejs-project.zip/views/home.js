<%- include('layout', { title, body: `
  <section class="hero">
    <h1>Beli Nomor Kosong <span>Cepat & Otomatis</span></h1>
    <p>Pilih negara dan aplikasi, nomor langsung dikirim ke halaman pesananmu.</p>
    <a href="/order" class="btn-primary">Mulai Pesan</a>
  </section>

  <section class="grid-cards">
    <h2>Negara Tersedia</h2>
    <div class="grid">
      ${countries.map(c => `
        <div class="card">
          <span class="flag">${c.flag}</span>
          <p>${c.name}</p>
        </div>
      `).join('')}
    </div>
  </section>

  <section class="grid-cards">
    <h2>Aplikasi Populer</h2>
    <div class="grid">
      ${services.map(s => `
        <div class="card">
          <span class="icon">${s.icon}</span>
          <p>${s.name}</p>
          <small>Rp${s.price.toLocaleString('id-ID')}</small>
        </div>
      `).join('')}
    </div>
  </section>
` }) %>