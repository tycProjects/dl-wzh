<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title><%= title %> · NokosKu</title>
  <link rel="stylesheet" href="/css/style.css" />
</head>
<body>
  <header class="navbar">
    <a href="/" class="brand">☁️ NokosKu</a>
    <nav>
      <a href="/">Beranda</a>
      <a href="/order">Pesan</a>
      <a href="/saldo">Isi Saldo</a>
    </nav>
  </header>

  <main class="container">
    <%- body %>
  </main>

  <footer class="footer">
    <p>© 2026 NokosKu — Demo UI. Gunakan dengan bijak.</p>
  </footer>

  <script src="/js/main.js"></script>
</body>
</html>