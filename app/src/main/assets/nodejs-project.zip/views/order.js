<%- include('layout', { title, body: `
  <section class="page-head">
    <h1>Buat Pesanan</h1>
    <p>Pilih negara dan aplikasi, lalu klik Pesan.</p>
  </section>

  ${error ? `<div class="alert">${error}</div>` : ''}

  <form action="/order" method="POST" class="order-form">
    <label>Negara</label>
    <select name="countryCode" required>
      <option value="">— Pilih Negara —</option>
      ${countries.map(c => `<option value="${c.code}">${c.flag} ${c.name}</option>`).join('')}
    </select>

    <label>Aplikasi</label>
    <select name="serviceId" required>
      <option value="">— Pilih Aplikasi —</option>
      ${services.map(s => `<option value="${s.id}">${s.icon} ${s.name} — Rp${s.price.toLocaleString('id-ID')}</option>`).join('')}
    </select>

    <button type="submit" class="btn-primary">Pesan Sekarang</button>
  </form>
` }) %>