<%- include('layout', { title, body: `
  <section class="page-head">
    <h1>Isi Saldo</h1>
    <p>Pilih nominal, lalu lanjut ke pembayaran.</p>
  </section>

  <div class="grid">
    ${[10000, 25000, 50000, 100000].map(n => `
      <div class="card saldo-card">
        <p>Rp${n.toLocaleString('id-ID')}</p>
        <button class="btn-primary" onclick="alert('Integrasi pembayaran belum tersambung')">Pilih</button>
      </div>
    `).join('')}
  </div>
` }) %>