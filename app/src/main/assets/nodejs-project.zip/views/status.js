<%- include('layout', { title, body: `
  <section class="page-head">
    <h1>Status Pesanan</h1>
  </section>

  ${error ? `<div class="alert">${error}</div>` : ''}

  ${order ? `
    <div class="order-card" data-order-id="${order.id}">
      <p class="label">ID Pesanan</p>
      <h2>${order.id}</h2>

      <p class="label">Nomor</p>
      <div class="number-box">${order.number}</div>

      <p class="label">Kode Verifikasi</p>
      <div class="code-box" id="codeBox">
        ${order.status === 'received' ? order.code : 'Menunggu kode...'}
      </div>

      <p class="status-line">
        Status: <strong id="statusText">${order.status === 'received' ? 'Kode diterima' : 'Menunggu SMS'}</strong>
      </p>

      <a href="/order" class="btn-secondary">Pesan Lagi</a>
    </div>
  ` : ''}
` }) %>