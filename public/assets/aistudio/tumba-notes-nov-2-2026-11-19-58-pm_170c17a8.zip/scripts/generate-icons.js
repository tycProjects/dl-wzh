import fs from 'fs';
import path from 'path';
import zlib from 'zlib';

function createPNG(width, height, getPixel) {
  // getPixel(x, y) => [r, g, b, a]
  const bytesPerPixel = 4;
  const lineSize = 1 + width * bytesPerPixel;
  const rawData = Buffer.alloc(lineSize * height);

  for (let y = 0; y < height; y++) {
    const rowOffset = y * lineSize;
    rawData[rowOffset] = 0; // Filter type 0 (None)
    for (let x = 0; x < width; x++) {
      const [r, g, b, a] = getPixel(x, y);
      const pxOffset = rowOffset + 1 + x * bytesPerPixel;
      rawData[pxOffset] = r;
      rawData[pxOffset + 1] = g;
      rawData[pxOffset + 2] = b;
      rawData[pxOffset + 3] = a;
    }
  }

  const compressed = zlib.deflateSync(rawData);

  function crc32(buf) {
    let crc = 0xffffffff;
    for (let i = 0; i < buf.length; i++) {
      crc ^= buf[i];
      for (let j = 0; j < 8; j++) {
        crc = (crc >>> 1) ^ (-(crc & 1) & 0xedb88320);
      }
    }
    return (crc ^ 0xffffffff) >>> 0;
  }

  function makeChunk(type, data) {
    const len = Buffer.alloc(4);
    len.writeUInt32BE(data.length, 0);
    const typeBuf = Buffer.from(type, 'ascii');
    const crcBuf = Buffer.alloc(4);
    const toCrc = Buffer.concat([typeBuf, data]);
    crcBuf.writeUInt32BE(crc32(toCrc), 0);
    return Buffer.concat([len, typeBuf, data, crcBuf]);
  }

  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8; // bit depth
  ihdr[9] = 6; // color type (RGBA)
  ihdr[10] = 0; // compression
  ihdr[11] = 0; // filter
  ihdr[12] = 0; // interlace

  const ihdrChunk = makeChunk('IHDR', ihdr);
  const idatChunk = makeChunk('IDAT', compressed);
  const iendChunk = makeChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([signature, ihdrChunk, idatChunk, iendChunk]);
}

// Ensure public dir
const publicDir = path.resolve('public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

// Design: Graphite dark background #161719 (22, 23, 25), elegant inner square #202124 (32, 33, 36),
// with subtle border #303236 (48, 50, 54), and crisp light graphite/white 'T' monogram #F1F1F1 (241, 241, 241)
function makeIcon(size) {
  return createPNG(size, size, (x, y) => {
    const cx = size / 2;
    const cy = size / 2;
    const r = size * 0.44; // rounded corner box
    const cornerR = size * 0.18;

    // Background: #161719
    let bgR = 22, bgG = 23, bgB = 25, bgA = 255;

    // Inner card bounds
    const minX = size * 0.12;
    const maxX = size * 0.88;
    const minY = size * 0.12;
    const maxY = size * 0.88;

    // Check if inside rounded squircle
    let inCard = false;
    if (x >= minX && x <= maxX && y >= minY && y <= maxY) {
      let dx = 0, dy = 0;
      if (x < minX + cornerR) dx = minX + cornerR - x;
      else if (x > maxX - cornerR) dx = x - (maxX - cornerR);
      if (y < minY + cornerR) dy = minY + cornerR - y;
      else if (y > maxY - cornerR) dy = y - (maxY - cornerR);
      if (dx * dx + dy * dy <= cornerR * cornerR) {
        inCard = true;
      }
    }

    if (inCard) {
      bgR = 32; bgG = 33; bgB = 36; // #202124
      // border
      if (
        x <= minX + 2 || x >= maxX - 2 ||
        y <= minY + 2 || y >= maxY - 2
      ) {
        bgR = 48; bgG = 50; bgB = 54; // #303236
      }
    }

    // Monogram 'T' & minimalist lines
    // T top bar: y between 0.32 and 0.40, x between 0.28 and 0.72
    const inTBar = (y >= size * 0.30 && y <= size * 0.38 && x >= size * 0.28 && x <= size * 0.72);
    // T stem: y between 0.38 and 0.70, x between 0.45 and 0.55
    const inTStem = (y >= size * 0.38 && y <= size * 0.70 && x >= size * 0.45 && x <= size * 0.55);
    // Dot indicator / accent at bottom: y between 0.73 and 0.77, x between 0.47 and 0.53
    const inDot = (y >= size * 0.73 && y <= size * 0.77 && x >= size * 0.47 && x <= size * 0.53);

    if (inTBar || inTStem) {
      return [241, 241, 241, 255]; // #F1F1F1
    }
    if (inDot) {
      return [183, 185, 190, 255]; // #B7B9BE
    }

    return [bgR, bgG, bgB, bgA];
  });
}

fs.writeFileSync(path.join(publicDir, 'pwa-192x192.png'), makeIcon(192));
fs.writeFileSync(path.join(publicDir, 'pwa-512x512.png'), makeIcon(512));
fs.writeFileSync(path.join(publicDir, 'pwa-maskable-512x512.png'), makeIcon(512));
fs.writeFileSync(path.join(publicDir, 'apple-touch-icon.png'), makeIcon(180));
fs.writeFileSync(path.join(publicDir, 'favicon.ico'), makeIcon(64));

// Also write clean SVG icon
const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="100%" height="100%">
  <rect width="512" height="512" fill="#161719"/>
  <rect x="56" y="56" width="400" height="400" rx="64" fill="#202124" stroke="#303236" stroke-width="8"/>
  <!-- T Monogram -->
  <path d="M140 160 H372 V200 H280 V360 H232 V200 H140 Z" fill="#F1F1F1"/>
  <rect x="236" y="380" width="40" height="20" rx="4" fill="#B7B9BE"/>
</svg>`;
fs.writeFileSync(path.join(publicDir, 'icon.svg'), svg);

console.log('Icons generated successfully!');
