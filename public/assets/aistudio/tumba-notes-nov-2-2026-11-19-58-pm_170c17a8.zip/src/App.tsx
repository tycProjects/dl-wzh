/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  db,
  seedDatabaseIfEmpty,
  getSettings,
  saveSetting,
  DEFAULT_SETTINGS,
  getAllChildFolderIds,
} from './db/db';
import type { Note, Folder, Tag, ViewSection, AppSettings } from './types';
import { Sidebar } from './components/Sidebar';
import { NoteList } from './components/NoteList';
import { NoteEditor } from './components/NoteEditor';
import { Dashboard } from './components/Dashboard';
import { SearchModal } from './components/SearchModal';
import { FolderModal } from './components/FolderModal';
import { TagModal } from './components/TagModal';
import { SettingsModal } from './components/SettingsModal';
import { ConfirmModal } from './components/ConfirmModal';
import { MobileBottomNav } from './components/MobileBottomNav';
import { useKeyboardShortcuts } from './hooks/useKeyboardShortcuts';
import {
  downloadNoteAsMarkdown,
  downloadNoteAsTxt,
  downloadFolderNotesAsBundle,
} from './utils/exportUtils';
import { Menu, ArrowLeft } from 'lucide-react';

export default function App() {
  // Database data states
  const [notes, setNotes] = useState<Note[]>([]);
  const [folders, setFolders] = useState<Folder[]>([]);
  const [tags, setTags] = useState<Tag[]>([]);
  const [noteTagsMap, setNoteTagsMap] = useState<Record<string, string[]>>({});
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [isLoading, setIsLoading] = useState(true);

  // View & selection states
  const [currentSection, setCurrentSection] = useState<ViewSection>('all');
  const [selectedFolderId, setSelectedFolderId] = useState<string | null>(null);
  const [selectedTagId, setSelectedTagId] = useState<string | null>(null);
  const [activeNoteId, setActiveNoteId] = useState<string | null>(null);

  // Layout UI states
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isMobileDrawerOpen, setIsMobileDrawerOpen] = useState(false);
  const [isFullscreenEditor, setIsFullscreenEditor] = useState(false);
  const [mobileViewMode, setMobileViewMode] = useState<'list' | 'editor'>('list');

  // Modals state
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [folderModalState, setFolderModalState] = useState<{
    isOpen: boolean;
    folderToEdit?: Folder | null;
    parentFolderId?: string | null;
  }>({ isOpen: false });
  const [tagModalState, setTagModalState] = useState<{
    isOpen: boolean;
    tagToEdit?: Tag | null;
  }>({ isOpen: false });
  const [confirmModalState, setConfirmModalState] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    confirmLabel?: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {},
  });

  // Load all database tables
  const loadDatabaseData = useCallback(async () => {
    try {
      await seedDatabaseIfEmpty();
      const [fetchedNotes, fetchedFolders, fetchedTags, fetchedNoteTags, fetchedSettings] =
        await Promise.all([
          db.notes.toArray(),
          db.folders.toArray(),
          db.tags.toArray(),
          db.noteTags.toArray(),
          getSettings(),
        ]);

      setNotes(fetchedNotes);
      setFolders(fetchedFolders);
      setTags(fetchedTags);
      setSettings(fetchedSettings);

      // Build noteTagsMap
      const ntMap: Record<string, string[]> = {};
      for (const nt of fetchedNoteTags) {
        if (!ntMap[nt.noteId]) ntMap[nt.noteId] = [];
        ntMap[nt.noteId].push(nt.tagId);
      }
      setNoteTagsMap(ntMap);

      // Set initial active note if none selected
      if (!activeNoteId && fetchedNotes.length > 0) {
        const firstActive = fetchedNotes.find((n) => !n.inTrash && !n.isArchived);
        if (firstActive) {
          setActiveNoteId(firstActive.id);
        }
      }
    } catch (err) {
      console.error('Error loading database:', err);
    } finally {
      setIsLoading(false);
    }
  }, [activeNoteId]);

  useEffect(() => {
    loadDatabaseData();
  }, [loadDatabaseData]);

  // Apply theme & accent attributes to HTML document
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', settings.theme);
    document.documentElement.setAttribute('data-accent', settings.accent);
  }, [settings.theme, settings.accent]);

  // Active note instance
  const activeNote = useMemo(() => {
    return notes.find((n) => n.id === activeNoteId) || null;
  }, [notes, activeNoteId]);

  const selectedFolder = useMemo(() => {
    return folders.find((f) => f.id === selectedFolderId) || null;
  }, [folders, selectedFolderId]);

  const selectedTag = useMemo(() => {
    return tags.find((t) => t.id === selectedTagId) || null;
  }, [tags, selectedTagId]);

  // Handlers for note operations
  const handleSelectNote = (noteId: string) => {
    setActiveNoteId(noteId);
    setMobileViewMode('editor');
  };

  const handleCreateNewNote = async () => {
    const now = Date.now();
    const newNote: Note = {
      id: `note-${now}-${Math.random().toString(36).substring(2, 7)}`,
      title: 'Untitled Note',
      content: '<p></p>',
      folderId: selectedFolderId || null,
      isFavorite: currentSection === 'favorites',
      isPinned: false,
      isArchived: false,
      inTrash: false,
      trashedAt: null,
      createdAt: now,
      updatedAt: now,
    };

    await db.notes.add(newNote);
    setNotes((prev) => [newNote, ...prev]);

    // If a tag is currently filtered, assign that tag immediately
    if (selectedTagId) {
      await db.noteTags.add({ noteId: newNote.id, tagId: selectedTagId });
      setNoteTagsMap((prev) => ({
        ...prev,
        [newNote.id]: [selectedTagId],
      }));
    }

    setActiveNoteId(newNote.id);
    if (currentSection === 'home') {
      setCurrentSection('all');
    }
    setMobileViewMode('editor');
  };

  const handleSaveNote = async (updatedFields: Partial<Note> & { id: string }) => {
    const noteId = updatedFields.id;
    const now = Date.now();
    const toUpdate = { ...updatedFields, updatedAt: updatedFields.updatedAt || now };

    await db.notes.update(noteId, toUpdate);
    setNotes((prev) =>
      prev.map((n) => (n.id === noteId ? { ...n, ...toUpdate } : n))
    );
  };

  const handleUpdateNoteTags = async (noteId: string, tagIds: string[]) => {
    await db.transaction('rw', db.noteTags, async () => {
      await db.noteTags.where('noteId').equals(noteId).delete();
      if (tagIds.length > 0) {
        await db.noteTags.bulkAdd(tagIds.map((tId) => ({ noteId, tagId: tId })));
      }
    });

    setNoteTagsMap((prev) => ({
      ...prev,
      [noteId]: tagIds,
    }));
  };

  const handleToggleFavorite = async (noteId: string, e?: React.MouseEvent) => {
    e?.stopPropagation();
    const note = notes.find((n) => n.id === noteId);
    if (!note) return;

    const newVal = !note.isFavorite;
    await db.notes.update(noteId, { isFavorite: newVal });
    setNotes((prev) =>
      prev.map((n) => (n.id === noteId ? { ...n, isFavorite: newVal } : n))
    );
  };

  const handleTogglePin = async (noteId: string, e?: React.MouseEvent) => {
    e?.stopPropagation();
    const note = notes.find((n) => n.id === noteId);
    if (!note) return;

    const newVal = !note.isPinned;
    await db.notes.update(noteId, { isPinned: newVal });
    setNotes((prev) =>
      prev.map((n) => (n.id === noteId ? { ...n, isPinned: newVal } : n))
    );
  };

  const handleDuplicateNote = async (noteToDup: Note) => {
    const now = Date.now();
    const newNote: Note = {
      ...noteToDup,
      id: `note-${now}-${Math.random().toString(36).substring(2, 7)}`,
      title: `${noteToDup.title || 'Untitled'} (Copy)`,
      createdAt: now,
      updatedAt: now,
      isPinned: false,
    };

    await db.notes.add(newNote);

    // Duplicate tags
    const existingTags = noteTagsMap[noteToDup.id] || [];
    if (existingTags.length > 0) {
      await db.noteTags.bulkAdd(
        existingTags.map((tId) => ({ noteId: newNote.id, tagId: tId }))
      );
      setNoteTagsMap((prev) => ({
        ...prev,
        [newNote.id]: [...existingTags],
      }));
    }

    setNotes((prev) => [newNote, ...prev]);
    setActiveNoteId(newNote.id);
  };

  const handleArchiveNote = async (noteId: string) => {
    await db.notes.update(noteId, { isArchived: true, isPinned: false });
    setNotes((prev) =>
      prev.map((n) => (n.id === noteId ? { ...n, isArchived: true, isPinned: false } : n))
    );
  };

  const handleUnarchiveNote = async (noteId: string) => {
    await db.notes.update(noteId, { isArchived: false });
    setNotes((prev) =>
      prev.map((n) => (n.id === noteId ? { ...n, isArchived: false } : n))
    );
  };

  const handleTrashNote = async (noteId: string) => {
    const now = Date.now();
    await db.notes.update(noteId, {
      inTrash: true,
      trashedAt: now,
      isPinned: false,
    });
    setNotes((prev) =>
      prev.map((n) =>
        n.id === noteId
          ? { ...n, inTrash: true, trashedAt: now, isPinned: false }
          : n
      )
    );
  };

  const handleRestoreNote = async (noteId: string) => {
    await db.notes.update(noteId, { inTrash: false, trashedAt: null });
    setNotes((prev) =>
      prev.map((n) =>
        n.id === noteId ? { ...n, inTrash: false, trashedAt: null } : n
      )
    );
  };

  const handlePermanentDeleteNote = (noteToDelete: Note) => {
    setConfirmModalState({
      isOpen: true,
      title: 'Permanently Delete Note?',
      message: `Are you sure you want to permanently delete "${noteToDelete.title || 'Untitled'}"? This action cannot be recovered.`,
      confirmLabel: 'Delete Forever',
      onConfirm: async () => {
        await db.transaction('rw', [db.notes, db.noteTags], async () => {
          await db.notes.delete(noteToDelete.id);
          await db.noteTags.where('noteId').equals(noteToDelete.id).delete();
        });
        setNotes((prev) => prev.filter((n) => n.id !== noteToDelete.id));
        setNoteTagsMap((prev) => {
          const next = { ...prev };
          delete next[noteToDelete.id];
          return next;
        });
        if (activeNoteId === noteToDelete.id) {
          const nextActive = notes.find(
            (n) => n.id !== noteToDelete.id && !n.inTrash
          );
          setActiveNoteId(nextActive ? nextActive.id : null);
        }
        setConfirmModalState((prev) => ({ ...prev, isOpen: false }));
      },
    });
  };

  const handleEmptyTrash = () => {
    const trashCount = notes.filter((n) => n.inTrash).length;
    if (trashCount === 0) return;

    setConfirmModalState({
      isOpen: true,
      title: 'Empty Trash?',
      message: `Permanently delete all ${trashCount} notes currently in Trash? This cannot be undone.`,
      confirmLabel: 'Empty Trash',
      onConfirm: async () => {
        const trashIds = notes.filter((n) => n.inTrash).map((n) => n.id);
        await db.transaction('rw', [db.notes, db.noteTags], async () => {
          await db.notes.where('id').anyOf(trashIds).delete();
          await db.noteTags.where('noteId').anyOf(trashIds).delete();
        });
        setNotes((prev) => prev.filter((n) => !n.inTrash));
        if (activeNote && activeNote.inTrash) {
          setActiveNoteId(null);
        }
        setConfirmModalState((prev) => ({ ...prev, isOpen: false }));
      },
    });
  };

  // Drag and drop notes / folders
  const handleMoveNoteToFolder = async (noteId: string, folderId: string | null) => {
    await db.notes.update(noteId, { folderId });
    setNotes((prev) =>
      prev.map((n) => (n.id === noteId ? { ...n, folderId } : n))
    );
  };

  const handleMoveFolderToFolder = async (
    draggedFolderId: string,
    targetParentId: string | null
  ) => {
    if (draggedFolderId === targetParentId) return;
    // Check if target is a child of dragged
    const childIds = await getAllChildFolderIds(draggedFolderId);
    if (targetParentId && childIds.includes(targetParentId)) {
      alert('Cannot move a folder into its own subfolder.');
      return;
    }
    await db.folders.update(draggedFolderId, { parentId: targetParentId });
    setFolders((prev) =>
      prev.map((f) =>
        f.id === draggedFolderId ? { ...f, parentId: targetParentId } : f
      )
    );
  };

  // Folder modal saving
  const handleSaveFolder = async (data: {
    id?: string;
    name: string;
    parentId: string | null;
    color: string;
    icon: string;
    description: string;
  }) => {
    if (data.id) {
      await db.folders.update(data.id, data);
      setFolders((prev) =>
        prev.map((f) => (f.id === data.id ? { ...f, ...data } : f))
      );
    } else {
      const newFolder: Folder = {
        id: `folder-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        name: data.name,
        parentId: data.parentId,
        color: data.color,
        icon: data.icon,
        description: data.description,
        createdAt: Date.now(),
      };
      await db.folders.add(newFolder);
      setFolders((prev) => [...prev, newFolder]);
    }
  };

  const handleDeleteFolder = (folder: Folder) => {
    setConfirmModalState({
      isOpen: true,
      title: `Delete Folder "${folder.name}"?`,
      message: `Deleting this folder will move its notes to the root level. All subfolders will also be moved to the parent level.`,
      confirmLabel: 'Delete Folder',
      onConfirm: async () => {
        const childIds = await getAllChildFolderIds(folder.id);
        const allIdsToDelete = [folder.id, ...childIds];

        await db.transaction('rw', [db.folders, db.notes], async () => {
          // Reset folderId on notes that were in these folders
          const affectedNotes = await db.notes
            .where('folderId')
            .anyOf(allIdsToDelete)
            .toArray();
          for (const n of affectedNotes) {
            await db.notes.update(n.id, { folderId: null });
          }

          // Delete folders
          await db.folders.where('id').anyOf(allIdsToDelete).delete();
        });

        setFolders((prev) => prev.filter((f) => !allIdsToDelete.includes(f.id)));
        setNotes((prev) =>
          prev.map((n) =>
            n.folderId && allIdsToDelete.includes(n.folderId)
              ? { ...n, folderId: null }
              : n
          )
        );

        if (selectedFolderId && allIdsToDelete.includes(selectedFolderId)) {
          setSelectedFolderId(null);
        }
        setConfirmModalState((prev) => ({ ...prev, isOpen: false }));
      },
    });
  };

  const handleExportFolderNotes = (folder: Folder) => {
    const folderNotes = notes.filter(
      (n) => !n.inTrash && n.folderId === folder.id
    );
    downloadFolderNotesAsBundle(folder, folderNotes);
  };

  // Tag modal saving
  const handleSaveTag = async (data: { id?: string; name: string; color: string }) => {
    if (data.id) {
      await db.tags.update(data.id, data);
      setTags((prev) =>
        prev.map((t) => (t.id === data.id ? { ...t, ...data } : t))
      );
    } else {
      const newTag: Tag = {
        id: `tag-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        name: data.name,
        color: data.color,
      };
      await db.tags.add(newTag);
      setTags((prev) => [...prev, newTag]);
    }
  };

  const handleCreateTagQuick = async (name: string): Promise<Tag> => {
    const clean = name.trim().toLowerCase().replace(/\s+/g, '-');
    const existing = tags.find((t) => t.name.toLowerCase() === clean);
    if (existing) return existing;

    const newTag: Tag = {
      id: `tag-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      name: clean,
      color: '#B7B9BE',
    };
    await db.tags.add(newTag);
    setTags((prev) => [...prev, newTag]);
    return newTag;
  };

  const handleDeleteTag = (tag: Tag) => {
    setConfirmModalState({
      isOpen: true,
      title: `Delete Tag #${tag.name}?`,
      message: `Are you sure you want to delete this tag? It will be removed from all associated notes.`,
      confirmLabel: 'Delete Tag',
      onConfirm: async () => {
        await db.transaction('rw', [db.tags, db.noteTags], async () => {
          await db.tags.delete(tag.id);
          await db.noteTags.where('tagId').equals(tag.id).delete();
        });

        setTags((prev) => prev.filter((t) => t.id !== tag.id));
        setNoteTagsMap((prev) => {
          const next: Record<string, string[]> = {};
          for (const [nId, tIds] of Object.entries(prev)) {
            next[nId] = tIds.filter((id) => id !== tag.id);
          }
          return next;
        });

        if (selectedTagId === tag.id) {
          setSelectedTagId(null);
        }
        setConfirmModalState((prev) => ({ ...prev, isOpen: false }));
      },
    });
  };

  // Export note helpers
  const handleExportMarkdown = (note: Note) => {
    const folder = note.folderId ? folders.find((f) => f.id === note.folderId) : undefined;
    const tagNames = (noteTagsMap[note.id] || [])
      .map((tId) => tags.find((t) => t.id === tId)?.name)
      .filter(Boolean) as string[];
    downloadNoteAsMarkdown(note, tagNames, folder?.name);
  };

  const handleExportTxt = (note: Note) => {
    const folder = note.folderId ? folders.find((f) => f.id === note.folderId) : undefined;
    const tagNames = (noteTagsMap[note.id] || [])
      .map((tId) => tags.find((t) => t.id === tId)?.name)
      .filter(Boolean) as string[];
    downloadNoteAsTxt(note, tagNames, folder?.name);
  };

  // Settings update
  const handleUpdateSetting = async <K extends keyof AppSettings>(
    key: K,
    value: AppSettings[K]
  ) => {
    await saveSetting(key, value);
    setSettings((prev) => ({ ...prev, [key]: value }));
  };

  // Keyboard Shortcuts Hook
  useKeyboardShortcuts({
    onNewNote: handleCreateNewNote,
    onNewFolder: () => setFolderModalState({ isOpen: true, parentFolderId: null }),
    onSearch: () => setIsSearchOpen(true),
    onEscape: () => {
      setIsSearchOpen(false);
      setIsSettingsOpen(false);
      setFolderModalState({ isOpen: false });
      setTagModalState({ isOpen: false });
      setConfirmModalState((prev) => ({ ...prev, isOpen: false }));
      if (isFullscreenEditor) setIsFullscreenEditor(false);
    },
  });

  if (isLoading) {
    return (
      <div className="h-screen w-screen flex flex-col items-center justify-center bg-[#111214] text-[#F1F1F1] select-none">
        <div className="w-10 h-10 rounded-xl bg-[#202124] border border-[#303236] flex items-center justify-center font-bold text-sm tracking-wider animate-pulse mb-3">
          TN
        </div>
        <p className="text-xs font-mono text-[#92959B]">Loading TUMBA NOTES...</p>
      </div>
    );
  }

  return (
    <div className="flex h-screen w-screen bg-[#111214] text-[#F1F1F1] overflow-hidden">
      {/* 1. Left Sidebar (Collapsible Desktop + Mobile Drawer) */}
      <Sidebar
        currentSection={currentSection}
        selectedFolderId={selectedFolderId}
        selectedTagId={selectedTagId}
        notes={notes}
        folders={folders}
        tags={tags}
        noteTagsMap={noteTagsMap}
        isCollapsed={isSidebarCollapsed}
        isMobileOpen={isMobileDrawerOpen}
        onToggleCollapse={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
        onCloseMobile={() => setIsMobileDrawerOpen(false)}
        onSelectSection={(sec) => {
          setCurrentSection(sec);
          setSelectedFolderId(null);
          setSelectedTagId(null);
          setMobileViewMode('list');
        }}
        onSelectFolder={(fId) => {
          setSelectedFolderId(fId);
          setSelectedTagId(null);
          setCurrentSection('folder');
          setMobileViewMode('list');
        }}
        onSelectTag={(tId) => {
          setSelectedTagId(tId);
          setSelectedFolderId(null);
          setCurrentSection('tag');
          setMobileViewMode('list');
        }}
        onNewNote={handleCreateNewNote}
        onNewFolder={(parentId) =>
          setFolderModalState({ isOpen: true, parentFolderId: parentId })
        }
        onEditFolder={(folder) =>
          setFolderModalState({ isOpen: true, folderToEdit: folder })
        }
        onDeleteFolder={handleDeleteFolder}
        onExportFolder={handleExportFolderNotes}
        onNewTag={() => setTagModalState({ isOpen: true })}
        onEditTag={(tag) => setTagModalState({ isOpen: true, tagToEdit: tag })}
        onDeleteTag={handleDeleteTag}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenSearch={() => setIsSearchOpen(true)}
        onMoveNoteToFolder={handleMoveNoteToFolder}
        onMoveFolderToFolder={handleMoveFolderToFolder}
      />

      {/* 2. Main Content Area */}
      <div className="flex-1 flex flex-col md:flex-row h-full overflow-hidden relative">
        {/* Mobile top bar for navigation toggling */}
        <div className="md:hidden flex items-center justify-between px-4 py-2.5 bg-[#161719] border-b border-[#303236]">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsMobileDrawerOpen(true)}
              className="p-1.5 rounded-lg bg-[#202124] border border-[#303236] text-[#F1F1F1]"
              title="Open Navigation"
            >
              <Menu className="w-4 h-4" />
            </button>
            <span className="text-xs font-bold tracking-wider">TUMBA NOTES</span>
          </div>

          {currentSection !== 'home' && mobileViewMode === 'editor' && (
            <button
              onClick={() => setMobileViewMode('list')}
              className="flex items-center gap-1 text-xs text-[#B7B9BE] bg-[#202124] px-2.5 py-1 rounded-lg border border-[#303236]"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Notes List</span>
            </button>
          )}
        </div>

        {/* Home Dashboard View */}
        {currentSection === 'home' ? (
          <Dashboard
            notes={notes}
            folders={folders}
            tags={tags}
            noteTagsMap={noteTagsMap}
            onSelectNote={(nId) => {
              setActiveNoteId(nId);
              setCurrentSection('all');
              setMobileViewMode('editor');
            }}
            onSelectFolder={(fId) => {
              setSelectedFolderId(fId);
              setCurrentSection('folder');
              setMobileViewMode('list');
            }}
            onNewNote={handleCreateNewNote}
            onNewFolder={() =>
              setFolderModalState({ isOpen: true, parentFolderId: null })
            }
            onViewSection={(sec) => {
              setCurrentSection(sec);
              setSelectedFolderId(null);
              setSelectedTagId(null);
              setMobileViewMode('list');
            }}
          />
        ) : (
          <>
            {/* Center Panel: Notes List (hidden on mobile when editor is active) */}
            <div
              className={`${
                mobileViewMode === 'editor' ? 'hidden md:flex' : 'flex'
              } h-full md:border-r border-[#303236] w-full md:w-auto`}
            >
              <NoteList
                currentSection={currentSection}
                selectedFolder={selectedFolder}
                selectedTag={selectedTag}
                notes={notes}
                folders={folders}
                tags={tags}
                noteTagsMap={noteTagsMap}
                activeNoteId={activeNoteId}
                isCompactMode={settings.compactMode}
                onSelectNote={handleSelectNote}
                onNewNote={handleCreateNewNote}
                onToggleFavorite={handleToggleFavorite}
                onTogglePin={handleTogglePin}
                onDuplicateNote={handleDuplicateNote}
                onArchiveNote={handleArchiveNote}
                onUnarchiveNote={handleUnarchiveNote}
                onTrashNote={handleTrashNote}
                onRestoreNote={handleRestoreNote}
                onPermanentDeleteNote={handlePermanentDeleteNote}
                onEmptyTrash={handleEmptyTrash}
              />
            </div>

            {/* Right Panel: Note Editor (hidden on mobile when list is active) */}
            <div
              className={`${
                mobileViewMode === 'list' ? 'hidden md:flex' : 'flex'
              } flex-1 h-full`}
            >
              <NoteEditor
                note={activeNote}
                folders={folders}
                tags={tags}
                noteTagIds={activeNote ? noteTagsMap[activeNote.id] || [] : []}
                settings={settings}
                isFullscreen={isFullscreenEditor}
                onToggleFullscreen={() =>
                  setIsFullscreenEditor(!isFullscreenEditor)
                }
                onSaveNote={handleSaveNote}
                onUpdateNoteTags={handleUpdateNoteTags}
                onToggleFavorite={handleToggleFavorite}
                onTogglePin={handleTogglePin}
                onDuplicateNote={handleDuplicateNote}
                onArchiveNote={handleArchiveNote}
                onUnarchiveNote={handleUnarchiveNote}
                onTrashNote={handleTrashNote}
                onRestoreNote={handleRestoreNote}
                onPermanentDeleteNote={handlePermanentDeleteNote}
                onExportMarkdown={handleExportMarkdown}
                onExportTxt={handleExportTxt}
                onCreateTagQuick={handleCreateTagQuick}
                onNewNote={handleCreateNewNote}
              />
            </div>
          </>
        )}
      </div>

      {/* 3. Mobile 5-tab Bottom Navigation */}
      <MobileBottomNav
        currentSection={currentSection}
        onSelectSection={(sec) => {
          setCurrentSection(sec);
          setSelectedFolderId(null);
          setSelectedTagId(null);
          setMobileViewMode(sec === 'home' ? 'list' : 'list');
        }}
        onOpenMobileFolders={() => setIsMobileDrawerOpen(true)}
        onOpenSettings={() => setIsSettingsOpen(true)}
      />

      {/* 4. Global Omni Search Modal (Ctrl+K) */}
      <SearchModal
        isOpen={isSearchOpen}
        notes={notes}
        folders={folders}
        tags={tags}
        noteTagsMap={noteTagsMap}
        onSelectNote={(nId) => {
          setActiveNoteId(nId);
          setMobileViewMode('editor');
        }}
        onClose={() => setIsSearchOpen(false)}
      />

      {/* 5. Folder Create/Edit Modal */}
      <FolderModal
        isOpen={folderModalState.isOpen}
        folderToEdit={folderModalState.folderToEdit}
        parentFolderId={folderModalState.parentFolderId}
        existingFolders={folders}
        onSave={handleSaveFolder}
        onClose={() => setFolderModalState({ isOpen: false })}
      />

      {/* 6. Tag Create/Edit Modal */}
      <TagModal
        isOpen={tagModalState.isOpen}
        tagToEdit={tagModalState.tagToEdit}
        onSave={handleSaveTag}
        onClose={() => setTagModalState({ isOpen: false })}
      />

      {/* 7. Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        settings={settings}
        onUpdateSetting={handleUpdateSetting}
        onClose={() => setIsSettingsOpen(false)}
        onDataReset={loadDatabaseData}
      />

      {/* 8. Destructive Action Confirmation Modal */}
      <ConfirmModal
        isOpen={confirmModalState.isOpen}
        title={confirmModalState.title}
        message={confirmModalState.message}
        confirmLabel={confirmModalState.confirmLabel}
        onConfirm={confirmModalState.onConfirm}
        onCancel={() =>
          setConfirmModalState((prev) => ({ ...prev, isOpen: false }))
        }
      />
    </div>
  );
}
