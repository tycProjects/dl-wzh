/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useMemo } from 'react';
import {
  FileText,
  Folder as FolderIcon,
  Tag as TagIcon,
  Star,
  Archive,
  Trash2,
  Plus,
  Clock,
  Pin,
  ArrowRight,
  Sparkles,
} from 'lucide-react';
import type { Note, Folder, Tag } from '../types';
import { formatDate, stripHtml } from '../utils/textUtils';
import { FOLDER_ICONS } from './FolderModal';

interface DashboardProps {
  notes: Note[];
  folders: Folder[];
  tags: Tag[];
  noteTagsMap: Record<string, string[]>;
  onSelectNote: (noteId: string) => void;
  onSelectFolder: (folderId: string) => void;
  onNewNote: () => void;
  onNewFolder: () => void;
  onViewSection: (section: 'all' | 'favorites' | 'recent' | 'archive' | 'trash') => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  notes,
  folders,
  tags,
  noteTagsMap,
  onSelectNote,
  onSelectFolder,
  onNewNote,
  onNewFolder,
  onViewSection,
}) => {
  // Real database calculations
  const stats = useMemo(() => {
    let totalNotes = 0;
    let favorites = 0;
    let archived = 0;
    let trash = 0;

    notes.forEach((n) => {
      if (n.inTrash) {
        trash++;
      } else if (n.isArchived) {
        archived++;
      } else {
        totalNotes++;
        if (n.isFavorite) favorites++;
      }
    });

    return {
      totalNotes,
      totalFolders: folders.length,
      totalTags: tags.length,
      favorites,
      archived,
      trash,
    };
  }, [notes, folders.length, tags.length]);

  // Folder note counts
  const folderCounts = useMemo(() => {
    const map: Record<string, number> = {};
    notes.forEach((n) => {
      if (!n.inTrash && n.folderId) {
        map[n.folderId] = (map[n.folderId] || 0) + 1;
      }
    });
    return map;
  }, [notes]);

  // Recently edited active notes (top 5)
  const recentlyEdited = useMemo(() => {
    return notes
      .filter((n) => !n.inTrash && !n.isArchived)
      .sort((a, b) => b.updatedAt - a.updatedAt)
      .slice(0, 5);
  }, [notes]);

  // Pinned / favorite notes
  const pinnedOrStarred = useMemo(() => {
    return notes
      .filter((n) => !n.inTrash && !n.isArchived && (n.isPinned || n.isFavorite))
      .sort((a, b) => (b.isPinned ? 1 : 0) - (a.isPinned ? 1 : 0) || b.updatedAt - a.updatedAt)
      .slice(0, 4);
  }, [notes]);

  // Top folders (up to 6)
  const topFolders = useMemo(() => {
    return [...folders]
      .sort((a, b) => (folderCounts[b.id] || 0) - (folderCounts[a.id] || 0))
      .slice(0, 6);
  }, [folders, folderCounts]);

  const folderMap = useMemo(() => {
    const map = new Map<string, Folder>();
    folders.forEach((f) => map.set(f.id, f));
    return map;
  }, [folders]);

  return (
    <div className="flex-1 h-full overflow-y-auto bg-[#111214] text-[#F1F1F1] p-6 md:p-10 select-none">
      <div className="max-w-5xl mx-auto space-y-8">
        {/* Welcome Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-[#303236]">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs uppercase font-mono tracking-widest text-[#92959B]">
                Personal Knowledge Base
              </span>
            </div>
            <h1 className="text-2xl md:text-3xl font-bold tracking-tight text-[#F1F1F1]">
              TUMBA NOTES Dashboard
            </h1>
            <p className="text-xs text-[#92959B] mt-1">
              All data is stored directly in your browser&apos;s IndexedDB. 100% offline and secure.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={onNewFolder}
              className="px-3 py-2 text-xs font-medium rounded-lg border border-[#303236] bg-[#191A1D] hover:bg-[#202124] text-[#F1F1F1] transition flex items-center gap-1.5"
            >
              <FolderIcon className="w-3.5 h-3.5 text-[#B7B9BE]" />
              <span>New Folder</span>
            </button>
            <button
              onClick={onNewNote}
              className="px-4 py-2 text-xs font-semibold rounded-lg bg-[#F1F1F1] hover:bg-white text-[#111214] transition shadow-xs flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4 stroke-[2.5]" />
              <span>Create Note</span>
            </button>
          </div>
        </div>

        {/* Real Metrics Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          <div
            onClick={() => onViewSection('all')}
            className="p-4 rounded-xl bg-[#191A1D] border border-[#303236] hover:border-[#B7B9BE] transition cursor-pointer group"
          >
            <div className="flex items-center justify-between text-[#92959B] mb-2">
              <span className="text-[11px] font-medium uppercase tracking-wider">Notes</span>
              <FileText className="w-4 h-4 text-[#B7B9BE]" />
            </div>
            <div className="text-2xl font-bold font-mono text-[#F1F1F1]">
              {stats.totalNotes}
            </div>
            <span className="text-[10px] text-[#63666E]">Active notes</span>
          </div>

          <div className="p-4 rounded-xl bg-[#191A1D] border border-[#303236]">
            <div className="flex items-center justify-between text-[#92959B] mb-2">
              <span className="text-[11px] font-medium uppercase tracking-wider">Folders</span>
              <FolderIcon className="w-4 h-4 text-[#B7B9BE]" />
            </div>
            <div className="text-2xl font-bold font-mono text-[#F1F1F1]">
              {stats.totalFolders}
            </div>
            <span className="text-[10px] text-[#63666E]">Hierarchical</span>
          </div>

          <div className="p-4 rounded-xl bg-[#191A1D] border border-[#303236]">
            <div className="flex items-center justify-between text-[#92959B] mb-2">
              <span className="text-[11px] font-medium uppercase tracking-wider">Tags</span>
              <TagIcon className="w-4 h-4 text-[#B7B9BE]" />
            </div>
            <div className="text-2xl font-bold font-mono text-[#F1F1F1]">
              {stats.totalTags}
            </div>
            <span className="text-[10px] text-[#63666E]">Labels created</span>
          </div>

          <div
            onClick={() => onViewSection('favorites')}
            className="p-4 rounded-xl bg-[#191A1D] border border-[#303236] hover:border-[#B7B9BE] transition cursor-pointer"
          >
            <div className="flex items-center justify-between text-[#92959B] mb-2">
              <span className="text-[11px] font-medium uppercase tracking-wider">Favorites</span>
              <Star className="w-4 h-4 text-[#D4AF37] fill-current" />
            </div>
            <div className="text-2xl font-bold font-mono text-[#F1F1F1]">
              {stats.favorites}
            </div>
            <span className="text-[10px] text-[#63666E]">Starred</span>
          </div>

          <div
            onClick={() => onViewSection('archive')}
            className="p-4 rounded-xl bg-[#191A1D] border border-[#303236] hover:border-[#B7B9BE] transition cursor-pointer"
          >
            <div className="flex items-center justify-between text-[#92959B] mb-2">
              <span className="text-[11px] font-medium uppercase tracking-wider">Archive</span>
              <Archive className="w-4 h-4 text-[#92959B]" />
            </div>
            <div className="text-2xl font-bold font-mono text-[#F1F1F1]">
              {stats.archived}
            </div>
            <span className="text-[10px] text-[#63666E]">Preserved</span>
          </div>

          <div
            onClick={() => onViewSection('trash')}
            className="p-4 rounded-xl bg-[#191A1D] border border-[#303236] hover:border-red-500/50 transition cursor-pointer"
          >
            <div className="flex items-center justify-between text-[#92959B] mb-2">
              <span className="text-[11px] font-medium uppercase tracking-wider">Trash</span>
              <Trash2 className="w-4 h-4 text-red-400" />
            </div>
            <div className="text-2xl font-bold font-mono text-[#F1F1F1]">
              {stats.trash}
            </div>
            <span className="text-[10px] text-[#63666E]">In bin</span>
          </div>
        </div>

        {/* Quick Folders Section */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-semibold uppercase tracking-wider text-[#92959B]">
              Quick Access Folders
            </h2>
            <button
              onClick={onNewFolder}
              className="text-xs text-[#B7B9BE] hover:text-[#F1F1F1] transition"
            >
              + Add Folder
            </button>
          </div>

          {topFolders.length === 0 ? (
            <div className="p-6 rounded-xl border border-[#303236] bg-[#191A1D] text-center text-xs text-[#63666E]">
              No folders yet. Click &quot;Add Folder&quot; to organize notes.
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
              {topFolders.map((f) => {
                const IconComp = FOLDER_ICONS[f.icon] || FolderIcon;
                const count = folderCounts[f.id] || 0;

                return (
                  <div
                    key={f.id}
                    onClick={() => onSelectFolder(f.id)}
                    className="p-3.5 rounded-xl bg-[#191A1D] border border-[#303236] hover:bg-[#202124] hover:border-[#B7B9BE] transition cursor-pointer flex flex-col justify-between"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span style={{ color: f.color || '#8E9096' }}>
                        <IconComp className="w-4 h-4" />
                      </span>
                      <span className="text-[10px] font-mono text-[#63666E]">
                        {count} notes
                      </span>
                    </div>
                    <span className="text-xs font-semibold text-[#F1F1F1] truncate">
                      {f.name}
                    </span>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Two Column Layout: Recently Edited & Key Pinned Notes */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Recently Edited */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-sm font-semibold uppercase tracking-wider text-[#92959B]">
                <Clock className="w-4 h-4" />
                <span>Recently Edited</span>
              </div>
              <button
                onClick={() => onViewSection('recent')}
                className="text-xs text-[#B7B9BE] hover:text-[#F1F1F1] flex items-center gap-1"
              >
                <span>View all</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>

            {recentlyEdited.length === 0 ? (
              <div className="p-8 rounded-xl border border-[#303236] bg-[#191A1D] text-center text-xs text-[#63666E]">
                No notes created yet.
              </div>
            ) : (
              <div className="space-y-2">
                {recentlyEdited.map((note) => {
                  const folder = note.folderId ? folderMap.get(note.folderId) : null;
                  const snippet = stripHtml(note.content).slice(0, 90);

                  return (
                    <div
                      key={note.id}
                      onClick={() => onSelectNote(note.id)}
                      className="p-3 rounded-xl bg-[#191A1D] border border-[#303236] hover:bg-[#202124] hover:border-[#4A4D53] transition cursor-pointer"
                    >
                      <div className="flex items-center justify-between gap-2 mb-1">
                        <h4 className="text-xs font-semibold text-[#F1F1F1] truncate">
                          {note.title || 'Untitled Note'}
                        </h4>
                        <span className="text-[10px] text-[#63666E] shrink-0">
                          {formatDate(note.updatedAt)}
                        </span>
                      </div>
                      <p className="text-[11px] text-[#92959B] truncate leading-relaxed">
                        {snippet || '(No content)'}
                      </p>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Key Pinned & Favorites */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-sm font-semibold uppercase tracking-wider text-[#92959B]">
                <Star className="w-4 h-4 text-[#D4AF37] fill-current" />
                <span>Pinned &amp; Favorites</span>
              </div>
              <button
                onClick={() => onViewSection('favorites')}
                className="text-xs text-[#B7B9BE] hover:text-[#F1F1F1] flex items-center gap-1"
              >
                <span>View all</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>

            {pinnedOrStarred.length === 0 ? (
              <div className="p-8 rounded-xl border border-[#303236] bg-[#191A1D] text-center text-xs text-[#63666E]">
                Pin or star important notes to keep them pinned here.
              </div>
            ) : (
              <div className="space-y-2">
                {pinnedOrStarred.map((note) => {
                  const folder = note.folderId ? folderMap.get(note.folderId) : null;
                  const snippet = stripHtml(note.content).slice(0, 90);

                  return (
                    <div
                      key={note.id}
                      onClick={() => onSelectNote(note.id)}
                      className="p-3 rounded-xl bg-[#191A1D] border border-[#303236] hover:bg-[#202124] hover:border-[#4A4D53] transition cursor-pointer"
                    >
                      <div className="flex items-center justify-between gap-2 mb-1">
                        <div className="flex items-center gap-1.5 min-w-0 flex-1">
                          {note.isPinned && (
                            <Pin className="w-3 h-3 text-[#B7B9BE] fill-current shrink-0" />
                          )}
                          {note.isFavorite && (
                            <Star className="w-3 h-3 text-[#D4AF37] fill-current shrink-0" />
                          )}
                          <h4 className="text-xs font-semibold text-[#F1F1F1] truncate">
                            {note.title || 'Untitled Note'}
                          </h4>
                        </div>
                        <span className="text-[10px] text-[#63666E] shrink-0">
                          {formatDate(note.updatedAt)}
                        </span>
                      </div>
                      <p className="text-[11px] text-[#92959B] truncate leading-relaxed">
                        {snippet || '(No content)'}
                      </p>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
