/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  Folder as FolderIcon,
  BookOpen,
  Code,
  Lightbulb,
  Target,
  Briefcase,
  Layers,
  Bookmark,
  Archive,
  Terminal,
  Globe,
  FileText,
  Heart,
  X,
  Check,
} from 'lucide-react';
import type { Folder } from '../types';

interface FolderModalProps {
  isOpen: boolean;
  folderToEdit?: Folder | null;
  parentFolderId?: string | null;
  existingFolders: Folder[];
  onSave: (folderData: {
    id?: string;
    name: string;
    parentId: string | null;
    color: string;
    icon: string;
    description: string;
  }) => Promise<void>;
  onClose: () => void;
}

export const FOLDER_ICONS: Record<string, React.FC<{ className?: string }>> = {
  folder: FolderIcon,
  'book-open': BookOpen,
  code: Code,
  lightbulb: Lightbulb,
  target: Target,
  briefcase: Briefcase,
  layers: Layers,
  bookmark: Bookmark,
  archive: Archive,
  terminal: Terminal,
  globe: Globe,
  'file-text': FileText,
  heart: Heart,
};

export const FOLDER_COLORS = [
  '#B7B9BE', // Light Graphite
  '#8E9096', // Medium Graphite
  '#63666E', // Deep Slate
  '#4A4D53', // Charcoal
  '#D4AF37', // Muted Gold accent
  '#93C5FD', // Ice Blue
  '#A7F3D0', // Sage
  '#FCA5A5', // Dusty Rose
];

export const FolderModal: React.FC<FolderModalProps> = ({
  isOpen,
  folderToEdit,
  parentFolderId = null,
  existingFolders,
  onSave,
  onClose,
}) => {
  const [name, setName] = useState('');
  const [parentId, setParentId] = useState<string | null>(null);
  const [color, setColor] = useState('#8E9096');
  const [icon, setIcon] = useState('folder');
  const [description, setDescription] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (folderToEdit) {
      setName(folderToEdit.name);
      setParentId(folderToEdit.parentId);
      setColor(folderToEdit.color || '#8E9096');
      setIcon(folderToEdit.icon || 'folder');
      setDescription(folderToEdit.description || '');
    } else {
      setName('');
      setParentId(parentFolderId);
      setColor('#8E9096');
      setIcon('folder');
      setDescription('');
    }
    setError('');
  }, [folderToEdit, parentFolderId, isOpen]);

  if (!isOpen) return null;

  // Filter out current folder and its children to prevent circular reference
  const validParentOptions = existingFolders.filter((f) => {
    if (!folderToEdit) return true;
    if (f.id === folderToEdit.id) return false;
    if (f.parentId === folderToEdit.id) return false;
    return true;
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = name.trim();
    if (!trimmed) {
      setError('Folder name is required.');
      return;
    }

    try {
      setIsSubmitting(true);
      await onSave({
        id: folderToEdit?.id,
        name: trimmed,
        parentId: parentId || null,
        color,
        icon,
        description: description.trim(),
      });
      onClose();
    } catch (err: any) {
      setError(err?.message || 'Failed to save folder.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="w-full max-w-lg bg-[#191A1D] border border-[#303236] rounded-xl shadow-2xl p-6 text-[#F1F1F1] max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-4 border-b border-[#303236] mb-5">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-[#202124] text-[#B7B9BE]">
              <FolderIcon className="w-4 h-4" />
            </div>
            <h3 className="text-base font-semibold tracking-tight">
              {folderToEdit ? 'Edit Folder' : 'Create New Folder'}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="text-[#92959B] hover:text-[#F1F1F1] p-1 rounded-md transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-red-500/10 border border-red-500/30 rounded-lg text-xs text-red-400">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-[#92959B] mb-1.5 uppercase tracking-wider">
              Folder Name
            </label>
            <input
              type="text"
              required
              autoFocus
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Daily Journal, Web Development"
              className="w-full px-3 py-2 text-sm bg-[#202124] border border-[#303236] rounded-lg text-[#F1F1F1] placeholder-[#63666E] focus:outline-none focus:border-[#B7B9BE] transition"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-[#92959B] mb-1.5 uppercase tracking-wider">
              Parent Folder (Optional)
            </label>
            <select
              value={parentId || ''}
              onChange={(e) => setParentId(e.target.value ? e.target.value : null)}
              className="w-full px-3 py-2 text-sm bg-[#202124] border border-[#303236] rounded-lg text-[#F1F1F1] focus:outline-none focus:border-[#B7B9BE] transition cursor-pointer"
            >
              <option value="">(None — Top-level Root Folder)</option>
              {validParentOptions.map((f) => (
                <option key={f.id} value={f.id}>
                  📁 {f.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-[#92959B] mb-1.5 uppercase tracking-wider">
              Description (Optional)
            </label>
            <input
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Short notes or purpose"
              className="w-full px-3 py-2 text-sm bg-[#202124] border border-[#303236] rounded-lg text-[#F1F1F1] placeholder-[#63666E] focus:outline-none focus:border-[#B7B9BE] transition"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-[#92959B] mb-2 uppercase tracking-wider">
              Icon
            </label>
            <div className="grid grid-cols-7 gap-2">
              {Object.entries(FOLDER_ICONS).map(([key, IconComponent]) => {
                const isSelected = icon === key;
                return (
                  <button
                    key={key}
                    type="button"
                    onClick={() => setIcon(key)}
                    className={`flex items-center justify-center p-2.5 rounded-lg border transition ${
                      isSelected
                        ? 'border-[#B7B9BE] bg-[#26282C] text-[#F1F1F1]'
                        : 'border-[#303236] bg-[#202124] text-[#92959B] hover:text-[#F1F1F1] hover:bg-[#26282C]'
                    }`}
                    title={key}
                  >
                    <IconComponent className="w-4 h-4" />
                  </button>
                );
              })}
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-[#92959B] mb-2 uppercase tracking-wider">
              Color Accent
            </label>
            <div className="flex items-center gap-2.5">
              {FOLDER_COLORS.map((c) => {
                const isSelected = color === c;
                return (
                  <button
                    key={c}
                    type="button"
                    onClick={() => setColor(c)}
                    className="w-7 h-7 rounded-full flex items-center justify-center transition border-2"
                    style={{
                      backgroundColor: c,
                      borderColor: isSelected ? '#F1F1F1' : 'transparent',
                    }}
                  >
                    {isSelected && <Check className="w-3.5 h-3.5 text-[#111214]" />}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-[#303236]">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium rounded-lg border border-[#303236] bg-[#202124] text-[#F1F1F1] hover:bg-[#26282C] transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-4 py-2 text-xs font-medium rounded-lg bg-[#F1F1F1] hover:bg-white text-[#111214] transition disabled:opacity-50"
            >
              {isSubmitting ? 'Saving...' : folderToEdit ? 'Update Folder' : 'Create Folder'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
