/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import {
  ChevronRight,
  ChevronDown,
  Folder as FolderIcon,
  Plus,
  MoreVertical,
  Edit2,
  Trash2,
  Download,
} from 'lucide-react';
import type { Folder, Note } from '../types';
import { FOLDER_ICONS } from './FolderModal';

interface FolderNode extends Folder {
  children: FolderNode[];
}

interface FolderTreeProps {
  folders: Folder[];
  notes: Note[];
  selectedFolderId: string | null;
  onSelectFolder: (folderId: string | null) => void;
  onCreateSubfolder: (parentFolderId: string) => void;
  onEditFolder: (folder: Folder) => void;
  onDeleteFolder: (folder: Folder) => void;
  onExportFolder: (folder: Folder) => void;
  onMoveNoteToFolder?: (noteId: string, folderId: string | null) => void;
  onMoveFolderToFolder?: (draggedFolderId: string, targetParentId: string | null) => void;
}

export const FolderTree: React.FC<FolderTreeProps> = ({
  folders,
  notes,
  selectedFolderId,
  onSelectFolder,
  onCreateSubfolder,
  onEditFolder,
  onDeleteFolder,
  onExportFolder,
  onMoveNoteToFolder,
  onMoveFolderToFolder,
}) => {
  const [expandedFolders, setExpandedFolders] = useState<Record<string, boolean>>(() => {
    // Expand root folders by default
    const map: Record<string, boolean> = {};
    folders.forEach((f) => {
      map[f.id] = true;
    });
    return map;
  });

  const [activeMenuFolderId, setActiveMenuFolderId] = useState<string | null>(null);
  const [dragOverFolderId, setDragOverFolderId] = useState<string | null>(null);

  // Compute note counts per folder (excluding trash)
  const folderNoteCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    notes.forEach((note) => {
      if (!note.inTrash && note.folderId) {
        counts[note.folderId] = (counts[note.folderId] || 0) + 1;
      }
    });
    return counts;
  }, [notes]);

  // Build tree
  const tree = useMemo(() => {
    const map = new Map<string, FolderNode>();
    const roots: FolderNode[] = [];

    folders.forEach((f) => {
      map.set(f.id, { ...f, children: [] });
    });

    folders.forEach((f) => {
      const node = map.get(f.id)!;
      if (f.parentId && map.has(f.parentId)) {
        map.get(f.parentId)!.children.push(node);
      } else {
        roots.push(node);
      }
    });

    // Sort folders alphabetically
    const sortNodes = (nodes: FolderNode[]) => {
      nodes.sort((a, b) => a.name.localeCompare(b.name));
      nodes.forEach((n) => sortNodes(n.children));
    };
    sortNodes(roots);

    return roots;
  }, [folders]);

  const toggleExpand = (folderId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setExpandedFolders((prev) => ({
      ...prev,
      [folderId]: !prev[folderId],
    }));
  };

  // Drag and drop handlers
  const handleDragOver = (e: React.DragEvent, folderId: string) => {
    e.preventDefault();
    e.stopPropagation();
    setDragOverFolderId(folderId);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragOverFolderId(null);
  };

  const handleDrop = (e: React.DragEvent, targetFolderId: string) => {
    e.preventDefault();
    e.stopPropagation();
    setDragOverFolderId(null);

    const noteId = e.dataTransfer.getData('text/tumba-note-id');
    const folderId = e.dataTransfer.getData('text/tumba-folder-id');

    if (noteId && onMoveNoteToFolder) {
      onMoveNoteToFolder(noteId, targetFolderId);
    } else if (folderId && folderId !== targetFolderId && onMoveFolderToFolder) {
      onMoveFolderToFolder(folderId, targetFolderId);
    }
  };

  const handleFolderDragStart = (e: React.DragEvent, folderId: string) => {
    e.dataTransfer.setData('text/tumba-folder-id', folderId);
  };

  const renderFolderItem = (node: FolderNode, depth: number = 0) => {
    const isExpanded = !!expandedFolders[node.id];
    const isSelected = selectedFolderId === node.id;
    const isDragOver = dragOverFolderId === node.id;
    const count = folderNoteCounts[node.id] || 0;
    const hasChildren = node.children.length > 0;
    const IconComp = FOLDER_ICONS[node.icon] || FolderIcon;

    return (
      <div key={node.id} className="select-none">
        <div
          draggable
          onDragStart={(e) => handleFolderDragStart(e, node.id)}
          onDragOver={(e) => handleDragOver(e, node.id)}
          onDragLeave={handleDragLeave}
          onDrop={(e) => handleDrop(e, node.id)}
          onClick={() => onSelectFolder(node.id)}
          style={{ paddingLeft: `${depth * 12 + 8}px` }}
          className={`group flex items-center justify-between py-1.5 pr-2 rounded-lg text-xs font-medium cursor-pointer transition relative ${
            isSelected
              ? 'bg-[#202124] text-[#F1F1F1] border-l-2 border-[#B7B9BE]'
              : 'text-[#92959B] hover:bg-[#1E2024] hover:text-[#F1F1F1]'
          } ${isDragOver ? 'ring-2 ring-[#B7B9BE] bg-[#26282C]' : ''}`}
        >
          <div className="flex items-center gap-1.5 min-w-0 flex-1">
            {hasChildren ? (
              <button
                type="button"
                onClick={(e) => toggleExpand(node.id, e)}
                className="p-0.5 hover:text-[#F1F1F1] text-[#63666E] rounded"
              >
                {isExpanded ? (
                  <ChevronDown className="w-3.5 h-3.5" />
                ) : (
                  <ChevronRight className="w-3.5 h-3.5" />
                )}
              </button>
            ) : (
              <span className="w-3.5 h-3.5 shrink-0" />
            )}

            <span style={{ color: node.color || '#8E9096' }} className="shrink-0">
              <IconComp className="w-3.5 h-3.5" />
            </span>

            <span className="truncate flex-1" title={node.description || node.name}>
              {node.name}
            </span>
          </div>

          <div className="flex items-center gap-1">
            <span className="text-[10px] text-[#63666E] font-mono px-1">
              {count}
            </span>

            {/* Quick Actions Menu Trigger */}
            <div className="relative">
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setActiveMenuFolderId(activeMenuFolderId === node.id ? null : node.id);
                }}
                className="p-1 rounded opacity-0 group-hover:opacity-100 hover:bg-[#2A2C31] text-[#92959B] hover:text-[#F1F1F1] transition"
                title="Folder actions"
              >
                <MoreVertical className="w-3 h-3" />
              </button>

              {activeMenuFolderId === node.id && (
                <div
                  onClick={(e) => e.stopPropagation()}
                  className="absolute right-0 top-6 z-30 w-36 bg-[#191A1D] border border-[#303236] rounded-lg shadow-xl py-1 text-xs"
                >
                  <button
                    onClick={() => {
                      setActiveMenuFolderId(null);
                      onCreateSubfolder(node.id);
                    }}
                    className="w-full flex items-center gap-2 px-3 py-1.5 text-left text-[#92959B] hover:text-[#F1F1F1] hover:bg-[#202124]"
                  >
                    <Plus className="w-3 h-3" />
                    <span>New Subfolder</span>
                  </button>
                  <button
                    onClick={() => {
                      setActiveMenuFolderId(null);
                      onEditFolder(node);
                    }}
                    className="w-full flex items-center gap-2 px-3 py-1.5 text-left text-[#92959B] hover:text-[#F1F1F1] hover:bg-[#202124]"
                  >
                    <Edit2 className="w-3 h-3" />
                    <span>Rename / Edit</span>
                  </button>
                  <button
                    onClick={() => {
                      setActiveMenuFolderId(null);
                      onExportFolder(node);
                    }}
                    className="w-full flex items-center gap-2 px-3 py-1.5 text-left text-[#92959B] hover:text-[#F1F1F1] hover:bg-[#202124]"
                  >
                    <Download className="w-3 h-3" />
                    <span>Export Notes</span>
                  </button>
                  <button
                    onClick={() => {
                      setActiveMenuFolderId(null);
                      onDeleteFolder(node);
                    }}
                    className="w-full flex items-center gap-2 px-3 py-1.5 text-left text-red-400 hover:bg-red-500/10"
                  >
                    <Trash2 className="w-3 h-3" />
                    <span>Delete Folder</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>

        {hasChildren && isExpanded && (
          <div className="space-y-0.5 mt-0.5">
            {node.children.map((child) => renderFolderItem(child, depth + 1))}
          </div>
        )}
      </div>
    );
  };

  return (
    <div
      className="space-y-0.5"
      onClick={() => setActiveMenuFolderId(null)}
    >
      {tree.length === 0 ? (
        <div className="px-3 py-2 text-xs text-[#63666E] italic">
          No folders created yet.
        </div>
      ) : (
        tree.map((node) => renderFolderItem(node, 0))
      )}
    </div>
  );
};
