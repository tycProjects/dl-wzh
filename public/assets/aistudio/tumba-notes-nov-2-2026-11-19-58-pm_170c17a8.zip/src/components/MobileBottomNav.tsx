/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Home, FileText, Folder as FolderIcon, Star, Settings } from 'lucide-react';
import type { ViewSection } from '../types';

interface MobileBottomNavProps {
  currentSection: ViewSection;
  onSelectSection: (section: ViewSection) => void;
  onOpenMobileFolders: () => void;
  onOpenSettings: () => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  currentSection,
  onSelectSection,
  onOpenMobileFolders,
  onOpenSettings,
}) => {
  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#161719] border-t border-[#303236] px-2 py-1.5 flex items-center justify-around select-none">
      <button
        onClick={() => onSelectSection('home')}
        className={`flex flex-col items-center gap-1 py-1 px-3 rounded-lg text-[10px] font-medium transition ${
          currentSection === 'home'
            ? 'text-[#F1F1F1]'
            : 'text-[#92959B] hover:text-[#F1F1F1]'
        }`}
      >
        <Home className="w-4 h-4" />
        <span>Home</span>
      </button>

      <button
        onClick={() => onSelectSection('all')}
        className={`flex flex-col items-center gap-1 py-1 px-3 rounded-lg text-[10px] font-medium transition ${
          currentSection === 'all' || currentSection === 'recent'
            ? 'text-[#F1F1F1]'
            : 'text-[#92959B] hover:text-[#F1F1F1]'
        }`}
      >
        <FileText className="w-4 h-4" />
        <span>Notes</span>
      </button>

      <button
        onClick={onOpenMobileFolders}
        className={`flex flex-col items-center gap-1 py-1 px-3 rounded-lg text-[10px] font-medium transition ${
          currentSection === 'folder'
            ? 'text-[#F1F1F1]'
            : 'text-[#92959B] hover:text-[#F1F1F1]'
        }`}
      >
        <FolderIcon className="w-4 h-4" />
        <span>Folders</span>
      </button>

      <button
        onClick={() => onSelectSection('favorites')}
        className={`flex flex-col items-center gap-1 py-1 px-3 rounded-lg text-[10px] font-medium transition ${
          currentSection === 'favorites'
            ? 'text-[#F1F1F1]'
            : 'text-[#92959B] hover:text-[#F1F1F1]'
        }`}
      >
        <Star className={`w-4 h-4 ${currentSection === 'favorites' ? 'fill-current' : ''}`} />
        <span>Favorites</span>
      </button>

      <button
        onClick={onOpenSettings}
        className={`flex flex-col items-center gap-1 py-1 px-3 rounded-lg text-[10px] font-medium transition ${
          currentSection === 'settings'
            ? 'text-[#F1F1F1]'
            : 'text-[#92959B] hover:text-[#F1F1F1]'
        }`}
      >
        <Settings className="w-4 h-4" />
        <span>Settings</span>
      </button>
    </nav>
  );
};
