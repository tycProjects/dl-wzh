/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Bold,
  Italic,
  Underline,
  Strikethrough,
  Highlighter,
  List,
  ListOrdered,
  CheckSquare,
  Code,
  Quote,
  Table as TableIcon,
  Link as LinkIcon,
  Minus,
  Star,
  Pin,
  Maximize2,
  Minimize2,
  Folder as FolderIcon,
  Tag as TagIcon,
  MoreVertical,
  Download,
  Copy,
  Archive,
  Trash2,
  RotateCcw,
  Check,
  Plus,
  X,
  FileText,
  Clock,
} from 'lucide-react';
import type { Note, Folder, Tag, AppSettings } from '../types';
import {
  getWordCount,
  getCharCount,
  getReadingTime,
  formatFullDateTime,
} from '../utils/textUtils';

interface NoteEditorProps {
  note: Note | null;
  folders: Folder[];
  tags: Tag[];
  noteTagIds: string[];
  settings: AppSettings;
  isFullscreen: boolean;
  onToggleFullscreen: () => void;
  onSaveNote: (updatedNote: Partial<Note> & { id: string }) => Promise<void>;
  onUpdateNoteTags: (noteId: string, tagIds: string[]) => Promise<void>;
  onToggleFavorite: (noteId: string) => void;
  onTogglePin: (noteId: string) => void;
  onDuplicateNote: (note: Note) => void;
  onArchiveNote: (noteId: string) => void;
  onUnarchiveNote: (noteId: string) => void;
  onTrashNote: (noteId: string) => void;
  onRestoreNote: (noteId: string) => void;
  onPermanentDeleteNote: (note: Note) => void;
  onExportMarkdown: (note: Note) => void;
  onExportTxt: (note: Note) => void;
  onCreateTagQuick: (name: string) => Promise<Tag>;
  onNewNote: () => void;
}

export const NoteEditor: React.FC<NoteEditorProps> = ({
  note,
  folders,
  tags,
  noteTagIds,
  settings,
  isFullscreen,
  onToggleFullscreen,
  onSaveNote,
  onUpdateNoteTags,
  onToggleFavorite,
  onTogglePin,
  onDuplicateNote,
  onArchiveNote,
  onUnarchiveNote,
  onTrashNote,
  onRestoreNote,
  onPermanentDeleteNote,
  onExportMarkdown,
  onExportTxt,
  onCreateTagQuick,
  onNewNote,
}) => {
  const [title, setTitle] = useState('');
  const [saveStatus, setSaveStatus] = useState<'saved' | 'saving' | 'unsaved'>('saved');
  const [showTagMenu, setShowTagMenu] = useState(false);
  const [showMoreMenu, setShowMoreMenu] = useState(false);
  const [newTagInput, setNewTagInput] = useState('');
  const [activeFormats, setActiveFormats] = useState({
    bold: false,
    italic: false,
    underline: false,
    strikeThrough: false,
  });

  const editorRef = useRef<HTMLDivElement>(null);
  const titleInputRef = useRef<HTMLInputElement>(null);
  const debounceTimerRef = useRef<any>(null);
  const lastSavedContentRef = useRef<string>('');
  const lastSavedTitleRef = useRef<string>('');
  const currentNoteIdRef = useRef<string | null>(null);

  // Sync editor when active note changes
  useEffect(() => {
    // Flush any pending save on previous note
    if (currentNoteIdRef.current && currentNoteIdRef.current !== note?.id) {
      if (debounceTimerRef.current) {
        clearTimeout(debounceTimerRef.current);
      }
    }

    if (note) {
      currentNoteIdRef.current = note.id;
      setTitle(note.title);
      lastSavedTitleRef.current = note.title;
      lastSavedContentRef.current = note.content || '';

      if (editorRef.current) {
        // Only update innerHTML if it actually differs to preserve cursor if typing
        if (editorRef.current.innerHTML !== note.content) {
          editorRef.current.innerHTML = note.content || '';
        }
      }
      setSaveStatus('saved');
    } else {
      currentNoteIdRef.current = null;
      setTitle('');
      if (editorRef.current) {
        editorRef.current.innerHTML = '';
      }
      setSaveStatus('saved');
    }
  }, [note?.id]);

  // Execute immediate database save
  const flushSave = useCallback(
    async (overrideTitle?: string, overrideContent?: string) => {
      if (!note) return;
      const t = overrideTitle !== undefined ? overrideTitle : title;
      const c =
        overrideContent !== undefined
          ? overrideContent
          : editorRef.current?.innerHTML || '';

      // Check if anything actually changed
      if (
        t === lastSavedTitleRef.current &&
        c === lastSavedContentRef.current
      ) {
        setSaveStatus('saved');
        return;
      }

      setSaveStatus('saving');
      try {
        await onSaveNote({
          id: note.id,
          title: t,
          content: c,
          updatedAt: Date.now(),
        });
        lastSavedTitleRef.current = t;
        lastSavedContentRef.current = c;
        setSaveStatus('saved');
      } catch (err) {
        console.error('Failed to save note:', err);
        setSaveStatus('unsaved');
      }
    },
    [note, title, onSaveNote]
  );

  // Trigger debounced autosave
  const triggerAutosave = useCallback(
    (newTitle?: string, newContent?: string) => {
      setSaveStatus('saving');
      if (debounceTimerRef.current) {
        clearTimeout(debounceTimerRef.current);
      }
      debounceTimerRef.current = setTimeout(() => {
        flushSave(newTitle, newContent);
      }, settings.autosaveIntervalMs || 800);
    },
    [flushSave, settings.autosaveIntervalMs]
  );

  // Title change
  const handleTitleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setTitle(val);
    triggerAutosave(val, undefined);
  };

  // Editor content input
  const handleContentInput = () => {
    const content = editorRef.current?.innerHTML || '';
    updateActiveFormats();
    triggerAutosave(undefined, content);
  };

  // Formatting commands
  const executeCommand = (command: string, value: string | undefined = undefined) => {
    document.execCommand(command, false, value);
    editorRef.current?.focus();
    updateActiveFormats();
    handleContentInput();
  };

  // Update active format state based on selection
  const updateActiveFormats = () => {
    try {
      setActiveFormats({
        bold: document.queryCommandState('bold'),
        italic: document.queryCommandState('italic'),
        underline: document.queryCommandState('underline'),
        strikeThrough: document.queryCommandState('strikeThrough'),
      });
    } catch {
      // Ignore if document selection not active
    }
  };

  // Insert custom block elements
  const insertCustomBlock = (htmlSnippet: string) => {
    if (!editorRef.current) return;
    editorRef.current.focus();
    const selection = window.getSelection();
    if (!selection || selection.rangeCount === 0) {
      editorRef.current.innerHTML += htmlSnippet;
    } else {
      const range = selection.getRangeAt(0);
      range.deleteContents();
      const tempDiv = document.createElement('div');
      tempDiv.innerHTML = htmlSnippet;
      const frag = document.createDocumentFragment();
      let node;
      while ((node = tempDiv.firstChild)) {
        frag.appendChild(node);
      }
      range.insertNode(frag);
    }
    handleContentInput();
  };

  // Insert interactive checklist item
  const insertChecklist = () => {
    insertCustomBlock(
      '<ul class="checklist"><li><input type="checkbox"/> New checklist task</li></ul><p></p>'
    );
  };

  // Insert clean table
  const insertTable = () => {
    insertCustomBlock(
      `<table border="1" cellpadding="6" style="border-collapse: collapse; width: 100%; border-color: #303236;">
  <thead>
    <tr style="background: #202124;">
      <th style="padding: 6px 10px; border: 1px solid #303236;">Header 1</th>
      <th style="padding: 6px 10px; border: 1px solid #303236;">Header 2</th>
      <th style="padding: 6px 10px; border: 1px solid #303236;">Header 3</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="padding: 6px 10px; border: 1px solid #303236;">Row 1 Item</td>
      <td style="padding: 6px 10px; border: 1px solid #303236;">Description</td>
      <td style="padding: 6px 10px; border: 1px solid #303236;">Status</td>
    </tr>
    <tr>
      <td style="padding: 6px 10px; border: 1px solid #303236;">Row 2 Item</td>
      <td style="padding: 6px 10px; border: 1px solid #303236;">Details</td>
      <td style="padding: 6px 10px; border: 1px solid #303236;">Active</td>
    </tr>
  </tbody>
</table><p></p>`
    );
  };

  // Insert code block
  const insertCodeBlock = () => {
    insertCustomBlock(
      `<pre><code>// Enter code or snippet here\nfunction example() {\n  return true;\n}</code></pre><p></p>`
    );
  };

  // Insert quote
  const insertQuote = () => {
    insertCustomBlock(`<blockquote>"Deep work requires focus and stillness."</blockquote><p></p>`);
  };

  // Insert Link
  const insertLink = () => {
    const url = prompt('Enter link URL (e.g. https://example.com):');
    if (url) {
      executeCommand('createLink', url);
    }
  };

  // Highlight selection
  const highlightSelection = () => {
    const selection = window.getSelection();
    if (selection && !selection.isCollapsed) {
      const selectedText = selection.toString();
      insertCustomBlock(`<mark>${selectedText}</mark>`);
    } else {
      insertCustomBlock(`<mark>highlighted text</mark>`);
    }
  };

  // Handle click on checklist checkboxes inside the contentEditable
  const handleEditorClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const target = e.target as HTMLElement;
    if (target && target.tagName === 'INPUT' && (target as HTMLInputElement).type === 'checkbox') {
      const cb = target as HTMLInputElement;
      if (cb.checked) {
        cb.setAttribute('checked', 'checked');
      } else {
        cb.removeAttribute('checked');
      }
      handleContentInput();
    }
    updateActiveFormats();
  };

  // Quick tag toggle
  const toggleTagForNote = (tagId: string) => {
    if (!note) return;
    const isAssigned = noteTagIds.includes(tagId);
    const newTagIds = isAssigned
      ? noteTagIds.filter((id) => id !== tagId)
      : [...noteTagIds, tagId];
    onUpdateNoteTags(note.id, newTagIds);
  };

  const handleCreateNewTag = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTagInput.trim() || !note) return;
    try {
      const createdTag = await onCreateTagQuick(newTagInput.trim());
      onUpdateNoteTags(note.id, [...noteTagIds, createdTag.id]);
      setNewTagInput('');
    } catch (err) {
      console.error(err);
    }
  };

  // Word & Char counts
  const currentContentHtml = editorRef.current?.innerHTML || note?.content || '';
  const wordCount = getWordCount(currentContentHtml);
  const charCount = getCharCount(currentContentHtml);
  const readingTime = getReadingTime(wordCount);

  if (!note) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center bg-[#111214] text-[#92959B] p-6 text-center select-none">
        <div className="w-14 h-14 rounded-2xl bg-[#191A1D] border border-[#303236] flex items-center justify-center text-[#63666E] mb-4">
          <FileText className="w-7 h-7" />
        </div>
        <h3 className="text-base font-semibold text-[#F1F1F1] tracking-tight">No Note Selected</h3>
        <p className="text-xs text-[#92959B] max-w-sm mt-1 leading-relaxed">
          Select an existing note from the list, or create a new note to start writing with the graphite editor.
        </p>
        <button
          onClick={onNewNote}
          className="mt-4 px-4 py-2 text-xs font-semibold rounded-lg bg-[#F1F1F1] hover:bg-white text-[#111214] transition shadow-xs flex items-center gap-2"
        >
          <Plus className="w-4 h-4 stroke-[2.5]" />
          <span>Create New Note</span>
        </button>
      </div>
    );
  }

  const currentFolder = note.folderId
    ? folders.find((f) => f.id === note.folderId)
    : null;

  return (
    <div
      className={`flex-1 flex flex-col bg-[#111214] text-[#F1F1F1] overflow-hidden ${
        isFullscreen ? 'fixed inset-0 z-50 bg-[#111214]' : ''
      }`}
    >
      {/* Top Meta Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-2.5 border-b border-[#303236] bg-[#161719] select-none text-xs">
        {/* Left: Folder Selector & Tags */}
        <div className="flex items-center gap-2 flex-wrap">
          {/* Folder picker */}
          <div className="flex items-center gap-1.5 bg-[#202124] border border-[#303236] rounded-lg px-2 py-1">
            <FolderIcon className="w-3.5 h-3.5 text-[#B7B9BE]" />
            <select
              value={note.folderId || ''}
              onChange={(e) => {
                const newFId = e.target.value ? e.target.value : null;
                onSaveNote({ id: note.id, folderId: newFId });
              }}
              className="bg-transparent text-xs text-[#F1F1F1] focus:outline-none cursor-pointer max-w-[140px] truncate"
            >
              <option value="" className="bg-[#202124]">(No Folder)</option>
              {folders.map((f) => (
                <option key={f.id} value={f.id} className="bg-[#202124]">
                  📁 {f.name}
                </option>
              ))}
            </select>
          </div>

          {/* Tags Dropdown Popover */}
          <div className="relative">
            <button
              type="button"
              onClick={() => setShowTagMenu(!showTagMenu)}
              className="flex items-center gap-1.5 bg-[#202124] border border-[#303236] hover:border-[#B7B9BE] rounded-lg px-2 py-1 text-xs text-[#92959B] hover:text-[#F1F1F1] transition"
            >
              <TagIcon className="w-3.5 h-3.5 text-[#B7B9BE]" />
              <span>Tags ({noteTagIds.length})</span>
            </button>

            {showTagMenu && (
              <div
                onClick={(e) => e.stopPropagation()}
                className="absolute left-0 top-8 z-30 w-56 bg-[#191A1D] border border-[#303236] rounded-xl shadow-2xl p-3 text-xs"
              >
                <div className="flex items-center justify-between pb-2 border-b border-[#303236] mb-2 font-semibold text-[#F1F1F1]">
                  <span>Assign Tags</span>
                  <button onClick={() => setShowTagMenu(false)}>
                    <X className="w-3.5 h-3.5 text-[#92959B]" />
                  </button>
                </div>

                <div className="max-h-40 overflow-y-auto space-y-1 mb-2">
                  {tags.length === 0 ? (
                    <div className="text-[11px] text-[#63666E] italic py-1">No tags yet.</div>
                  ) : (
                    tags.map((tag) => {
                      const isChecked = noteTagIds.includes(tag.id);
                      return (
                        <label
                          key={tag.id}
                          className="flex items-center gap-2 p-1.5 rounded hover:bg-[#202124] cursor-pointer text-[#92959B] hover:text-[#F1F1F1]"
                        >
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={() => toggleTagForNote(tag.id)}
                            className="rounded accent-[#B7B9BE] cursor-pointer"
                          />
                          <span
                            className="w-2 h-2 rounded-full"
                            style={{ backgroundColor: tag.color }}
                          />
                          <span className="truncate">#{tag.name}</span>
                        </label>
                      );
                    })
                  )}
                </div>

                {/* Quick Add Tag Form */}
                <form onSubmit={handleCreateNewTag} className="pt-2 border-t border-[#303236] flex gap-1">
                  <input
                    type="text"
                    value={newTagInput}
                    onChange={(e) => setNewTagInput(e.target.value)}
                    placeholder="New tag..."
                    className="flex-1 bg-[#202124] border border-[#303236] rounded px-2 py-1 text-xs text-[#F1F1F1] placeholder-[#63666E] focus:outline-none"
                  />
                  <button
                    type="submit"
                    className="p-1 rounded bg-[#202124] border border-[#303236] hover:bg-[#26282C] text-[#F1F1F1]"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </form>
              </div>
            )}
          </div>

          {/* Render assigned tag pills */}
          <div className="hidden sm:flex items-center gap-1.5">
            {noteTagIds.map((tId) => {
              const tag = tags.find((t) => t.id === tId);
              if (!tag) return null;
              return (
                <span
                  key={tag.id}
                  className="px-2 py-0.5 rounded-md bg-[#202124] border border-[#303236] text-[11px] text-[#B7B9BE] flex items-center gap-1"
                >
                  <span
                    className="w-1.5 h-1.5 rounded-full"
                    style={{ backgroundColor: tag.color }}
                  />
                  <span>#{tag.name}</span>
                </span>
              );
            })}
          </div>
        </div>

        {/* Right: Autosave Status, Star, Pin, Fullscreen, More */}
        <div className="flex items-center gap-1.5">
          {/* Autosave Status */}
          <span className="text-[11px] text-[#92959B] mr-1 hidden sm:inline-flex items-center gap-1">
            <span
              className={`w-1.5 h-1.5 rounded-full ${
                saveStatus === 'saving'
                  ? 'bg-amber-400 animate-pulse'
                  : saveStatus === 'unsaved'
                  ? 'bg-red-400'
                  : 'bg-emerald-400'
              }`}
            />
            {saveStatus === 'saving'
              ? 'Saving...'
              : saveStatus === 'unsaved'
              ? 'Unsaved'
              : 'Saved'}
          </span>

          {/* Star toggle */}
          <button
            type="button"
            onClick={() => onToggleFavorite(note.id)}
            className={`p-1.5 rounded-lg border transition ${
              note.isFavorite
                ? 'bg-[#202124] border-[#B7B9BE] text-[#D4AF37]'
                : 'border-[#303236] text-[#92959B] hover:text-[#F1F1F1] hover:bg-[#202124]'
            }`}
            title={note.isFavorite ? 'Remove from favorites' : 'Star note'}
          >
            <Star className={`w-3.5 h-3.5 ${note.isFavorite ? 'fill-current' : ''}`} />
          </button>

          {/* Pin toggle */}
          <button
            type="button"
            onClick={() => onTogglePin(note.id)}
            className={`p-1.5 rounded-lg border transition ${
              note.isPinned
                ? 'bg-[#202124] border-[#B7B9BE] text-[#F1F1F1]'
                : 'border-[#303236] text-[#92959B] hover:text-[#F1F1F1] hover:bg-[#202124]'
            }`}
            title={note.isPinned ? 'Unpin note' : 'Pin note to top'}
          >
            <Pin className={`w-3.5 h-3.5 ${note.isPinned ? 'fill-current' : ''}`} />
          </button>

          {/* Fullscreen toggle */}
          <button
            type="button"
            onClick={onToggleFullscreen}
            className="p-1.5 rounded-lg border border-[#303236] text-[#92959B] hover:text-[#F1F1F1] hover:bg-[#202124] transition"
            title={isFullscreen ? 'Exit Fullscreen (Esc)' : 'Fullscreen Editor'}
          >
            {isFullscreen ? (
              <Minimize2 className="w-3.5 h-3.5" />
            ) : (
              <Maximize2 className="w-3.5 h-3.5" />
            )}
          </button>

          {/* More options menu */}
          <div className="relative">
            <button
              type="button"
              onClick={() => setShowMoreMenu(!showMoreMenu)}
              className="p-1.5 rounded-lg border border-[#303236] text-[#92959B] hover:text-[#F1F1F1] hover:bg-[#202124] transition"
              title="More actions"
            >
              <MoreVertical className="w-3.5 h-3.5" />
            </button>

            {showMoreMenu && (
              <div
                onClick={(e) => e.stopPropagation()}
                className="absolute right-0 top-8 z-30 w-48 bg-[#191A1D] border border-[#303236] rounded-xl shadow-2xl py-1 text-xs"
              >
                <button
                  onClick={() => {
                    setShowMoreMenu(false);
                    onExportMarkdown(note);
                  }}
                  className="w-full flex items-center gap-2 px-3 py-1.5 text-left text-[#92959B] hover:text-[#F1F1F1] hover:bg-[#202124]"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Export as Markdown (.md)</span>
                </button>

                <button
                  onClick={() => {
                    setShowMoreMenu(false);
                    onExportTxt(note);
                  }}
                  className="w-full flex items-center gap-2 px-3 py-1.5 text-left text-[#92959B] hover:text-[#F1F1F1] hover:bg-[#202124]"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Export as Plain Text (.txt)</span>
                </button>

                <button
                  onClick={() => {
                    setShowMoreMenu(false);
                    onDuplicateNote(note);
                  }}
                  className="w-full flex items-center gap-2 px-3 py-1.5 text-left text-[#92959B] hover:text-[#F1F1F1] hover:bg-[#202124]"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>Duplicate Note</span>
                </button>

                <div className="my-1 border-t border-[#303236]" />

                {note.isArchived ? (
                  <button
                    onClick={() => {
                      setShowMoreMenu(false);
                      onUnarchiveNote(note.id);
                    }}
                    className="w-full flex items-center gap-2 px-3 py-1.5 text-left text-[#92959B] hover:text-[#F1F1F1] hover:bg-[#202124]"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Unarchive Note</span>
                  </button>
                ) : (
                  <button
                    onClick={() => {
                      setShowMoreMenu(false);
                      onArchiveNote(note.id);
                    }}
                    className="w-full flex items-center gap-2 px-3 py-1.5 text-left text-[#92959B] hover:text-[#F1F1F1] hover:bg-[#202124]"
                  >
                    <Archive className="w-3.5 h-3.5" />
                    <span>Archive Note</span>
                  </button>
                )}

                {note.inTrash ? (
                  <>
                    <button
                      onClick={() => {
                        setShowMoreMenu(false);
                        onRestoreNote(note.id);
                      }}
                      className="w-full flex items-center gap-2 px-3 py-1.5 text-left text-[#92959B] hover:text-[#F1F1F1] hover:bg-[#202124]"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>Restore from Trash</span>
                    </button>
                    <button
                      onClick={() => {
                        setShowMoreMenu(false);
                        onPermanentDeleteNote(note);
                      }}
                      className="w-full flex items-center gap-2 px-3 py-1.5 text-left text-red-400 hover:bg-red-500/10"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Delete Forever</span>
                    </button>
                  </>
                ) : (
                  <button
                    onClick={() => {
                      setShowMoreMenu(false);
                      onTrashNote(note.id);
                    }}
                    className="w-full flex items-center gap-2 px-3 py-1.5 text-left text-red-400 hover:bg-red-500/10"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Move to Trash</span>
                  </button>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Formatting Toolbar */}
      <div className="flex items-center gap-0.5 px-4 py-2 border-b border-[#303236] bg-[#141517] overflow-x-auto select-none scrollbar-none">
        {/* Headings */}
        <button
          type="button"
          onClick={() => executeCommand('formatBlock', '<H1>')}
          className="px-2 py-1 rounded text-xs font-bold text-[#92959B] hover:text-[#F1F1F1] hover:bg-[#202124] transition shrink-0"
          title="Heading 1"
        >
          H1
        </button>
        <button
          type="button"
          onClick={() => executeCommand('formatBlock', '<H2>')}
          className="px-2 py-1 rounded text-xs font-bold text-[#92959B] hover:text-[#F1F1F1] hover:bg-[#202124] transition shrink-0"
          title="Heading 2"
        >
          H2
        </button>
        <button
          type="button"
          onClick={() => executeCommand('formatBlock', '<H3>')}
          className="px-2 py-1 rounded text-xs font-bold text-[#92959B] hover:text-[#F1F1F1] hover:bg-[#202124] transition shrink-0"
          title="Heading 3"
        >
          H3
        </button>
        <button
          type="button"
          onClick={() => executeCommand('formatBlock', '<P>')}
          className="px-2 py-1 rounded text-xs text-[#92959B] hover:text-[#F1F1F1] hover:bg-[#202124] transition shrink-0"
          title="Normal Paragraph"
        >
          ¶
        </button>

        <div className="w-[1px] h-4 bg-[#303236] mx-1 shrink-0" />

        {/* Inline styles */}
        <button
          type="button"
          onClick={() => executeCommand('bold')}
          className={`p-1.5 rounded transition shrink-0 ${
            activeFormats.bold
              ? 'bg-[#202124] text-[#F1F1F1]'
              : 'text-[#92959B] hover:text-[#F1F1F1] hover:bg-[#202124]'
          }`}
          title="Bold (Ctrl+B)"
        >
          <Bold className="w-3.5 h-3.5" />
        </button>

        <button
          type="button"
          onClick={() => executeCommand('italic')}
          className={`p-1.5 rounded transition shrink-0 ${
            activeFormats.italic
              ? 'bg-[#202124] text-[#F1F1F1]'
              : 'text-[#92959B] hover:text-[#F1F1F1] hover:bg-[#202124]'
          }`}
          title="Italic (Ctrl+I)"
        >
          <Italic className="w-3.5 h-3.5" />
        </button>

        <button
          type="button"
          onClick={() => executeCommand('underline')}
          className={`p-1.5 rounded transition shrink-0 ${
            activeFormats.underline
              ? 'bg-[#202124] text-[#F1F1F1]'
              : 'text-[#92959B] hover:text-[#F1F1F1] hover:bg-[#202124]'
          }`}
          title="Underline"
        >
          <Underline className="w-3.5 h-3.5" />
        </button>

        <button
          type="button"
          onClick={() => executeCommand('strikeThrough')}
          className={`p-1.5 rounded transition shrink-0 ${
            activeFormats.strikeThrough
              ? 'bg-[#202124] text-[#F1F1F1]'
              : 'text-[#92959B] hover:text-[#F1F1F1] hover:bg-[#202124]'
          }`}
          title="Strikethrough"
        >
          <Strikethrough className="w-3.5 h-3.5" />
        </button>

        <button
          type="button"
          onClick={highlightSelection}
          className="p-1.5 rounded text-[#92959B] hover:text-[#F1F1F1] hover:bg-[#202124] transition shrink-0"
          title="Highlight text"
        >
          <Highlighter className="w-3.5 h-3.5" />
        </button>

        <div className="w-[1px] h-4 bg-[#303236] mx-1 shrink-0" />

        {/* Lists & Checks */}
        <button
          type="button"
          onClick={() => executeCommand('insertUnorderedList')}
          className="p-1.5 rounded text-[#92959B] hover:text-[#F1F1F1] hover:bg-[#202124] transition shrink-0"
          title="Bullet List"
        >
          <List className="w-3.5 h-3.5" />
        </button>

        <button
          type="button"
          onClick={() => executeCommand('insertOrderedList')}
          className="p-1.5 rounded text-[#92959B] hover:text-[#F1F1F1] hover:bg-[#202124] transition shrink-0"
          title="Numbered List"
        >
          <ListOrdered className="w-3.5 h-3.5" />
        </button>

        <button
          type="button"
          onClick={insertChecklist}
          className="p-1.5 rounded text-[#92959B] hover:text-[#F1F1F1] hover:bg-[#202124] transition shrink-0"
          title="Interactive Checklist"
        >
          <CheckSquare className="w-3.5 h-3.5" />
        </button>

        <div className="w-[1px] h-4 bg-[#303236] mx-1 shrink-0" />

        {/* Code & Quote & Table & Link */}
        <button
          type="button"
          onClick={insertCodeBlock}
          className="p-1.5 rounded text-[#92959B] hover:text-[#F1F1F1] hover:bg-[#202124] transition shrink-0"
          title="Code Block"
        >
          <Code className="w-3.5 h-3.5" />
        </button>

        <button
          type="button"
          onClick={insertQuote}
          className="p-1.5 rounded text-[#92959B] hover:text-[#F1F1F1] hover:bg-[#202124] transition shrink-0"
          title="Blockquote"
        >
          <Quote className="w-3.5 h-3.5" />
        </button>

        <button
          type="button"
          onClick={insertTable}
          className="p-1.5 rounded text-[#92959B] hover:text-[#F1F1F1] hover:bg-[#202124] transition shrink-0"
          title="Insert Table"
        >
          <TableIcon className="w-3.5 h-3.5" />
        </button>

        <button
          type="button"
          onClick={insertLink}
          className="p-1.5 rounded text-[#92959B] hover:text-[#F1F1F1] hover:bg-[#202124] transition shrink-0"
          title="Insert Link"
        >
          <LinkIcon className="w-3.5 h-3.5" />
        </button>

        <button
          type="button"
          onClick={() => executeCommand('insertHorizontalRule')}
          className="p-1.5 rounded text-[#92959B] hover:text-[#F1F1F1] hover:bg-[#202124] transition shrink-0"
          title="Divider Line"
        >
          <Minus className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Editor Main Writing Area */}
      <div className="flex-1 overflow-y-auto px-6 py-6 md:px-12 lg:px-16 max-w-4xl w-full mx-auto">
        {/* Title Input */}
        <input
          ref={titleInputRef}
          type="text"
          value={title}
          onChange={handleTitleChange}
          placeholder="Untitled Note..."
          className="w-full text-2xl md:text-3xl font-bold bg-transparent text-[#F1F1F1] placeholder-[#4A4D53] focus:outline-none mb-4 pb-2 border-b border-[#303236]/40 tracking-tight"
        />

        {/* ContentEditable Area */}
        <div
          ref={editorRef}
          contentEditable
          suppressContentEditableWarning
          onInput={handleContentInput}
          onClick={handleEditorClick}
          onKeyUp={updateActiveFormats}
          className="tumba-editor-content focus:outline-none"
          style={{
            fontFamily:
              settings.editorFontFamily === 'mono'
                ? 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace'
                : settings.editorFontFamily === 'serif'
                ? 'Georgia, Cambria, "Times New Roman", Times, serif'
                : 'inherit',
            fontSize:
              settings.fontSize === 'small'
                ? '0.9rem'
                : settings.fontSize === 'large'
                ? '1.15rem'
                : '1rem',
          }}
          data-placeholder="Start typing your note..."
        />
      </div>

      {/* Bottom Status Bar */}
      <div className="flex items-center justify-between px-6 py-2 border-t border-[#303236] bg-[#141517] text-[11px] text-[#63666E] select-none">
        <div className="flex items-center gap-4">
          <span>{wordCount} words</span>
          <span>{charCount} characters</span>
          <span className="hidden sm:inline">{readingTime}</span>
        </div>

        <div className="flex items-center gap-4">
          <span className="hidden md:inline">
            Created: {formatFullDateTime(note.createdAt)}
          </span>
          <span>
            Modified: {formatFullDateTime(note.updatedAt)}
          </span>
        </div>
      </div>
    </div>
  );
};
