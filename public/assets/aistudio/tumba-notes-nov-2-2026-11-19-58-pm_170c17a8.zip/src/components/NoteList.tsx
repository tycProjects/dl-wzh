/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import {
  Search,
  Plus,
  Star,
  Pin,
  Calendar,
  ArrowUpDown,
  Filter,
  FileText,
  Trash2,
  Archive,
  Copy,
  MoreVertical,
  RotateCcw,
  Tag as TagIcon,
  Folder as FolderIcon,
  Check,
} from 'lucide-react';
import type { Note, Folder, Tag, ViewSection } from '../types';
import { stripHtml, formatDate } from '../utils/textUtils';

interface NoteListProps {
  currentSection: ViewSection;
  selectedFolder: Folder | null;
  selectedTag: Tag | null;
  notes: Note[];
  folders: Folder[];
  tags: Tag[];
  noteTagsMap: Record<string, string[]>;
  activeNoteId: string | null;
  isCompactMode: boolean;
  onSelectNote: (noteId: string) => void;
  onNewNote: () => void;
  onToggleFavorite: (noteId: string, e: React.MouseEvent) => void;
  onTogglePin: (noteId: string, e: React.MouseEvent) => void;
  onDuplicateNote: (note: Note) => void;
  onArchiveNote: (noteId: string) => void;
  onUnarchiveNote: (noteId: string) => void;
  onTrashNote: (noteId: string) => void;
  onRestoreNote: (noteId: string) => void;
  onPermanentDeleteNote: (note: Note) => void;
  onEmptyTrash?: () => void;
}

export const NoteList: React.FC<NoteListProps> = ({
  currentSection,
  selectedFolder,
  selectedTag,
  notes,
  folders,
  tags,
  noteTagsMap,
  activeNoteId,
  isCompactMode,
  onSelectNote,
  onNewNote,
  onToggleFavorite,
  onTogglePin,
  onDuplicateNote,
  onArchiveNote,
  onUnarchiveNote,
  onTrashNote,
  onRestoreNote,
  onPermanentDeleteNote,
  onEmptyTrash,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'updated-desc' | 'updated-asc' | 'created-desc' | 'title-asc'>('updated-desc');
  const [tagFilter, setTagFilter] = useState<string>('all');
  const [favoriteOnlyFilter, setFavoriteOnlyFilter] = useState(false);
  const [openActionMenuId, setOpenActionMenuId] = useState<string | null>(null);

  const folderMap = useMemo(() => {
    const map = new Map<string, Folder>();
    folders.forEach((f) => map.set(f.id, f));
    return map;
  }, [folders]);

  const tagMap = useMemo(() => {
    const map = new Map<string, Tag>();
    tags.forEach((t) => map.set(t.id, t));
    return map;
  }, [tags]);

  // Determine section title and icon
  const sectionMeta = useMemo(() => {
    if (selectedFolder) {
      return {
        title: selectedFolder.name,
        subtitle: selectedFolder.description || 'Folder contents',
        isTrash: false,
        isArchive: false,
      };
    }
    if (selectedTag) {
      return {
        title: `#${selectedTag.name}`,
        subtitle: 'Notes tagged with this label',
        isTrash: false,
        isArchive: false,
      };
    }
    switch (currentSection) {
      case 'favorites':
        return { title: 'Favorites', subtitle: 'Starred & essential notes', isTrash: false, isArchive: false };
      case 'recent':
        return { title: 'Recent Notes', subtitle: 'Active in the last 7 days', isTrash: false, isArchive: false };
      case 'archive':
        return { title: 'Archive', subtitle: 'Archived reference notes', isTrash: false, isArchive: true };
      case 'trash':
        return { title: 'Trash', subtitle: 'Deleted notes', isTrash: true, isArchive: false };
      case 'all':
      default:
        return { title: 'All Notes', subtitle: 'Complete collection', isTrash: false, isArchive: false };
    }
  }, [currentSection, selectedFolder, selectedTag]);

  // Base filtering by section
  const sectionFilteredNotes = useMemo(() => {
    const now = Date.now();
    const oneWeekAgo = now - 7 * 24 * 60 * 60 * 1000;

    return notes.filter((n) => {
      if (sectionMeta.isTrash) {
        return n.inTrash;
      }
      if (n.inTrash) return false;

      if (sectionMeta.isArchive) {
        return n.isArchived;
      }
      if (n.isArchived) return false;

      if (selectedFolder) {
        return n.folderId === selectedFolder.id;
      }

      if (selectedTag) {
        const noteTagIds = noteTagsMap[n.id] || [];
        return noteTagIds.includes(selectedTag.id);
      }

      switch (currentSection) {
        case 'favorites':
          return n.isFavorite;
        case 'recent':
          return n.updatedAt >= oneWeekAgo;
        case 'all':
        default:
          return true;
      }
    });
  }, [notes, currentSection, selectedFolder, selectedTag, sectionMeta, noteTagsMap]);

  // Search & filter
  const processedNotes = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();

    const filtered = sectionFilteredNotes.filter((note) => {
      if (favoriteOnlyFilter && !note.isFavorite) return false;
      if (tagFilter !== 'all') {
        const noteTagIds = noteTagsMap[note.id] || [];
        if (!noteTagIds.includes(tagFilter)) return false;
      }

      if (!q) return true;
      if (note.title.toLowerCase().includes(q)) return true;
      const plain = stripHtml(note.content).toLowerCase();
      if (plain.includes(q)) return true;

      return false;
    });

    // Sorting: Pinned first (except in trash/archive), then by sortBy criteria
    return filtered.sort((a, b) => {
      if (!sectionMeta.isTrash && !sectionMeta.isArchive) {
        if (a.isPinned && !b.isPinned) return -1;
        if (!a.isPinned && b.isPinned) return 1;
      }

      switch (sortBy) {
        case 'updated-asc':
          return a.updatedAt - b.updatedAt;
        case 'created-desc':
          return b.createdAt - a.createdAt;
        case 'title-asc':
          return a.title.localeCompare(b.title);
        case 'updated-desc':
        default:
          return b.updatedAt - a.updatedAt;
      }
    });
  }, [sectionFilteredNotes, searchQuery, tagFilter, favoriteOnlyFilter, sortBy, sectionMeta, noteTagsMap]);

  // Split into pinned and unpinned if in standard views
  const { pinnedNotes, unpinnedNotes } = useMemo(() => {
    if (sectionMeta.isTrash || sectionMeta.isArchive) {
      return { pinnedNotes: [], unpinnedNotes: processedNotes };
    }
    const pinned = processedNotes.filter((n) => n.isPinned);
    const unpinned = processedNotes.filter((n) => !n.isPinned);
    return { pinnedNotes: pinned, unpinnedNotes: unpinned };
  }, [processedNotes, sectionMeta]);

  const handleCardDragStart = (e: React.DragEvent, noteId: string) => {
    e.dataTransfer.setData('text/tumba-note-id', noteId);
  };

  const renderNoteCard = (note: Note) => {
    const isActive = activeNoteId === note.id;
    const folder = note.folderId ? folderMap.get(note.folderId) : null;
    const noteTagIds = noteTagsMap[note.id] || [];
    const plainText = stripHtml(note.content).trim();

    return (
      <div
        key={note.id}
        draggable
        onDragStart={(e) => handleCardDragStart(e, note.id)}
        onClick={() => onSelectNote(note.id)}
        className={`group relative rounded-xl border p-3.5 transition cursor-pointer select-none ${
          isActive
            ? 'bg-[#202124] border-[#B7B9BE] shadow-md'
            : 'bg-[#191A1D] border-[#303236] hover:bg-[#1E2024] hover:border-[#4A4D53]'
        } ${isCompactMode ? 'py-2 px-3' : ''}`}
      >
        <div className="flex items-start justify-between gap-2 mb-1">
          <div className="flex items-center gap-1.5 min-w-0 flex-1">
            {note.isPinned && (
              <span title="Pinned Note">
                <Pin className="w-3.5 h-3.5 text-[#B7B9BE] fill-current shrink-0" />
              </span>
            )}
            <h4 className="text-xs font-semibold text-[#F1F1F1] truncate">
              {note.title || 'Untitled Note'}
            </h4>
          </div>

          <div className="flex items-center gap-1 shrink-0">
            {/* Star toggle */}
            {!sectionMeta.isTrash && (
              <button
                type="button"
                onClick={(e) => onToggleFavorite(note.id, e)}
                className="p-1 text-[#63666E] hover:text-[#D4AF37] transition rounded"
                title={note.isFavorite ? 'Remove favorite' : 'Mark favorite'}
              >
                <Star
                  className={`w-3.5 h-3.5 ${
                    note.isFavorite ? 'text-[#D4AF37] fill-current' : ''
                  }`}
                />
              </button>
            )}

            {/* Quick action menu trigger */}
            <div className="relative">
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setOpenActionMenuId(openActionMenuId === note.id ? null : note.id);
                }}
                className="p-1 text-[#63666E] hover:text-[#F1F1F1] rounded opacity-0 group-hover:opacity-100 transition"
                title="Options"
              >
                <MoreVertical className="w-3.5 h-3.5" />
              </button>

              {openActionMenuId === note.id && (
                <div
                  onClick={(e) => e.stopPropagation()}
                  className="absolute right-0 top-6 z-30 w-40 bg-[#191A1D] border border-[#303236] rounded-lg shadow-xl py-1 text-xs"
                >
                  {!sectionMeta.isTrash && (
                    <>
                      <button
                        onClick={() => {
                          setOpenActionMenuId(null);
                          onDuplicateNote(note);
                        }}
                        className="w-full flex items-center gap-2 px-3 py-1.5 text-left text-[#92959B] hover:text-[#F1F1F1] hover:bg-[#202124]"
                      >
                        <Copy className="w-3 h-3" />
                        <span>Duplicate</span>
                      </button>

                      <button
                        onClick={(e) => {
                          setOpenActionMenuId(null);
                          onTogglePin(note.id, e);
                        }}
                        className="w-full flex items-center gap-2 px-3 py-1.5 text-left text-[#92959B] hover:text-[#F1F1F1] hover:bg-[#202124]"
                      >
                        <Pin className="w-3 h-3" />
                        <span>{note.isPinned ? 'Unpin' : 'Pin to top'}</span>
                      </button>

                      {note.isArchived ? (
                        <button
                          onClick={() => {
                            setOpenActionMenuId(null);
                            onUnarchiveNote(note.id);
                          }}
                          className="w-full flex items-center gap-2 px-3 py-1.5 text-left text-[#92959B] hover:text-[#F1F1F1] hover:bg-[#202124]"
                        >
                          <RotateCcw className="w-3 h-3" />
                          <span>Unarchive</span>
                        </button>
                      ) : (
                        <button
                          onClick={() => {
                            setOpenActionMenuId(null);
                            onArchiveNote(note.id);
                          }}
                          className="w-full flex items-center gap-2 px-3 py-1.5 text-left text-[#92959B] hover:text-[#F1F1F1] hover:bg-[#202124]"
                        >
                          <Archive className="w-3 h-3" />
                          <span>Archive</span>
                        </button>
                      )}

                      <button
                        onClick={() => {
                          setOpenActionMenuId(null);
                          onTrashNote(note.id);
                        }}
                        className="w-full flex items-center gap-2 px-3 py-1.5 text-left text-red-400 hover:bg-red-500/10"
                      >
                        <Trash2 className="w-3 h-3" />
                        <span>Move to Trash</span>
                      </button>
                    </>
                  )}

                  {sectionMeta.isTrash && (
                    <>
                      <button
                        onClick={() => {
                          setOpenActionMenuId(null);
                          onRestoreNote(note.id);
                        }}
                        className="w-full flex items-center gap-2 px-3 py-1.5 text-left text-[#92959B] hover:text-[#F1F1F1] hover:bg-[#202124]"
                      >
                        <RotateCcw className="w-3 h-3" />
                        <span>Restore Note</span>
                      </button>
                      <button
                        onClick={() => {
                          setOpenActionMenuId(null);
                          onPermanentDeleteNote(note);
                        }}
                        className="w-full flex items-center gap-2 px-3 py-1.5 text-left text-red-400 hover:bg-red-500/10"
                      >
                        <Trash2 className="w-3 h-3" />
                        <span>Delete Forever</span>
                      </button>
                    </>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Text snippet (hidden in compact mode if very short) */}
        {!isCompactMode && (
          <p className="text-[11px] text-[#92959B] line-clamp-2 leading-relaxed mb-2.5">
            {plainText || '(No content)'}
          </p>
        )}

        {/* Card Footer: Date, Folder chip, Tags */}
        <div className="flex flex-wrap items-center gap-1.5 text-[10px] text-[#63666E]">
          <span className="flex items-center gap-1">
            <Calendar className="w-3 h-3 text-[#63666E]" />
            {formatDate(note.updatedAt)}
          </span>

          {folder && (
            <span
              className="px-1.5 py-0.5 rounded bg-[#161719] border border-[#303236] text-[#B7B9BE] flex items-center gap-1"
              title={`Folder: ${folder.name}`}
            >
              <FolderIcon className="w-2.5 h-2.5" />
              <span className="max-w-[70px] truncate">{folder.name}</span>
            </span>
          )}

          {noteTagIds.slice(0, 2).map((tId) => {
            const tag = tagMap.get(tId);
            if (!tag) return null;
            return (
              <span
                key={tag.id}
                className="px-1.5 py-0.5 rounded bg-[#161719] border border-[#303236] text-[#92959B]"
              >
                #{tag.name}
              </span>
            );
          })}
          {noteTagIds.length > 2 && (
            <span className="text-[#63666E]">+{noteTagIds.length - 2}</span>
          )}
        </div>
      </div>
    );
  };

  return (
    <div
      onClick={() => setOpenActionMenuId(null)}
      className="flex flex-col h-full bg-[#111214] border-r border-[#303236] select-none min-w-[280px] w-full md:w-80 lg:w-96 shrink-0"
    >
      {/* Header with Title and New Note / Empty Trash */}
      <div className="px-4 py-3.5 border-b border-[#303236] bg-[#161719]">
        <div className="flex items-center justify-between mb-2">
          <div>
            <h2 className="text-sm font-bold tracking-tight text-[#F1F1F1]">
              {sectionMeta.title}
            </h2>
            <p className="text-[10px] text-[#92959B]">{sectionMeta.subtitle}</p>
          </div>

          <div className="flex items-center gap-2">
            {sectionMeta.isTrash && onEmptyTrash && processedNotes.length > 0 && (
              <button
                onClick={onEmptyTrash}
                className="px-2.5 py-1 text-[11px] font-medium text-red-400 bg-red-500/10 hover:bg-red-500/20 border border-red-500/30 rounded-lg transition"
              >
                Empty Trash
              </button>
            )}

            {!sectionMeta.isTrash && (
              <button
                onClick={onNewNote}
                className="p-1.5 rounded-lg bg-[#F1F1F1] hover:bg-white text-[#111214] transition shadow-xs"
                title="Create New Note (Ctrl+N)"
              >
                <Plus className="w-4 h-4 stroke-[2.5]" />
              </button>
            )}
          </div>
        </div>

        {/* Search bar inside note list */}
        <div className="relative">
          <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-[#63666E]" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Filter notes..."
            className="w-full bg-[#202124] border border-[#303236] rounded-lg pl-8 pr-3 py-1.5 text-xs text-[#F1F1F1] placeholder-[#63666E] focus:outline-none focus:border-[#B7B9BE] transition"
          />
        </div>

        {/* Sort & Filter controls */}
        <div className="flex items-center justify-between mt-2 pt-2 border-t border-[#303236]/50 text-xs">
          <div className="flex items-center gap-1.5">
            <ArrowUpDown className="w-3 h-3 text-[#63666E]" />
            <select
              value={sortBy}
              onChange={(e: any) => setSortBy(e.target.value)}
              className="bg-transparent text-[11px] text-[#92959B] focus:outline-none cursor-pointer"
            >
              <option value="updated-desc" className="bg-[#202124]">Modified (Newest)</option>
              <option value="updated-asc" className="bg-[#202124]">Modified (Oldest)</option>
              <option value="created-desc" className="bg-[#202124]">Created (Newest)</option>
              <option value="title-asc" className="bg-[#202124]">Title (A-Z)</option>
            </select>
          </div>

          <div className="flex items-center gap-1 text-[11px] text-[#63666E]">
            <span>{processedNotes.length} notes</span>
          </div>
        </div>
      </div>

      {/* Note Cards List */}
      <div className="flex-1 overflow-y-auto p-3 space-y-2">
        {processedNotes.length === 0 ? (
          <div className="py-16 text-center text-[#92959B]">
            <FileText className="w-8 h-8 mx-auto mb-2 opacity-30 text-[#63666E]" />
            <p className="text-xs font-medium text-[#92959B]">No notes found</p>
            <p className="text-[11px] text-[#63666E] mt-0.5">
              {searchQuery ? 'Try another keyword' : 'Create a new note to get started'}
            </p>
            {!sectionMeta.isTrash && !searchQuery && (
              <button
                onClick={onNewNote}
                className="mt-3 px-3 py-1.5 text-xs rounded-lg border border-[#303236] bg-[#191A1D] text-[#F1F1F1] hover:bg-[#202124] transition"
              >
                + New Note
              </button>
            )}
          </div>
        ) : (
          <>
            {pinnedNotes.length > 0 && (
              <div className="space-y-2">
                <div className="flex items-center gap-1 text-[10px] font-semibold text-[#63666E] uppercase tracking-wider px-1">
                  <Pin className="w-3 h-3" />
                  <span>Pinned</span>
                </div>
                {pinnedNotes.map(renderNoteCard)}
              </div>
            )}

            {unpinnedNotes.length > 0 && (
              <div className="space-y-2">
                {pinnedNotes.length > 0 && (
                  <div className="flex items-center gap-1 text-[10px] font-semibold text-[#63666E] uppercase tracking-wider px-1 pt-2">
                    <span>All</span>
                  </div>
                )}
                {unpinnedNotes.map(renderNoteCard)}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};
