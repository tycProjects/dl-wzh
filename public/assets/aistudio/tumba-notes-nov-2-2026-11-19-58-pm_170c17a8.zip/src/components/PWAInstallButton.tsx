/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Download, Share, PlusSquare, X } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

export const PWAInstallButton: React.FC = () => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  // If already running as an installed standalone PWA, hide
  if (isInstalled) {
    return null;
  }

  // Chromium / Android / Desktop flow
  if (isInstallable) {
    return (
      <button
        onClick={install}
        className="flex items-center gap-2 w-full px-3 py-2 text-xs font-medium rounded-lg border border-[#303236] bg-[#202124] text-[#F1F1F1] hover:bg-[#26282C] hover:border-[#B7B9BE] transition group shadow-xs"
        title="Install Tumba Notes as an offline application"
      >
        <Download className="w-3.5 h-3.5 text-[#B7B9BE] group-hover:scale-110 transition-transform" />
        <span className="truncate">Install TUMBA App</span>
      </button>
    );
  }

  // iOS Safari flow
  if (isIOS) {
    return (
      <>
        <button
          onClick={() => setShowIOSGuide(true)}
          className="flex items-center gap-2 w-full px-3 py-2 text-xs font-medium rounded-lg border border-[#303236] bg-[#202124] text-[#F1F1F1] hover:bg-[#26282C] transition group"
        >
          <Share className="w-3.5 h-3.5 text-[#B7B9BE]" />
          <span className="truncate">Install on iOS</span>
        </button>

        {showIOSGuide && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150">
            <div className="w-full max-w-sm bg-[#191A1D] border border-[#303236] rounded-xl shadow-2xl p-6 text-[#F1F1F1]">
              <div className="flex items-center justify-between pb-3 border-b border-[#303236] mb-4">
                <h3 className="text-sm font-semibold tracking-tight">Install on iOS / Safari</h3>
                <button
                  onClick={() => setShowIOSGuide(false)}
                  className="text-[#92959B] hover:text-[#F1F1F1] p-1"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-3 text-xs text-[#92959B] mb-5">
                <div className="flex items-start gap-2.5">
                  <div className="p-1.5 rounded bg-[#202124] text-[#F1F1F1] shrink-0">
                    <Share className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="font-semibold text-[#F1F1F1]">1. Tap Share</span>
                    <p className="mt-0.5">Press the Share icon in the bottom Safari toolbar.</p>
                  </div>
                </div>

                <div className="flex items-start gap-2.5">
                  <div className="p-1.5 rounded bg-[#202124] text-[#F1F1F1] shrink-0">
                    <PlusSquare className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="font-semibold text-[#F1F1F1]">2. Add to Home Screen</span>
                    <p className="mt-0.5">Scroll down and tap &quot;Add to Home Screen&quot; to enable full offline mode.</p>
                  </div>
                </div>
              </div>

              <button
                onClick={() => setShowIOSGuide(false)}
                className="w-full py-2 text-xs font-medium rounded-lg bg-[#202124] hover:bg-[#26282C] border border-[#303236] text-[#F1F1F1] transition"
              >
                Got it
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  return null;
};
