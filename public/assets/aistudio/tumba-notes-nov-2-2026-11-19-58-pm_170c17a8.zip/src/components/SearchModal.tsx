/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  Search,
  X,
  FileText,
  Star,
  Pin,
  Archive,
  Calendar,
  Filter,
  ArrowRight,
} from 'lucide-react';
import type { Note, Folder, Tag } from '../types';
import { stripHtml, formatDate } from '../utils/textUtils';

interface SearchModalProps {
  isOpen: boolean;
  notes: Note[];
  folders: Folder[];
  tags: Tag[];
  noteTagsMap: Record<string, string[]>; // noteId -> tagIds
  onSelectNote: (noteId: string) => void;
  onClose: () => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  notes,
  folders,
  tags,
  noteTagsMap,
  onSelectNote,
  onClose,
}) => {
  const [query, setQuery] = useState('');
  const [selectedFolder, setSelectedFolder] = useState<string>('all');
  const [selectedTag, setSelectedTag] = useState<string>('all');
  const [favoriteOnly, setFavoriteOnly] = useState(false);
  const [includeArchived, setIncludeArchived] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(0);

  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => {
        inputRef.current?.focus();
      }, 50);
      setSelectedIndex(0);
    }
  }, [isOpen]);

  const folderMap = useMemo(() => {
    const map = new Map<string, Folder>();
    folders.forEach((f) => map.set(f.id, f));
    return map;
  }, [folders]);

  const tagMap = useMemo(() => {
    const map = new Map<string, Tag>();
    tags.forEach((t) => map.set(t.id, t));
    return map;
  }, [tags]);

  const filteredNotes = useMemo(() => {
    const q = query.trim().toLowerCase();

    return notes.filter((note) => {
      // Exclude trashed notes from search
      if (note.inTrash) return false;

      // Archive filter
      if (!includeArchived && note.isArchived) return false;

      // Favorite filter
      if (favoriteOnly && !note.isFavorite) return false;

      // Folder filter
      if (selectedFolder !== 'all' && note.folderId !== selectedFolder) {
        return false;
      }

      // Tag filter
      if (selectedTag !== 'all') {
        const noteTagIds = noteTagsMap[note.id] || [];
        if (!noteTagIds.includes(selectedTag)) return false;
      }

      if (!q) return true;

      // Match title
      if (note.title.toLowerCase().includes(q)) return true;

      // Match content plain text
      const plainContent = stripHtml(note.content).toLowerCase();
      if (plainContent.includes(q)) return true;

      // Match folder name
      if (note.folderId) {
        const folder = folderMap.get(note.folderId);
        if (folder && folder.name.toLowerCase().includes(q)) return true;
      }

      // Match tag name
      const noteTagIds = noteTagsMap[note.id] || [];
      for (const tId of noteTagIds) {
        const tag = tagMap.get(tId);
        if (tag && tag.name.toLowerCase().includes(q)) return true;
      }

      return false;
    });
  }, [notes, query, selectedFolder, selectedTag, favoriteOnly, includeArchived, folderMap, tagMap, noteTagsMap]);

  // Keep selected index in bounds
  useEffect(() => {
    if (selectedIndex >= filteredNotes.length) {
      setSelectedIndex(Math.max(0, filteredNotes.length - 1));
    }
  }, [filteredNotes.length, selectedIndex]);

  // Keyboard navigation
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev + 1 < filteredNotes.length ? prev + 1 : prev));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev - 1 >= 0 ? prev - 1 : 0));
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (filteredNotes[selectedIndex]) {
        onSelectNote(filteredNotes[selectedIndex].id);
        onClose();
      }
    }
  };

  if (!isOpen) return null;

  // Highlight helper
  const highlightText = (text: string, highlight: string) => {
    if (!highlight.trim()) return text;
    const parts = text.split(new RegExp(`(${highlight.replace(/[-/\\^$*+?.()|[\]{}]/g, '\\$&')})`, 'gi'));
    return (
      <>
        {parts.map((part, i) =>
          part.toLowerCase() === highlight.toLowerCase() ? (
            <mark key={i} className="bg-[#B7B9BE]/30 text-[#F1F1F1] px-0.5 rounded font-medium">
              {part}
            </mark>
          ) : (
            part
          )
        )}
      </>
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-16 sm:pt-24 p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="w-full max-w-2xl bg-[#191A1D] border border-[#303236] rounded-xl shadow-2xl flex flex-col text-[#F1F1F1] max-h-[80vh] overflow-hidden">
        {/* Search Input Bar */}
        <div className="flex items-center gap-3 px-4 py-3.5 border-b border-[#303236]">
          <Search className="w-5 h-5 text-[#92959B] shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setSelectedIndex(0);
            }}
            onKeyDown={handleKeyDown}
            placeholder="Search notes, contents, folders, tags... (Use ↑↓ arrows to navigate, Enter to open)"
            className="w-full bg-transparent text-sm text-[#F1F1F1] placeholder-[#63666E] focus:outline-none"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="text-[#92959B] hover:text-[#F1F1F1] p-1"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <kbd className="hidden sm:inline-block px-1.5 py-0.5 text-[10px] bg-[#202124] border border-[#303236] rounded text-[#92959B]">
            ESC
          </kbd>
        </div>

        {/* Filter bar */}
        <div className="flex flex-wrap items-center gap-2 px-4 py-2 border-b border-[#303236] bg-[#161719] text-xs">
          <div className="flex items-center gap-1 text-[#92959B]">
            <Filter className="w-3.5 h-3.5" />
            <span>Filters:</span>
          </div>

          {/* Folder filter */}
          <select
            value={selectedFolder}
            onChange={(e) => setSelectedFolder(e.target.value)}
            className="bg-[#202124] border border-[#303236] rounded px-2 py-1 text-xs text-[#F1F1F1] focus:outline-none focus:border-[#B7B9BE]"
          >
            <option value="all">All Folders</option>
            {folders.map((f) => (
              <option key={f.id} value={f.id}>
                📁 {f.name}
              </option>
            ))}
          </select>

          {/* Tag filter */}
          <select
            value={selectedTag}
            onChange={(e) => setSelectedTag(e.target.value)}
            className="bg-[#202124] border border-[#303236] rounded px-2 py-1 text-xs text-[#F1F1F1] focus:outline-none focus:border-[#B7B9BE]"
          >
            <option value="all">All Tags</option>
            {tags.map((t) => (
              <option key={t.id} value={t.id}>
                #{t.name}
              </option>
            ))}
          </select>

          {/* Favorite toggle */}
          <button
            onClick={() => setFavoriteOnly(!favoriteOnly)}
            className={`flex items-center gap-1 px-2 py-1 rounded border text-xs transition ${
              favoriteOnly
                ? 'bg-[#202124] border-[#B7B9BE] text-[#F1F1F1]'
                : 'border-[#303236] text-[#92959B] hover:text-[#F1F1F1]'
            }`}
          >
            <Star className={`w-3 h-3 ${favoriteOnly ? 'fill-current' : ''}`} />
            <span>Favorites</span>
          </button>

          {/* Archived toggle */}
          <button
            onClick={() => setIncludeArchived(!includeArchived)}
            className={`flex items-center gap-1 px-2 py-1 rounded border text-xs transition ${
              includeArchived
                ? 'bg-[#202124] border-[#B7B9BE] text-[#F1F1F1]'
                : 'border-[#303236] text-[#92959B] hover:text-[#F1F1F1]'
            }`}
          >
            <Archive className="w-3 h-3" />
            <span>Archived</span>
          </button>

          <span className="ml-auto text-[#63666E]">
            {filteredNotes.length} result{filteredNotes.length === 1 ? '' : 's'}
          </span>
        </div>

        {/* Results List */}
        <div className="overflow-y-auto flex-1 divide-y divide-[#303236]">
          {filteredNotes.length === 0 ? (
            <div className="py-12 text-center text-[#92959B]">
              <Search className="w-8 h-8 mx-auto mb-2 opacity-40" />
              <p className="text-sm">No notes match your search criteria</p>
            </div>
          ) : (
            filteredNotes.map((note, index) => {
              const isSelected = index === selectedIndex;
              const folder = note.folderId ? folderMap.get(note.folderId) : null;
              const noteTagIds = noteTagsMap[note.id] || [];
              const plainSnippet = stripHtml(note.content).slice(0, 160);

              return (
                <div
                  key={note.id}
                  onClick={() => {
                    onSelectNote(note.id);
                    onClose();
                  }}
                  onMouseEnter={() => setSelectedIndex(index)}
                  className={`p-3.5 transition cursor-pointer flex items-start justify-between gap-4 ${
                    isSelected ? 'bg-[#202124]' : 'hover:bg-[#1C1D21]'
                  }`}
                >
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      {note.isPinned && <Pin className="w-3 h-3 text-[#B7B9BE] shrink-0 fill-current" />}
                      {note.isFavorite && <Star className="w-3 h-3 text-[#D4AF37] shrink-0 fill-current" />}
                      <h4 className="text-sm font-semibold text-[#F1F1F1] truncate">
                        {highlightText(note.title || 'Untitled Note', query)}
                      </h4>
                    </div>

                    <p className="text-xs text-[#92959B] line-clamp-2 leading-relaxed mb-2 font-mono">
                      {highlightText(plainSnippet, query) || '(Empty note)'}
                    </p>

                    <div className="flex flex-wrap items-center gap-2 text-[11px] text-[#92959B]">
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        {formatDate(note.updatedAt)}
                      </span>

                      {folder && (
                        <span className="px-1.5 py-0.5 rounded bg-[#161719] border border-[#303236] text-[#B7B9BE]">
                          📁 {folder.name}
                        </span>
                      )}

                      {noteTagIds.map((tId) => {
                        const tag = tagMap.get(tId);
                        if (!tag) return null;
                        return (
                          <span
                            key={tag.id}
                            className="px-1.5 py-0.5 rounded bg-[#161719] border border-[#303236] text-[#92959B]"
                          >
                            #{tag.name}
                          </span>
                        );
                      })}
                    </div>
                  </div>

                  <div className="self-center">
                    <ArrowRight className={`w-4 h-4 text-[#92959B] transition ${isSelected ? 'translate-x-1 text-[#F1F1F1]' : 'opacity-0'}`} />
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
