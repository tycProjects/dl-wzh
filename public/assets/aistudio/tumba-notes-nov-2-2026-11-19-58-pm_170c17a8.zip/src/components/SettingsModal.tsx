/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  X,
  Moon,
  Sun,
  Palette,
  HardDrive,
  Download,
  Upload,
  Trash2,
  Sliders,
  Type,
  Clock,
  ShieldCheck,
  Check,
  AlertTriangle,
} from 'lucide-react';
import type { AppSettings, BackupData } from '../types';
import { downloadAllDataBackup, validateBackupJson } from '../utils/exportUtils';
import { importDatabaseBackup, clearAllDatabase, db } from '../db/db';
import { ConfirmModal } from './ConfirmModal';

interface SettingsModalProps {
  isOpen: boolean;
  settings: AppSettings;
  onUpdateSetting: <K extends keyof AppSettings>(key: K, value: AppSettings[K]) => Promise<void>;
  onClose: () => void;
  onDataReset: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  settings,
  onUpdateSetting,
  onClose,
  onDataReset,
}) => {
  const [activeTab, setActiveTab] = useState<'appearance' | 'editor' | 'backup' | 'storage'>('appearance');
  const [storageEstimate, setStorageEstimate] = useState<{ usage: string; quota: string }>({
    usage: 'Calculating...',
    quota: 'Calculating...',
  });
  const [importStatus, setImportStatus] = useState<string | null>(null);
  const [importError, setImportError] = useState<string | null>(null);
  const [pendingBackupData, setPendingBackupData] = useState<BackupData | null>(null);
  const [importMode, setImportMode] = useState<'merge' | 'replace'>('merge');
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);

  // Storage usage calculation
  useEffect(() => {
    if (isOpen) {
      if (navigator.storage && navigator.storage.estimate) {
        navigator.storage.estimate().then((estimate) => {
          const usageMB = ((estimate.usage || 0) / (1024 * 1024)).toFixed(2);
          const quotaMB = ((estimate.quota || 0) / (1024 * 1024)).toFixed(1);
          setStorageEstimate({
            usage: `${usageMB} MB`,
            quota: `${quotaMB} MB`,
          });
        }).catch(() => {
          setStorageEstimate({ usage: 'Unavailable', quota: 'Unavailable' });
        });
      }
    }
  }, [isOpen]);

  if (!isOpen) return null;

  // Handle file select for JSON import
  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    setImportStatus(null);
    setImportError(null);
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        const backupData = validateBackupJson(text);
        setPendingBackupData(backupData);
      } catch (err: any) {
        setImportError(err?.message || 'Invalid JSON file.');
      }
    };
    reader.readAsText(file);
    // Reset input
    e.target.value = '';
  };

  // Perform import
  const executeImport = async () => {
    if (!pendingBackupData) return;
    try {
      setIsProcessing(true);
      const res = await importDatabaseBackup(pendingBackupData, importMode);
      setImportStatus(
        `Successfully imported ${res.importedNotes} notes, ${res.importedFolders} folders, ${res.importedTags} tags!`
      );
      setPendingBackupData(null);
      onDataReset();
    } catch (err: any) {
      setImportError(err?.message || 'Failed to import backup.');
    } finally {
      setIsProcessing(false);
    }
  };

  // Clear all database
  const handleConfirmClearAll = async () => {
    try {
      setIsProcessing(true);
      await clearAllDatabase();
      setShowClearConfirm(false);
      onDataReset();
      onClose();
    } catch (err: any) {
      alert('Failed to clear database: ' + err.message);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150">
        <div className="w-full max-w-2xl bg-[#191A1D] border border-[#303236] rounded-xl shadow-2xl flex flex-col text-[#F1F1F1] max-h-[88vh] overflow-hidden">
          {/* Header */}
          <div className="flex items-center justify-between px-6 py-4 border-b border-[#303236]">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-lg bg-[#202124] text-[#B7B9BE]">
                <Sliders className="w-4 h-4" />
              </div>
              <h3 className="text-base font-semibold tracking-tight">Settings &amp; Data</h3>
            </div>
            <button
              onClick={onClose}
              className="text-[#92959B] hover:text-[#F1F1F1] p-1 rounded-md transition"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Settings Tabs */}
          <div className="flex items-center gap-2 px-6 border-b border-[#303236] bg-[#161719] text-xs font-medium">
            <button
              onClick={() => setActiveTab('appearance')}
              className={`py-3 px-2 border-b-2 transition ${
                activeTab === 'appearance'
                  ? 'border-[#B7B9BE] text-[#F1F1F1]'
                  : 'border-transparent text-[#92959B] hover:text-[#F1F1F1]'
              }`}
            >
              Appearance
            </button>
            <button
              onClick={() => setActiveTab('editor')}
              className={`py-3 px-2 border-b-2 transition ${
                activeTab === 'editor'
                  ? 'border-[#B7B9BE] text-[#F1F1F1]'
                  : 'border-transparent text-[#92959B] hover:text-[#F1F1F1]'
              }`}
            >
              Editor &amp; Autosave
            </button>
            <button
              onClick={() => setActiveTab('backup')}
              className={`py-3 px-2 border-b-2 transition ${
                activeTab === 'backup'
                  ? 'border-[#B7B9BE] text-[#F1F1F1]'
                  : 'border-transparent text-[#92959B] hover:text-[#F1F1F1]'
              }`}
            >
              Backup &amp; Restore
            </button>
            <button
              onClick={() => setActiveTab('storage')}
              className={`py-3 px-2 border-b-2 transition ${
                activeTab === 'storage'
                  ? 'border-[#B7B9BE] text-[#F1F1F1]'
                  : 'border-transparent text-[#92959B] hover:text-[#F1F1F1]'
              }`}
            >
              Storage &amp; Reset
            </button>
          </div>

          {/* Tab Content */}
          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            {activeTab === 'appearance' && (
              <div className="space-y-6">
                {/* Theme Mode */}
                <div>
                  <label className="block text-xs font-semibold text-[#92959B] uppercase tracking-wider mb-2">
                    Graphite Theme
                  </label>
                  <div className="grid grid-cols-3 gap-3">
                    <button
                      onClick={() => onUpdateSetting('theme', 'dark')}
                      className={`p-3 rounded-lg border text-left transition flex items-center justify-between ${
                        settings.theme === 'dark'
                          ? 'border-[#B7B9BE] bg-[#202124]'
                          : 'border-[#303236] bg-[#161719] hover:bg-[#202124]'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <Moon className="w-4 h-4 text-[#B7B9BE]" />
                        <span className="text-xs font-medium">Obsidian (Dark)</span>
                      </div>
                      {settings.theme === 'dark' && <Check className="w-3.5 h-3.5 text-[#B7B9BE]" />}
                    </button>

                    <button
                      onClick={() => onUpdateSetting('theme', 'dim')}
                      className={`p-3 rounded-lg border text-left transition flex items-center justify-between ${
                        settings.theme === 'dim'
                          ? 'border-[#B7B9BE] bg-[#202124]'
                          : 'border-[#303236] bg-[#161719] hover:bg-[#202124]'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <Moon className="w-4 h-4 text-[#92959B]" />
                        <span className="text-xs font-medium">Slate (Dim)</span>
                      </div>
                      {settings.theme === 'dim' && <Check className="w-3.5 h-3.5 text-[#B7B9BE]" />}
                    </button>

                    <button
                      onClick={() => onUpdateSetting('theme', 'light')}
                      className={`p-3 rounded-lg border text-left transition flex items-center justify-between ${
                        settings.theme === 'light'
                          ? 'border-[#B7B9BE] bg-[#202124]'
                          : 'border-[#303236] bg-[#161719] hover:bg-[#202124]'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <Sun className="w-4 h-4 text-amber-400" />
                        <span className="text-xs font-medium">Paper (Light)</span>
                      </div>
                      {settings.theme === 'light' && <Check className="w-3.5 h-3.5 text-[#B7B9BE]" />}
                    </button>
                  </div>
                </div>

                {/* Accent Nuance */}
                <div>
                  <label className="block text-xs font-semibold text-[#92959B] uppercase tracking-wider mb-2">
                    Accent Hue Nuance
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                    {[
                      { key: 'silver', label: 'Silver', color: '#B7B9BE' },
                      { key: 'titanium', label: 'Titanium', color: '#9AA0A6' },
                      { key: 'platinum', label: 'Platinum', color: '#E5E5E7' },
                      { key: 'gold', label: 'Gold', color: '#D4AF37' },
                      { key: 'ice', label: 'Nordic Ice', color: '#93C5FD' },
                    ].map((acc) => {
                      const isSelected = settings.accent === acc.key;
                      return (
                        <button
                          key={acc.key}
                          onClick={() => onUpdateSetting('accent', acc.key as any)}
                          className={`p-2.5 rounded-lg border text-left text-xs font-medium transition flex items-center gap-2 ${
                            isSelected
                              ? 'border-[#B7B9BE] bg-[#202124]'
                              : 'border-[#303236] bg-[#161719] hover:bg-[#202124]'
                          }`}
                        >
                          <span
                            className="w-3 h-3 rounded-full shrink-0"
                            style={{ backgroundColor: acc.color }}
                          />
                          <span className="truncate">{acc.label}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Font Size & Compact Mode */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 border-t border-[#303236]">
                  <div>
                    <label className="block text-xs font-semibold text-[#92959B] uppercase tracking-wider mb-2">
                      Editor Font Size
                    </label>
                    <select
                      value={settings.fontSize}
                      onChange={(e) => onUpdateSetting('fontSize', e.target.value as any)}
                      className="w-full bg-[#202124] border border-[#303236] rounded-lg px-3 py-2 text-xs text-[#F1F1F1] focus:outline-none"
                    >
                      <option value="small">Small (14px)</option>
                      <option value="medium">Medium (16px — Default)</option>
                      <option value="large">Large (18px)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-[#92959B] uppercase tracking-wider mb-2">
                      Compact Card Mode
                    </label>
                    <button
                      onClick={() => onUpdateSetting('compactMode', !settings.compactMode)}
                      className={`w-full p-2 rounded-lg border text-xs font-medium transition flex items-center justify-between ${
                        settings.compactMode
                          ? 'border-[#B7B9BE] bg-[#202124] text-[#F1F1F1]'
                          : 'border-[#303236] bg-[#161719] text-[#92959B]'
                      }`}
                    >
                      <span>Compact Note Cards</span>
                      <span className="text-[10px] uppercase font-mono">
                        {settings.compactMode ? 'Enabled' : 'Disabled'}
                      </span>
                    </button>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'editor' && (
              <div className="space-y-6">
                <div>
                  <label className="block text-xs font-semibold text-[#92959B] uppercase tracking-wider mb-2">
                    Editor Typography Style
                  </label>
                  <div className="grid grid-cols-3 gap-3">
                    {[
                      { key: 'sans', label: 'System Sans', sample: 'Clean modern sans' },
                      { key: 'serif', label: 'Editorial Serif', sample: 'Classic reading serif' },
                      { key: 'mono', label: 'Developer Mono', sample: 'Strict code monospace' },
                    ].map((f) => (
                      <button
                        key={f.key}
                        onClick={() => onUpdateSetting('editorFontFamily', f.key as any)}
                        className={`p-3 rounded-lg border text-left transition ${
                          settings.editorFontFamily === f.key
                            ? 'border-[#B7B9BE] bg-[#202124]'
                            : 'border-[#303236] bg-[#161719] hover:bg-[#202124]'
                        }`}
                      >
                        <div className="text-xs font-medium text-[#F1F1F1]">{f.label}</div>
                        <div className="text-[10px] text-[#63666E] mt-0.5">{f.sample}</div>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="pt-4 border-t border-[#303236]">
                  <label className="block text-xs font-semibold text-[#92959B] uppercase tracking-wider mb-2">
                    Autosave Interval
                  </label>
                  <select
                    value={settings.autosaveIntervalMs}
                    onChange={(e) => onUpdateSetting('autosaveIntervalMs', Number(e.target.value))}
                    className="w-full bg-[#202124] border border-[#303236] rounded-lg px-3 py-2 text-xs text-[#F1F1F1] focus:outline-none"
                  >
                    <option value={400}>400ms (Immediate / Highly responsive)</option>
                    <option value={800}>800ms (Balanced — Recommended)</option>
                    <option value={1500}>1.5 seconds</option>
                    <option value={3000}>3 seconds</option>
                  </select>
                  <p className="text-[11px] text-[#63666E] mt-1.5">
                    Notes are automatically saved in the background into IndexedDB after typing stops.
                  </p>
                </div>

                <div className="pt-4 border-t border-[#303236]">
                  <label className="block text-xs font-semibold text-[#92959B] uppercase tracking-wider mb-2">
                    Default Sort Order
                  </label>
                  <select
                    value={settings.defaultSort}
                    onChange={(e) => onUpdateSetting('defaultSort', e.target.value as any)}
                    className="w-full bg-[#202124] border border-[#303236] rounded-lg px-3 py-2 text-xs text-[#F1F1F1] focus:outline-none"
                  >
                    <option value="updated-desc">Last Modified (Newest first)</option>
                    <option value="updated-asc">Last Modified (Oldest first)</option>
                    <option value="created-desc">Creation Date (Newest first)</option>
                    <option value="title-asc">Title (Alphabetical A-Z)</option>
                  </select>
                </div>
              </div>
            )}

            {activeTab === 'backup' && (
              <div className="space-y-6">
                <div>
                  <h4 className="text-xs font-semibold text-[#F1F1F1] mb-1">
                    Export Full JSON Backup
                  </h4>
                  <p className="text-xs text-[#92959B] mb-3 leading-relaxed">
                    Downloads an unencrypted JSON bundle containing all your notes, folder structures, tags, and settings.
                  </p>
                  <button
                    onClick={downloadAllDataBackup}
                    className="px-4 py-2 text-xs font-medium rounded-lg bg-[#202124] border border-[#303236] hover:border-[#B7B9BE] text-[#F1F1F1] transition flex items-center gap-2"
                  >
                    <Download className="w-3.5 h-3.5 text-[#B7B9BE]" />
                    <span>Download JSON Backup</span>
                  </button>
                </div>

                <div className="pt-4 border-t border-[#303236]">
                  <h4 className="text-xs font-semibold text-[#F1F1F1] mb-1">
                    Import &amp; Restore Backup
                  </h4>
                  <p className="text-xs text-[#92959B] mb-3 leading-relaxed">
                    Select a previously exported TUMBA NOTES JSON file to restore notes and folder structures.
                  </p>

                  <div className="flex items-center gap-3 mb-3">
                    <label className="px-4 py-2 text-xs font-medium rounded-lg bg-[#202124] border border-[#303236] hover:border-[#B7B9BE] text-[#F1F1F1] transition flex items-center gap-2 cursor-pointer">
                      <Upload className="w-3.5 h-3.5 text-[#B7B9BE]" />
                      <span>Select Backup File...</span>
                      <input
                        type="file"
                        accept=".json"
                        onChange={handleFileSelect}
                        className="hidden"
                      />
                    </label>
                  </div>

                  {importError && (
                    <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-lg text-xs text-red-400">
                      {importError}
                    </div>
                  )}

                  {importStatus && (
                    <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-lg text-xs text-emerald-400">
                      {importStatus}
                    </div>
                  )}

                  {pendingBackupData && (
                    <div className="p-4 bg-[#202124] border border-[#303236] rounded-xl space-y-3">
                      <div className="flex items-center justify-between text-xs font-semibold text-[#F1F1F1]">
                        <span>Backup Summary Detected:</span>
                        <span className="font-mono text-[#B7B9BE]">
                          {pendingBackupData.notes?.length || 0} notes,{' '}
                          {pendingBackupData.folders?.length || 0} folders
                        </span>
                      </div>

                      <div className="space-y-1 text-xs">
                        <label className="block text-[#92959B] mb-1">Conflict Resolution Mode:</label>
                        <div className="flex items-center gap-4">
                          <label className="flex items-center gap-1.5 cursor-pointer text-[#F1F1F1]">
                            <input
                              type="radio"
                              name="importMode"
                              checked={importMode === 'merge'}
                              onChange={() => setImportMode('merge')}
                              className="accent-[#B7B9BE]"
                            />
                            <span>Merge with existing data</span>
                          </label>

                          <label className="flex items-center gap-1.5 cursor-pointer text-[#F1F1F1]">
                            <input
                              type="radio"
                              name="importMode"
                              checked={importMode === 'replace'}
                              onChange={() => setImportMode('replace')}
                              className="accent-[#B7B9BE]"
                            />
                            <span>Replace entire database</span>
                          </label>
                        </div>
                      </div>

                      <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#303236]">
                        <button
                          onClick={() => setPendingBackupData(null)}
                          className="px-3 py-1.5 text-xs text-[#92959B] hover:text-[#F1F1F1]"
                        >
                          Cancel
                        </button>
                        <button
                          onClick={executeImport}
                          disabled={isProcessing}
                          className="px-4 py-1.5 text-xs font-medium rounded-lg bg-[#F1F1F1] text-[#111214] hover:bg-white"
                        >
                          {isProcessing ? 'Importing...' : 'Confirm Import'}
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {activeTab === 'storage' && (
              <div className="space-y-6">
                <div>
                  <h4 className="text-xs font-semibold text-[#92959B] uppercase tracking-wider mb-2">
                    IndexedDB Storage Footprint
                  </h4>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="p-3 rounded-lg bg-[#202124] border border-[#303236]">
                      <span className="text-[10px] text-[#92959B]">Current Usage</span>
                      <div className="text-lg font-bold font-mono text-[#F1F1F1]">
                        {storageEstimate.usage}
                      </div>
                    </div>
                    <div className="p-3 rounded-lg bg-[#202124] border border-[#303236]">
                      <span className="text-[10px] text-[#92959B]">Estimated Device Quota</span>
                      <div className="text-lg font-bold font-mono text-[#F1F1F1]">
                        {storageEstimate.quota}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="pt-4 border-t border-[#303236] space-y-3">
                  <div className="flex items-center gap-2 text-xs font-semibold text-red-400">
                    <AlertTriangle className="w-4 h-4" />
                    <span>Danger Zone</span>
                  </div>
                  <p className="text-xs text-[#92959B] leading-relaxed">
                    Permanently wipe all notes, folders, tags, and settings stored in this browser. This action cannot be reversed.
                  </p>
                  <button
                    onClick={() => setShowClearConfirm(true)}
                    className="px-4 py-2 text-xs font-medium rounded-lg bg-red-600/15 hover:bg-red-600 text-red-400 hover:text-white border border-red-500/30 transition flex items-center gap-2"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Clear All Data</span>
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Footer with Version & Close */}
          <div className="flex items-center justify-between px-6 py-3 border-t border-[#303236] bg-[#161719] text-xs text-[#63666E]">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-3.5 h-3.5 text-[#B7B9BE]" />
              <span>TUMBA NOTES v1.0.0 — Local First PWA</span>
            </div>
            <button
              onClick={onClose}
              className="px-4 py-1.5 text-xs font-medium rounded-lg bg-[#202124] border border-[#303236] text-[#F1F1F1] hover:bg-[#26282C] transition"
            >
              Done
            </button>
          </div>
        </div>
      </div>

      <ConfirmModal
        isOpen={showClearConfirm}
        title="Wipe All Database Data?"
        message="Are you completely sure you want to delete all notes, folders, tags, and settings? This operation permanently clears local IndexedDB storage and cannot be undone."
        confirmLabel="Yes, Clear Everything"
        cancelLabel="Cancel"
        isDestructive={true}
        onConfirm={handleConfirmClearAll}
        onCancel={() => setShowClearConfirm(false)}
      />
    </>
  );
};
