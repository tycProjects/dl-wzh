/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useMemo } from 'react';
import {
  Home,
  FileText,
  Star,
  Clock,
  Archive,
  Trash2,
  FolderPlus,
  Plus,
  Settings,
  Search,
  Tag as TagIcon,
  ChevronLeft,
  ChevronRight,
  X,
  Edit2,
} from 'lucide-react';
import type { Folder, Note, Tag, ViewSection } from '../types';
import { FolderTree } from './FolderTree';
import { PWAInstallButton } from './PWAInstallButton';
import { OfflineIndicator } from './OfflineIndicator';

interface SidebarProps {
  currentSection: ViewSection;
  selectedFolderId: string | null;
  selectedTagId: string | null;
  notes: Note[];
  folders: Folder[];
  tags: Tag[];
  noteTagsMap: Record<string, string[]>;
  isCollapsed: boolean;
  isMobileOpen: boolean;
  onToggleCollapse: () => void;
  onCloseMobile: () => void;
  onSelectSection: (section: ViewSection) => void;
  onSelectFolder: (folderId: string | null) => void;
  onSelectTag: (tagId: string | null) => void;
  onNewNote: () => void;
  onNewFolder: (parentId?: string | null) => void;
  onEditFolder: (folder: Folder) => void;
  onDeleteFolder: (folder: Folder) => void;
  onExportFolder: (folder: Folder) => void;
  onNewTag: () => void;
  onEditTag: (tag: Tag) => void;
  onDeleteTag: (tag: Tag) => void;
  onOpenSettings: () => void;
  onOpenSearch: () => void;
  onMoveNoteToFolder?: (noteId: string, folderId: string | null) => void;
  onMoveFolderToFolder?: (draggedFolderId: string, targetParentId: string | null) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentSection,
  selectedFolderId,
  selectedTagId,
  notes,
  folders,
  tags,
  noteTagsMap,
  isCollapsed,
  isMobileOpen,
  onToggleCollapse,
  onCloseMobile,
  onSelectSection,
  onSelectFolder,
  onSelectTag,
  onNewNote,
  onNewFolder,
  onEditFolder,
  onDeleteFolder,
  onExportFolder,
  onNewTag,
  onEditTag,
  onDeleteTag,
  onOpenSettings,
  onOpenSearch,
  onMoveNoteToFolder,
  onMoveFolderToFolder,
}) => {
  // Compute section counts
  const counts = useMemo(() => {
    let all = 0;
    let favorites = 0;
    let recent = 0;
    let archive = 0;
    let trash = 0;
    const now = Date.now();
    const oneWeekAgo = now - 7 * 24 * 60 * 60 * 1000;

    notes.forEach((note) => {
      if (note.inTrash) {
        trash++;
      } else if (note.isArchived) {
        archive++;
      } else {
        all++;
        if (note.isFavorite) favorites++;
        if (note.updatedAt >= oneWeekAgo) recent++;
      }
    });

    return { all, favorites, recent, archive, trash };
  }, [notes]);

  // Compute tag note counts
  const tagNoteCounts = useMemo(() => {
    const map: Record<string, number> = {};
    Object.values(noteTagsMap).forEach((tIds) => {
      tIds.forEach((tId) => {
        map[tId] = (map[tId] || 0) + 1;
      });
    });
    return map;
  }, [noteTagsMap]);

  const navItems = [
    { id: 'home', label: 'Home', icon: Home, count: null },
    { id: 'all', label: 'All Notes', icon: FileText, count: counts.all },
    { id: 'favorites', label: 'Favorites', icon: Star, count: counts.favorites },
    { id: 'recent', label: 'Recent Notes', icon: Clock, count: counts.recent },
    { id: 'archive', label: 'Archive', icon: Archive, count: counts.archive },
    { id: 'trash', label: 'Trash', icon: Trash2, count: counts.trash },
  ];

  const sidebarContent = (
    <div className="flex flex-col h-full bg-[#161719] border-r border-[#303236] text-[#F1F1F1] select-none">
      {/* Top Header: Logo + Collapse */}
      <div className="flex items-center justify-between px-4 py-3.5 border-b border-[#303236]">
        <div
          onClick={() => {
            onSelectSection('home');
            onCloseMobile();
          }}
          className="flex items-center gap-2.5 cursor-pointer group"
        >
          <div className="w-7 h-7 rounded-lg bg-[#202124] border border-[#303236] flex items-center justify-center font-bold text-xs text-[#F1F1F1] tracking-tighter group-hover:border-[#B7B9BE] transition">
            TN
          </div>
          <div className="flex flex-col">
            <span className="text-xs font-bold tracking-wider text-[#F1F1F1]">
              TUMBA NOTES
            </span>
            <span className="text-[9px] text-[#92959B] tracking-tight -mt-0.5">
              Graphite Local-First
            </span>
          </div>
        </div>

        <div className="flex items-center gap-1">
          {/* Mobile close button */}
          <button
            onClick={onCloseMobile}
            className="md:hidden p-1 rounded-md text-[#92959B] hover:text-[#F1F1F1]"
          >
            <X className="w-4 h-4" />
          </button>
          {/* Desktop collapse toggle */}
          <button
            onClick={onToggleCollapse}
            className="hidden md:flex p-1 rounded-md text-[#92959B] hover:text-[#F1F1F1] hover:bg-[#202124] transition"
            title="Collapse sidebar"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Action buttons: New Note & Quick Search */}
      <div className="p-3 space-y-2 border-b border-[#303236]">
        <button
          onClick={() => {
            onNewNote();
            onCloseMobile();
          }}
          className="w-full flex items-center justify-center gap-2 px-3 py-2 text-xs font-semibold rounded-lg bg-[#F1F1F1] hover:bg-white text-[#111214] transition shadow-xs active:scale-[0.99]"
        >
          <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
          <span>New Note</span>
          <kbd className="hidden sm:inline-block ml-auto text-[9px] bg-[#E0E0E2] text-[#333] px-1 py-0.5 rounded font-mono">
            ⌘N
          </kbd>
        </button>

        <button
          onClick={onOpenSearch}
          className="w-full flex items-center gap-2 px-3 py-1.5 text-xs text-[#92959B] bg-[#202124] hover:bg-[#26282C] border border-[#303236] rounded-lg transition"
        >
          <Search className="w-3.5 h-3.5 text-[#92959B]" />
          <span className="flex-1 text-left">Quick Search...</span>
          <kbd className="text-[10px] bg-[#161719] px-1.5 py-0.5 rounded border border-[#303236] font-mono text-[#63666E]">
            ⌘K
          </kbd>
        </button>
      </div>

      {/* Scrollable navigation area */}
      <div className="flex-1 overflow-y-auto px-2 py-3 space-y-4">
        {/* Core Navigation Items */}
        <div className="space-y-0.5">
          {navItems.map((item) => {
            const isSelected =
              currentSection === item.id && !selectedFolderId && !selectedTagId;
            const Icon = item.icon;

            return (
              <button
                key={item.id}
                onClick={() => {
                  onSelectSection(item.id as ViewSection);
                  onCloseMobile();
                }}
                className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs font-medium transition ${
                  isSelected
                    ? 'bg-[#202124] text-[#F1F1F1] border-l-2 border-[#B7B9BE]'
                    : 'text-[#92959B] hover:bg-[#1E2024] hover:text-[#F1F1F1]'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Icon
                    className={`w-3.5 h-3.5 ${
                      isSelected ? 'text-[#F1F1F1]' : 'text-[#92959B]'
                    } ${item.id === 'favorites' && isSelected ? 'fill-current text-[#D4AF37]' : ''}`}
                  />
                  <span>{item.label}</span>
                </div>
                {item.count !== null && (
                  <span className="text-[10px] text-[#63666E] font-mono px-1">
                    {item.count}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Folders Section */}
        <div className="pt-2 border-t border-[#303236]/60">
          <div className="flex items-center justify-between px-2.5 mb-1.5">
            <span className="text-[10px] font-semibold text-[#63666E] uppercase tracking-wider">
              Folders ({folders.length})
            </span>
            <button
              onClick={() => onNewFolder(null)}
              className="p-1 text-[#92959B] hover:text-[#F1F1F1] hover:bg-[#202124] rounded transition"
              title="Create new root folder (Ctrl+Shift+N)"
            >
              <FolderPlus className="w-3.5 h-3.5" />
            </button>
          </div>

          <FolderTree
            folders={folders}
            notes={notes}
            selectedFolderId={selectedFolderId}
            onSelectFolder={(fId) => {
              onSelectFolder(fId);
              onCloseMobile();
            }}
            onCreateSubfolder={onNewFolder}
            onEditFolder={onEditFolder}
            onDeleteFolder={onDeleteFolder}
            onExportFolder={onExportFolder}
            onMoveNoteToFolder={onMoveNoteToFolder}
            onMoveFolderToFolder={onMoveFolderToFolder}
          />
        </div>

        {/* Tags Section */}
        <div className="pt-2 border-t border-[#303236]/60">
          <div className="flex items-center justify-between px-2.5 mb-1.5">
            <span className="text-[10px] font-semibold text-[#63666E] uppercase tracking-wider">
              Tags ({tags.length})
            </span>
            <button
              onClick={onNewTag}
              className="p-1 text-[#92959B] hover:text-[#F1F1F1] hover:bg-[#202124] rounded transition"
              title="Create new tag"
            >
              <Plus className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-0.5">
            {tags.length === 0 ? (
              <div className="px-3 py-1.5 text-xs text-[#63666E] italic">
                No tags created yet.
              </div>
            ) : (
              tags.map((tag) => {
                const isSelected = selectedTagId === tag.id;
                const count = tagNoteCounts[tag.id] || 0;

                return (
                  <div
                    key={tag.id}
                    onClick={() => {
                      onSelectTag(tag.id);
                      onCloseMobile();
                    }}
                    className={`group flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs font-medium cursor-pointer transition ${
                      isSelected
                        ? 'bg-[#202124] text-[#F1F1F1] border-l-2 border-[#B7B9BE]'
                        : 'text-[#92959B] hover:bg-[#1E2024] hover:text-[#F1F1F1]'
                    }`}
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <span
                        className="w-2 h-2 rounded-full shrink-0"
                        style={{ backgroundColor: tag.color || '#B7B9BE' }}
                      />
                      <span className="truncate">#{tag.name}</span>
                    </div>

                    <div className="flex items-center gap-1">
                      <span className="text-[10px] text-[#63666E] font-mono px-1">
                        {count}
                      </span>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onEditTag(tag);
                        }}
                        className="p-0.5 opacity-0 group-hover:opacity-100 text-[#92959B] hover:text-[#F1F1F1] rounded"
                        title="Edit tag"
                      >
                        <Edit2 className="w-3 h-3" />
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onDeleteTag(tag);
                        }}
                        className="p-0.5 opacity-0 group-hover:opacity-100 text-red-400 hover:text-red-300 rounded"
                        title="Delete tag"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>

      {/* Bottom Footer: PWA + Offline + Settings */}
      <div className="p-3 border-t border-[#303236] space-y-2 bg-[#141517]">
        <PWAInstallButton />
        <OfflineIndicator />

        <button
          onClick={() => {
            onOpenSettings();
            onCloseMobile();
          }}
          className="w-full flex items-center justify-between px-2.5 py-2 rounded-lg text-xs text-[#92959B] hover:bg-[#202124] hover:text-[#F1F1F1] transition"
        >
          <div className="flex items-center gap-2">
            <Settings className="w-3.5 h-3.5" />
            <span>Settings &amp; Backup</span>
          </div>
          <span className="text-[10px] font-mono text-[#63666E]">v1.0</span>
        </button>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Collapsible Sidebar */}
      <aside
        className={`hidden md:block h-full transition-all duration-200 z-20 shrink-0 ${
          isCollapsed ? 'w-14' : 'w-64 lg:w-72'
        }`}
      >
        {isCollapsed ? (
          <div className="flex flex-col items-center h-full bg-[#161719] border-r border-[#303236] py-3.5 px-2 justify-between">
            <div className="flex flex-col items-center gap-3">
              <button
                onClick={onToggleCollapse}
                className="w-8 h-8 rounded-lg bg-[#202124] border border-[#303236] flex items-center justify-center font-bold text-xs text-[#F1F1F1] hover:border-[#B7B9BE] transition"
                title="Expand sidebar"
              >
                TN
              </button>

              <button
                onClick={onNewNote}
                className="w-8 h-8 rounded-lg bg-[#F1F1F1] text-[#111214] flex items-center justify-center hover:bg-white transition"
                title="New Note"
              >
                <Plus className="w-4 h-4 stroke-[2.5]" />
              </button>

              <button
                onClick={onOpenSearch}
                className="p-2 rounded-lg text-[#92959B] hover:text-[#F1F1F1] hover:bg-[#202124] transition"
                title="Quick Search (Ctrl+K)"
              >
                <Search className="w-4 h-4" />
              </button>

              <button
                onClick={() => onSelectSection('home')}
                className={`p-2 rounded-lg transition ${
                  currentSection === 'home'
                    ? 'bg-[#202124] text-[#F1F1F1]'
                    : 'text-[#92959B] hover:text-[#F1F1F1]'
                }`}
                title="Home"
              >
                <Home className="w-4 h-4" />
              </button>

              <button
                onClick={() => onSelectSection('all')}
                className={`p-2 rounded-lg transition ${
                  currentSection === 'all'
                    ? 'bg-[#202124] text-[#F1F1F1]'
                    : 'text-[#92959B] hover:text-[#F1F1F1]'
                }`}
                title="All Notes"
              >
                <FileText className="w-4 h-4" />
              </button>

              <button
                onClick={() => onSelectSection('favorites')}
                className={`p-2 rounded-lg transition ${
                  currentSection === 'favorites'
                    ? 'bg-[#202124] text-[#F1F1F1]'
                    : 'text-[#92959B] hover:text-[#F1F1F1]'
                }`}
                title="Favorites"
              >
                <Star className="w-4 h-4" />
              </button>
            </div>

            <div className="flex flex-col items-center gap-2">
              <button
                onClick={onOpenSettings}
                className="p-2 rounded-lg text-[#92959B] hover:text-[#F1F1F1] hover:bg-[#202124] transition"
                title="Settings"
              >
                <Settings className="w-4 h-4" />
              </button>
              <button
                onClick={onToggleCollapse}
                className="p-1 rounded text-[#63666E] hover:text-[#F1F1F1]"
                title="Expand sidebar"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        ) : (
          sidebarContent
        )}
      </aside>

      {/* Mobile Slide-out Drawer */}
      {isMobileOpen && (
        <div className="md:hidden fixed inset-0 z-50 flex">
          <div
            onClick={onCloseMobile}
            className="fixed inset-0 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150"
          />
          <div className="relative w-72 max-w-[80vw] h-full shadow-2xl animate-in slide-in-from-left duration-200">
            {sidebarContent}
          </div>
        </div>
      )}
    </>
  );
};
