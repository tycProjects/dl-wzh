/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Tag as TagIcon, X, Check } from 'lucide-react';
import type { Tag } from '../types';

interface TagModalProps {
  isOpen: boolean;
  tagToEdit?: Tag | null;
  onSave: (tagData: { id?: string; name: string; color: string }) => Promise<void>;
  onClose: () => void;
}

const TAG_COLORS = [
  '#B7B9BE', // Light Graphite
  '#92959B', // Medium Gray
  '#6B6F7A', // Slate
  '#4A4D53', // Charcoal
  '#D4AF37', // Muted Gold
  '#93C5FD', // Ice Blue
  '#A7F3D0', // Sage
  '#FCA5A5', // Dusty Rose
];

export const TagModal: React.FC<TagModalProps> = ({
  isOpen,
  tagToEdit,
  onSave,
  onClose,
}) => {
  const [name, setName] = useState('');
  const [color, setColor] = useState('#B7B9BE');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (tagToEdit) {
      setName(tagToEdit.name);
      setColor(tagToEdit.color || '#B7B9BE');
    } else {
      setName('');
      setColor('#B7B9BE');
    }
    setError('');
  }, [tagToEdit, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const clean = name.trim().toLowerCase().replace(/\s+/g, '-');
    if (!clean) {
      setError('Tag name is required.');
      return;
    }

    try {
      setIsSubmitting(true);
      await onSave({
        id: tagToEdit?.id,
        name: clean,
        color,
      });
      onClose();
    } catch (err: any) {
      setError(err?.message || 'Failed to save tag.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="w-full max-w-sm bg-[#191A1D] border border-[#303236] rounded-xl shadow-2xl p-6 text-[#F1F1F1]">
        <div className="flex items-center justify-between pb-3 border-b border-[#303236] mb-4">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-[#202124] text-[#B7B9BE]">
              <TagIcon className="w-4 h-4" />
            </div>
            <h3 className="text-base font-semibold tracking-tight">
              {tagToEdit ? 'Edit Tag' : 'New Tag'}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="text-[#92959B] hover:text-[#F1F1F1] p-1 rounded-md transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {error && (
          <div className="mb-4 p-2.5 bg-red-500/10 border border-red-500/30 rounded-lg text-xs text-red-400">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-[#92959B] mb-1.5 uppercase tracking-wider">
              Tag Name
            </label>
            <input
              type="text"
              required
              autoFocus
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. priority, project-x"
              className="w-full px-3 py-2 text-sm bg-[#202124] border border-[#303236] rounded-lg text-[#F1F1F1] placeholder-[#63666E] focus:outline-none focus:border-[#B7B9BE] transition"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-[#92959B] mb-2 uppercase tracking-wider">
              Color
            </label>
            <div className="flex items-center gap-2">
              {TAG_COLORS.map((c) => {
                const isSelected = color === c;
                return (
                  <button
                    key={c}
                    type="button"
                    onClick={() => setColor(c)}
                    className="w-6 h-6 rounded-full flex items-center justify-center transition border-2"
                    style={{
                      backgroundColor: c,
                      borderColor: isSelected ? '#F1F1F1' : 'transparent',
                    }}
                  >
                    {isSelected && <Check className="w-3 h-3 text-[#111214]" />}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-[#303236]">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium rounded-lg border border-[#303236] bg-[#202124] text-[#F1F1F1] hover:bg-[#26282C] transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-4 py-2 text-xs font-medium rounded-lg bg-[#F1F1F1] hover:bg-white text-[#111214] transition disabled:opacity-50"
            >
              {isSubmitting ? 'Saving...' : tagToEdit ? 'Save Tag' : 'Create Tag'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
