/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import Dexie, { type Table } from 'dexie';
import type { Note, Folder, Tag, NoteTag, AppSettings, BackupData } from '../types';

export class TumbaDatabase extends Dexie {
  notes!: Table<Note, string>;
  folders!: Table<Folder, string>;
  tags!: Table<Tag, string>;
  noteTags!: Table<NoteTag, [string, string]>;
  settings!: Table<{ key: string; value: any }, string>;

  constructor() {
    super('TumbaNotesDB');
    this.version(1).stores({
      notes: 'id, folderId, isFavorite, isPinned, isArchived, inTrash, createdAt, updatedAt',
      folders: 'id, parentId, name, createdAt',
      tags: 'id, name',
      noteTags: '[noteId+tagId], noteId, tagId',
      settings: 'key',
    });
  }
}

export const db = new TumbaDatabase();

export const DEFAULT_SETTINGS: AppSettings = {
  theme: 'dark',
  accent: 'silver',
  compactMode: false,
  fontSize: 'medium',
  defaultSort: 'updated-desc',
  autosaveIntervalMs: 800,
  editorFontFamily: 'sans',
};

// Seed initial database if empty
export async function seedDatabaseIfEmpty(): Promise<void> {
  const noteCount = await db.notes.count();
  if (noteCount > 0) return;

  const now = Date.now();

  // Folders
  const rootPersonal: Folder = {
    id: 'f-personal',
    name: 'Personal',
    parentId: null,
    color: '#8E9096',
    icon: 'user',
    description: 'Personal journal, goals, and thoughts',
    createdAt: now - 1000000,
  };

  const fJournal: Folder = {
    id: 'f-journal',
    name: 'Daily Journal',
    parentId: 'f-personal',
    color: '#B7B9BE',
    icon: 'book-open',
    description: 'Reflections and logs',
    createdAt: now - 900000,
  };

  const fIdeas: Folder = {
    id: 'f-ideas',
    name: 'Ideas',
    parentId: 'f-personal',
    color: '#B7B9BE',
    icon: 'lightbulb',
    description: 'Concepts and creative sparks',
    createdAt: now - 850000,
  };

  const fGoals: Folder = {
    id: 'f-goals',
    name: 'Goals',
    parentId: 'f-personal',
    color: '#B7B9BE',
    icon: 'target',
    description: 'Long-term milestones',
    createdAt: now - 800000,
  };

  const rootProgramming: Folder = {
    id: 'f-programming',
    name: 'Programming',
    parentId: null,
    color: '#8E9096',
    icon: 'code',
    description: 'Engineering notes and snippets',
    createdAt: now - 750000,
  };

  const fWebDev: Folder = {
    id: 'f-webdev',
    name: 'Web Development',
    parentId: 'f-programming',
    color: '#B7B9BE',
    icon: 'globe',
    description: 'Frontend, backend, offline PWAs',
    createdAt: now - 700000,
  };

  const fProjects: Folder = {
    id: 'f-projects',
    name: 'Projects',
    parentId: 'f-programming',
    color: '#B7B9BE',
    icon: 'layers',
    description: 'Software project specs',
    createdAt: now - 650000,
  };

  const rootWork: Folder = {
    id: 'f-work',
    name: 'Work',
    parentId: null,
    color: '#8E9096',
    icon: 'briefcase',
    description: 'Professional tasks & meetings',
    createdAt: now - 600000,
  };

  await db.folders.bulkAdd([
    rootPersonal,
    fJournal,
    fIdeas,
    fGoals,
    rootProgramming,
    fWebDev,
    fProjects,
    rootWork,
  ]);

  // Tags
  const tags: Tag[] = [
    { id: 't-guide', name: 'Guide', color: '#B7B9BE' },
    { id: 't-productivity', name: 'Productivity', color: '#92959B' },
    { id: 't-engineering', name: 'Engineering', color: '#8E9096' },
    { id: 't-offline', name: 'Offline', color: '#B7B9BE' },
    { id: 't-checklist', name: 'Checklist', color: '#92959B' },
  ];
  await db.tags.bulkAdd(tags);

  // Notes
  const note1: Note = {
    id: 'note-welcome',
    title: 'Welcome to TUMBA NOTES',
    content: `<h2>Minimalist Graphite Productivity</h2>
<p>TUMBA NOTES is an uncompromising, local-first personal knowledge repository crafted with an ultra-clean monochrome aesthetic.</p>
<hr/>
<h3>Core Principles</h3>
<ul>
  <li><strong>100% Offline &amp; Private:</strong> All notes reside securely in your browser's IndexedDB. Zero servers, zero telemetry, zero cloud lock-in.</li>
  <li><strong>Instant &amp; Responsive:</strong> Millisecond search, instant note transitions, and background autosave.</li>
  <li><strong>Hierarchical Organization:</strong> Unlimited nested folders, multi-tag filtering, and quick pinning.</li>
</ul>
<br/>
<h3>Interactive Checklists</h3>
<ul class="checklist">
  <li><input type="checkbox" checked /> Install TUMBA NOTES as a desktop or mobile PWA</li>
  <li><input type="checkbox" checked /> Experience the Graphite monochrome palette</li>
  <li><input type="checkbox" /> Create your first custom nested folder</li>
  <li><input type="checkbox" /> Try full-screen focus writing mode</li>
  <li><input type="checkbox" /> Export a complete encrypted JSON backup in Settings</li>
</ul>
<br/>
<blockquote>"Simplicity is prerequisite for reliability." — Edsger W. Dijkstra</blockquote>
<br/>
<h3>Quick Keyboard Shortcuts</h3>
<table border="1" cellpadding="6" style="border-collapse: collapse; width: 100%; border-color: #303236;">
  <thead>
    <tr style="background: #191A1D; text-align: left;">
      <th style="padding: 8px; border: 1px solid #303236;">Shortcut</th>
      <th style="padding: 8px; border: 1px solid #303236;">Action</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="padding: 8px; border: 1px solid #303236;"><code>Ctrl / Cmd + N</code></td>
      <td style="padding: 8px; border: 1px solid #303236;">Create new note instantly</td>
    </tr>
    <tr>
      <td style="padding: 8px; border: 1px solid #303236;"><code>Ctrl / Cmd + Shift + N</code></td>
      <td style="padding: 8px; border: 1px solid #303236;">Create new folder</td>
    </tr>
    <tr>
      <td style="padding: 8px; border: 1px solid #303236;"><code>Ctrl / Cmd + K</code></td>
      <td style="padding: 8px; border: 1px solid #303236;">Global omni search dialog</td>
    </tr>
    <tr>
      <td style="padding: 8px; border: 1px solid #303236;"><code>Ctrl / Cmd + S</code></td>
      <td style="padding: 8px; border: 1px solid #303236;">Force immediate database save</td>
    </tr>
  </tbody>
</table>`,
    folderId: 'f-journal',
    isFavorite: true,
    isPinned: true,
    isArchived: false,
    inTrash: false,
    trashedAt: null,
    createdAt: now - 300000,
    updatedAt: now - 60000,
  };

  const note2: Note = {
    id: 'note-architecture',
    title: 'Offline Architecture & Local Data Safety',
    content: `<h2>Engineered for Permanence</h2>
<p>Unlike cloud note apps that charge subscriptions or suffer network outages, <strong>TUMBA NOTES</strong> is built around the modern <em>Local-First Software</em> paradigm.</p>
<pre><code>// Client-side transactional persistence via Dexie.js
await db.transaction('rw', db.notes, db.folders, async () => {
  await db.notes.put(note);
  await updateFolderNoteCount(note.folderId);
});</code></pre>
<p>Key architectural safeguards:</p>
<ol>
  <li><strong>Atomic Transactions:</strong> Saves and batch movements execute atomically.</li>
  <li><strong>Safe Soft Deletion:</strong> Deleting a note moves it to Trash first. Permanent deletion requires explicit user confirmation.</li>
  <li><strong>High-Fidelity JSON Backup:</strong> Export your entire database anytime with intact hierarchy, timestamps, and tag linkages.</li>
  <li><strong>Markdown &amp; TXT Exports:</strong> Single-click export of individual notes into clean Markdown.</li>
</ol>`,
    folderId: 'f-webdev',
    isFavorite: true,
    isPinned: false,
    isArchived: false,
    inTrash: false,
    trashedAt: null,
    createdAt: now - 250000,
    updatedAt: now - 120000,
  };

  const note3: Note = {
    id: 'note-sprint',
    title: 'Sprint Focus: Offline First Tooling',
    content: `<h2>Weekly Objectives &amp; Tasks</h2>
<p>Tracking the completion of high-priority milestones for local productivity.</p>
<ul class="checklist">
  <li><input type="checkbox" checked /> IndexedDB schema migration and validation</li>
  <li><input type="checkbox" checked /> Rich text formatting toolbar (H1-H3, bold, lists, quotes, code)</li>
  <li><input type="checkbox" checked /> PWA Service Worker caching &amp; install prompts</li>
  <li><input type="checkbox" /> Folder drag &amp; drop hierarchy reorganization</li>
  <li><input type="checkbox" /> Review backup file format against JSON schemas</li>
</ul>
<br/>
<p><mark>Note: Keep all client state strictly synchronized with IndexedDB on each keystroke debounce.</mark></p>`,
    folderId: 'f-projects',
    isFavorite: false,
    isPinned: false,
    isArchived: false,
    inTrash: false,
    trashedAt: null,
    createdAt: now - 180000,
    updatedAt: now - 45000,
  };

  await db.notes.bulkAdd([note1, note2, note3]);

  // NoteTags
  await db.noteTags.bulkAdd([
    { noteId: 'note-welcome', tagId: 't-guide' },
    { noteId: 'note-welcome', tagId: 't-productivity' },
    { noteId: 'note-welcome', tagId: 't-offline' },
    { noteId: 'note-architecture', tagId: 't-engineering' },
    { noteId: 'note-architecture', tagId: 't-offline' },
    { noteId: 'note-sprint', tagId: 't-checklist' },
    { noteId: 'note-sprint', tagId: 't-productivity' },
  ]);

  // Settings
  for (const [key, value] of Object.entries(DEFAULT_SETTINGS)) {
    await db.settings.put({ key, value });
  }
}

// Settings helper
export async function getSettings(): Promise<AppSettings> {
  const allSettings = await db.settings.toArray();
  const result: any = { ...DEFAULT_SETTINGS };
  for (const item of allSettings) {
    result[item.key] = item.value;
  }
  return result as AppSettings;
}

export async function saveSetting<K extends keyof AppSettings>(
  key: K,
  value: AppSettings[K]
): Promise<void> {
  await db.settings.put({ key, value });
}

// Database helper operations
export async function getTagsForNote(noteId: string): Promise<Tag[]> {
  const noteTags = await db.noteTags.where('noteId').equals(noteId).toArray();
  const tagIds = noteTags.map((nt) => nt.tagId);
  if (tagIds.length === 0) return [];
  return db.tags.where('id').anyOf(tagIds).toArray();
}

export async function setTagsForNote(noteId: string, tagIds: string[]): Promise<void> {
  await db.transaction('rw', db.noteTags, async () => {
    await db.noteTags.where('noteId').equals(noteId).delete();
    const records: NoteTag[] = tagIds.map((tagId) => ({ noteId, tagId }));
    if (records.length > 0) {
      await db.noteTags.bulkAdd(records);
    }
  });
}

// Deep folder hierarchy helpers
export async function getAllChildFolderIds(parentFolderId: string): Promise<string[]> {
  const allFolders = await db.folders.toArray();
  const childrenMap = new Map<string, string[]>();
  for (const f of allFolders) {
    if (f.parentId) {
      const list = childrenMap.get(f.parentId) || [];
      list.push(f.id);
      childrenMap.set(f.parentId, list);
    }
  }

  const result: string[] = [];
  const queue = [parentFolderId];
  while (queue.length > 0) {
    const current = queue.shift()!;
    const children = childrenMap.get(current) || [];
    for (const childId of children) {
      result.push(childId);
      queue.push(childId);
    }
  }
  return result;
}

// Backup & restore helpers
export async function exportDatabaseBackup(): Promise<BackupData> {
  const [notes, folders, tags, noteTags, settingsList] = await Promise.all([
    db.notes.toArray(),
    db.folders.toArray(),
    db.tags.toArray(),
    db.noteTags.toArray(),
    db.settings.toArray(),
  ]);

  const settingsObj: any = {};
  for (const item of settingsList) {
    settingsObj[item.key] = item.value;
  }

  return {
    version: '1.0.0',
    timestamp: Date.now(),
    notes,
    folders,
    tags,
    noteTags,
    settings: settingsObj,
  };
}

export async function importDatabaseBackup(
  data: BackupData,
  mode: 'replace' | 'merge' = 'merge'
): Promise<{ importedNotes: number; importedFolders: number; importedTags: number }> {
  if (!data || !Array.isArray(data.notes) || !Array.isArray(data.folders)) {
    throw new Error('Invalid backup file format: missing notes or folders collections.');
  }

  return db.transaction('rw', [db.notes, db.folders, db.tags, db.noteTags, db.settings], async () => {
    if (mode === 'replace') {
      await db.notes.clear();
      await db.folders.clear();
      await db.tags.clear();
      await db.noteTags.clear();
    }

    let importedNotes = 0;
    let importedFolders = 0;
    let importedTags = 0;

    for (const folder of data.folders) {
      await db.folders.put(folder);
      importedFolders++;
    }

    if (Array.isArray(data.tags)) {
      for (const tag of data.tags) {
        await db.tags.put(tag);
        importedTags++;
      }
    }

    for (const note of data.notes) {
      await db.notes.put(note);
      importedNotes++;
    }

    if (Array.isArray(data.noteTags)) {
      for (const nt of data.noteTags) {
        await db.noteTags.put(nt);
      }
    }

    if (data.settings && typeof data.settings === 'object') {
      for (const [key, value] of Object.entries(data.settings)) {
        await db.settings.put({ key, value });
      }
    }

    return { importedNotes, importedFolders, importedTags };
  });
}

// Clear all data
export async function clearAllDatabase(): Promise<void> {
  await db.transaction('rw', [db.notes, db.folders, db.tags, db.noteTags, db.settings], async () => {
    await db.notes.clear();
    await db.folders.clear();
    await db.tags.clear();
    await db.noteTags.clear();
    await db.settings.clear();
  });
}
