/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect } from 'react';

interface ShortcutHandlers {
  onNewNote?: () => void;
  onNewFolder?: () => void;
  onSearch?: () => void;
  onSave?: () => void;
  onEscape?: () => void;
}

export function useKeyboardShortcuts(handlers: ShortcutHandlers) {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const isMac = navigator.platform.toUpperCase().indexOf('MAC') >= 0;
      const mod = isMac ? e.metaKey : e.ctrlKey;

      // Escape key (always active to close modals/search)
      if (e.key === 'Escape') {
        if (handlers.onEscape) {
          handlers.onEscape();
        }
        return;
      }

      // Ctrl / Cmd + Shift + N: New folder
      if (mod && e.shiftKey && (e.key === 'N' || e.key === 'n')) {
        e.preventDefault();
        handlers.onNewFolder?.();
        return;
      }

      // Ctrl / Cmd + N: New note
      if (mod && !e.shiftKey && (e.key === 'n' || e.key === 'N')) {
        e.preventDefault();
        handlers.onNewNote?.();
        return;
      }

      // Ctrl / Cmd + K: Search
      if (mod && (e.key === 'k' || e.key === 'K')) {
        e.preventDefault();
        handlers.onSearch?.();
        return;
      }

      // Ctrl / Cmd + S: Force save
      if (mod && (e.key === 's' || e.key === 'S')) {
        e.preventDefault();
        handlers.onSave?.();
        return;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handlers]);
}
