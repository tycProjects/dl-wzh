/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Note {
  id: string;
  title: string;
  content: string; // HTML formatted string
  folderId: string | null;
  isFavorite: boolean;
  isPinned: boolean;
  isArchived: boolean;
  inTrash: boolean;
  trashedAt?: number | null;
  createdAt: number;
  updatedAt: number;
}

export interface Folder {
  id: string;
  name: string;
  parentId: string | null;
  color: string;
  icon: string;
  description: string;
  createdAt: number;
}

export interface Tag {
  id: string;
  name: string;
  color: string;
}

export interface NoteTag {
  id?: string;
  noteId: string;
  tagId: string;
}

export interface AppSettings {
  theme: 'dark' | 'dim' | 'light';
  accent: 'silver' | 'titanium' | 'platinum' | 'gold' | 'ice';
  compactMode: boolean;
  fontSize: 'small' | 'medium' | 'large';
  defaultSort: 'updated-desc' | 'updated-asc' | 'created-desc' | 'created-asc' | 'title-asc' | 'title-desc';
  autosaveIntervalMs: number;
  editorFontFamily: 'sans' | 'serif' | 'mono';
}

export type ViewSection = 
  | 'home' 
  | 'all' 
  | 'favorites' 
  | 'recent' 
  | 'archive' 
  | 'trash' 
  | 'folder' 
  | 'tag'
  | 'settings';

export interface SearchFilters {
  query: string;
  folderId: string | 'all';
  tagId: string | 'all';
  favoriteOnly: boolean;
  includeArchived: boolean;
  dateRange: 'all' | 'today' | 'week' | 'month' | 'year';
  sortBy: 'updated-desc' | 'updated-asc' | 'created-desc' | 'created-asc' | 'title-asc' | 'title-desc';
}

export interface BackupData {
  version: string;
  timestamp: number;
  notes: Note[];
  folders: Folder[];
  tags: Tag[];
  noteTags: NoteTag[];
  settings?: Partial<AppSettings>;
}
