/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import type { Note, Folder, BackupData } from '../types';
import { exportDatabaseBackup } from '../db/db';
import { htmlToMarkdown, stripHtml } from './textUtils';

export function downloadFile(filename: string, content: string, mimeType: string): void {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
  URL.revokeObjectURL(url);
}

export async function downloadAllDataBackup(): Promise<void> {
  const backup = await exportDatabaseBackup();
  const dateStr = new Date().toISOString().split('T')[0];
  const filename = `tumba-notes-backup-${dateStr}.json`;
  const jsonContent = JSON.stringify(backup, null, 2);
  downloadFile(filename, jsonContent, 'application/json');
}

export function downloadNoteAsMarkdown(note: Note, tags: string[] = [], folderName?: string): void {
  let header = '';
  if (folderName || tags.length > 0) {
    header += '---\n';
    if (folderName) header += `folder: "${folderName}"\n`;
    if (tags.length > 0) header += `tags: [${tags.map((t) => `"${t}"`).join(', ')}]\n`;
    header += `created: "${new Date(note.createdAt).toISOString()}"\n`;
    header += `updated: "${new Date(note.updatedAt).toISOString()}"\n`;
    header += '---\n\n';
  }

  const body = htmlToMarkdown(note.content, note.title);
  const cleanTitle = (note.title || 'untitled').replace(/[^a-z0-9-_]/gi, '_').toLowerCase();
  downloadFile(`${cleanTitle}.md`, header + body, 'text/markdown;charset=utf-8');
}

export function downloadNoteAsTxt(note: Note, tags: string[] = [], folderName?: string): void {
  let text = `${note.title || 'Untitled'}\n`;
  text += '='.repeat(note.title?.length || 8) + '\n\n';
  if (folderName) text += `Folder: ${folderName}\n`;
  if (tags.length > 0) text += `Tags: ${tags.join(', ')}\n`;
  text += `Last Modified: ${new Date(note.updatedAt).toLocaleString()}\n\n`;
  text += '-'.repeat(40) + '\n\n';
  text += stripHtml(note.content) + '\n';

  const cleanTitle = (note.title || 'untitled').replace(/[^a-z0-9-_]/gi, '_').toLowerCase();
  downloadFile(`${cleanTitle}.txt`, text, 'text/plain;charset=utf-8');
}

export function downloadFolderNotesAsBundle(
  folder: Folder,
  notes: Note[]
): void {
  let bundle = `# ${folder.name} — Folder Export\n`;
  if (folder.description) {
    bundle += `*${folder.description}*\n\n`;
  }
  bundle += `Total Notes: ${notes.length}\n`;
  bundle += `Exported: ${new Date().toLocaleString()}\n\n`;
  bundle += '='.repeat(60) + '\n\n';

  notes.forEach((note, index) => {
    bundle += `## ${index + 1}. ${note.title || 'Untitled'}\n`;
    bundle += `Created: ${new Date(note.createdAt).toLocaleString()} | Modified: ${new Date(note.updatedAt).toLocaleString()}\n\n`;
    bundle += htmlToMarkdown(note.content) + '\n\n';
    bundle += '-'.repeat(60) + '\n\n';
  });

  const cleanFolderName = folder.name.replace(/[^a-z0-9-_]/gi, '_').toLowerCase();
  downloadFile(`${cleanFolderName}-notes.md`, bundle, 'text/markdown;charset=utf-8');
}

export function validateBackupJson(jsonString: string): BackupData {
  const parsed = JSON.parse(jsonString);
  if (!parsed || typeof parsed !== 'object') {
    throw new Error('File does not contain valid JSON object.');
  }

  if (!Array.isArray(parsed.notes)) {
    throw new Error('Invalid backup: Missing notes array.');
  }

  if (!Array.isArray(parsed.folders)) {
    throw new Error('Invalid backup: Missing folders array.');
  }

  return parsed as BackupData;
}
