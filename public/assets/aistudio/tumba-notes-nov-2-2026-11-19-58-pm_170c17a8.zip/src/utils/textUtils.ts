/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export function stripHtml(html: string): string {
  if (!html) return '';
  const doc = new DOMParser().parseFromString(html, 'text/html');
  return doc.body.textContent || '';
}

export function getWordCount(html: string): number {
  const text = stripHtml(html).trim();
  if (!text) return 0;
  return text.split(/\s+/).filter(Boolean).length;
}

export function getCharCount(html: string): number {
  return stripHtml(html).length;
}

export function getReadingTime(words: number): string {
  if (words <= 0) return '0 min';
  const minutes = Math.ceil(words / 200);
  return `${minutes} min read`;
}

export function formatDate(timestamp: number): string {
  if (!timestamp) return '';
  const date = new Date(timestamp);
  const now = new Date();
  
  const isToday =
    date.getDate() === now.getDate() &&
    date.getMonth() === now.getMonth() &&
    date.getFullYear() === now.getFullYear();

  if (isToday) {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  }

  const isCurrentYear = date.getFullYear() === now.getFullYear();
  if (isCurrentYear) {
    return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
  }

  return date.toLocaleDateString([], { year: 'numeric', month: 'short', day: 'numeric' });
}

export function formatFullDateTime(timestamp: number): string {
  if (!timestamp) return '';
  const date = new Date(timestamp);
  return date.toLocaleDateString([], {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

/**
 * Converts rich text HTML from the editor into clean, readable Markdown
 */
export function htmlToMarkdown(html: string, title?: string): string {
  if (!html) return title ? `# ${title}\n\n` : '';

  const div = document.createElement('div');
  div.innerHTML = html;

  function processNode(node: Node): string {
    if (node.nodeType === Node.TEXT_NODE) {
      return node.textContent || '';
    }

    if (node.nodeType !== Node.ELEMENT_NODE) {
      return '';
    }

    const el = node as HTMLElement;
    const tag = el.tagName.toLowerCase();

    // Check for interactive checklist item
    const checkbox = el.querySelector('input[type="checkbox"]') as HTMLInputElement | null;
    if (tag === 'li' && (checkbox || el.classList.contains('checklist-item'))) {
      const isChecked = checkbox ? checkbox.checked : el.getAttribute('data-checked') === 'true';
      // clone and remove input to avoid duplicate text
      const clone = el.cloneNode(true) as HTMLElement;
      const cb = clone.querySelector('input[type="checkbox"]');
      if (cb) cb.remove();
      return `- [${isChecked ? 'x' : ' '}] ${clone.textContent?.trim()}\n`;
    }

    const children = Array.from(el.childNodes).map(processNode).join('');

    switch (tag) {
      case 'h1':
        return `# ${children.trim()}\n\n`;
      case 'h2':
        return `## ${children.trim()}\n\n`;
      case 'h3':
        return `### ${children.trim()}\n\n`;
      case 'p':
        return `${children}\n\n`;
      case 'br':
        return '\n';
      case 'hr':
        return '---\n\n';
      case 'strong':
      case 'b':
        return `**${children}**`;
      case 'em':
      case 'i':
        return `*${children}*`;
      case 'u':
        return `<u>${children}</u>`;
      case 's':
      case 'strike':
      case 'del':
        return `~~${children}~~`;
      case 'mark':
        return `==${children}==`;
      case 'code':
        return el.parentElement?.tagName.toLowerCase() === 'pre'
          ? children
          : `\`${children}\``;
      case 'pre':
        return `\`\`\`\n${el.textContent || ''}\n\`\`\`\n\n`;
      case 'blockquote':
        return `> ${children.trim().replace(/\n/g, '\n> ')}\n\n`;
      case 'ul':
        return `${children}\n`;
      case 'ol': {
        const items = Array.from(el.children);
        return (
          items
            .map((item, idx) => `${idx + 1}. ${item.textContent?.trim() || ''}\n`)
            .join('') + '\n'
        );
      }
      case 'li':
        return `- ${children.trim()}\n`;
      case 'a':
        return `[${children}](${el.getAttribute('href') || ''})`;
      case 'table': {
        let mdTable = '\n';
        const rows = Array.from(el.querySelectorAll('tr'));
        rows.forEach((row, rowIndex) => {
          const cells = Array.from(row.querySelectorAll('th, td'));
          const rowText =
            '| ' + cells.map((c) => (c.textContent || '').trim()).join(' | ') + ' |\n';
          mdTable += rowText;
          if (rowIndex === 0) {
            mdTable +=
              '| ' + cells.map(() => '---').join(' | ') + ' |\n';
          }
        });
        return mdTable + '\n';
      }
      default:
        return children;
    }
  }

  let markdown = '';
  if (title) {
    markdown += `# ${title}\n\n`;
  }
  markdown += Array.from(div.childNodes).map(processNode).join('');
  // clean multiple blank lines
  return markdown.replace(/\n{3,}/g, '\n\n').trim();
}

/**
 * Escapes regex special characters
 */
export function escapeRegex(text: string): string {
  return text.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, '\\$&');
}
