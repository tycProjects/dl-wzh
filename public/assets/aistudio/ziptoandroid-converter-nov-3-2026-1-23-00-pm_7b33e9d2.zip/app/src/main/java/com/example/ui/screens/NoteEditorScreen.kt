package com.example.ui.screens

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.LocalTextSelectionColors
import androidx.compose.foundation.text.selection.TextSelectionColors
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.CheckBox
import androidx.compose.material.icons.filled.CheckBoxOutlineBlank
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FormatBold
import androidx.compose.material.icons.filled.FormatItalic
import androidx.compose.material.icons.filled.FormatListBulleted
import androidx.compose.material.icons.filled.FormatListNumbered
import androidx.compose.material.icons.filled.FormatQuote
import androidx.compose.material.icons.filled.FormatStrikethrough
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.HorizontalRule
import androidx.compose.material.icons.filled.Label
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Redo
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppSettings
import com.example.data.model.Attachment
import com.example.data.model.Folder
import com.example.data.model.Note
import com.example.data.model.NoteLink
import com.example.data.model.NoteRevision
import com.example.data.model.Tag
import com.example.ui.theme.LocalTumbaColors
import com.example.ui.theme.LocalTumbaStrings
import com.example.utils.TextFormatUtils
import kotlin.math.max
import kotlin.math.min

@Composable
fun NoteEditorScreen(
    note: Note?,
    folders: List<Folder>,
    tags: List<Tag>,
    allNotes: List<Note> = emptyList(),
    noteTagIds: List<String>,
    attachments: List<Attachment> = emptyList(),
    revisions: List<NoteRevision> = emptyList(),
    incomingLinks: List<NoteLink> = emptyList(),
    outgoingLinks: List<NoteLink> = emptyList(),
    settings: AppSettings,
    saveStatus: String,
    onBack: () -> Unit,
    onSaveNote: (Note) -> Unit,
    onUpdateNoteTags: (String, List<String>) -> Unit,
    onToggleFavorite: (String) -> Unit,
    onTogglePin: (String) -> Unit,
    onDuplicateNote: (Note) -> Unit,
    onArchiveNote: (String) -> Unit,
    onTrashNote: (String) -> Unit,
    onRestoreRevision: (NoteRevision) -> Unit = {},
    onAddAttachment: () -> Unit = {},
    onDeleteAttachment: (Attachment) -> Unit = {},
    onOpenLinkedNote: (String) -> Unit = {},
    modifier: Modifier = Modifier
) {
    BackHandler {
        onBack()
    }

    val context = LocalContext.current
    val colors = LocalTumbaColors.current
    val strings = LocalTumbaStrings.current

    if (note == null) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(colors.background),
            contentAlignment = Alignment.Center
        ) {
            Text(strings.noNoteSelected, color = colors.textSecondary)
        }
        return
    }

    var title by remember(note.id) { mutableStateOf(note.title) }
    var contentValue by remember(note.id) { mutableStateOf(TextFieldValue(note.content)) }
    var selectedFolderId by remember(note.id, note.folderId) { mutableStateOf(note.folderId) }

    // Undo / Redo history stack
    val undoStack = remember(note.id) { mutableListOf<TextFieldValue>() }
    val redoStack = remember(note.id) { mutableListOf<TextFieldValue>() }

    // Modes & Sheets
    var isFocusMode by remember { mutableStateOf(false) }
    var isReadingMode by remember { mutableStateOf(false) }
    var showFolderMenu by remember { mutableStateOf(false) }
    var showTagDialog by remember { mutableStateOf(false) }
    var showMoreMenu by remember { mutableStateOf(false) }
    var showRevisionsDialog by remember { mutableStateOf(false) }
    var showAttachmentsSheet by remember { mutableStateOf(false) }
    var showSlashCommands by remember { mutableStateOf(false) }
    var showLinkAutocomplete by remember { mutableStateOf(false) }

    val currentFolder = folders.find { it.id == selectedFolderId }
    val assignedTags = remember(noteTagIds, tags) {
        noteTagIds.mapNotNull { tId -> tags.find { it.id == tId } }
    }

    val wordCount = remember(contentValue.text) { TextFormatUtils.getWordCount(contentValue.text) }
    val charCount = remember(contentValue.text) { TextFormatUtils.getCharCount(contentValue.text) }
    val readingTime = remember(wordCount) { TextFormatUtils.getReadingTime(wordCount) }

    // Trigger save on change
    fun notifyContentChange(newVal: TextFieldValue, addToUndo: Boolean = true) {
        if (addToUndo && newVal.text != contentValue.text) {
            undoStack.add(contentValue)
            if (undoStack.size > 50) undoStack.removeAt(0)
            redoStack.clear()
        }
        contentValue = newVal

        // Check if slash command popup should open (typing '/' at start of a line)
        val textBefore = newVal.text.take(newVal.selection.start)
        val currentLine = textBefore.substringAfterLast('\n', textBefore)
        showSlashCommands = currentLine == "/"
        showLinkAutocomplete = currentLine.endsWith("[[") && !currentLine.endsWith("]]")

        val updatedNote = note.copy(
            title = title,
            content = newVal.text,
            folderId = selectedFolderId
        )
        onSaveNote(updatedNote)
    }

    fun applyUndo() {
        if (undoStack.isNotEmpty()) {
            val prev = undoStack.removeAt(undoStack.lastIndex)
            redoStack.add(contentValue)
            contentValue = prev
            val updated = note.copy(title = title, content = prev.text, folderId = selectedFolderId)
            onSaveNote(updated)
        }
    }

    fun applyRedo() {
        if (redoStack.isNotEmpty()) {
            val next = redoStack.removeAt(redoStack.lastIndex)
            undoStack.add(contentValue)
            contentValue = next
            val updated = note.copy(title = title, content = next.text, folderId = selectedFolderId)
            onSaveNote(updated)
        }
    }

    fun insertTextAtCursor(insert: String, cursorOffset: Int = insert.length) {
        val currentText = contentValue.text
        val selStart = min(contentValue.selection.start, contentValue.selection.end)
        val selEnd = max(contentValue.selection.start, contentValue.selection.end)
        val newText = currentText.substring(0, selStart) + insert + currentText.substring(selEnd)
        val newCursor = selStart + cursorOffset
        notifyContentChange(TextFieldValue(newText, TextRange(newCursor)))
    }

    fun wrapSelection(prefix: String, suffix: String = prefix) {
        val currentText = contentValue.text
        val selStart = min(contentValue.selection.start, contentValue.selection.end)
        val selEnd = max(contentValue.selection.start, contentValue.selection.end)
        if (selStart == selEnd) {
            insertTextAtCursor(prefix + suffix, prefix.length)
        } else {
            val selected = currentText.substring(selStart, selEnd)
            val replacement = prefix + selected + suffix
            val newText = currentText.substring(0, selStart) + replacement + currentText.substring(selEnd)
            notifyContentChange(TextFieldValue(newText, TextRange(selStart + replacement.length)))
        }
    }

    fun insertAtLineStart(prefix: String) {
        val currentText = contentValue.text
        val selStart = contentValue.selection.start
        val lineStart = currentText.lastIndexOf('\n', (selStart - 1).coerceAtLeast(0)).let { if (it == -1) 0 else it + 1 }
        val newText = currentText.substring(0, lineStart) + prefix + currentText.substring(lineStart)
        notifyContentChange(TextFieldValue(newText, TextRange(selStart + prefix.length)))
    }

    // Execute slash command
    fun executeSlashCommand(commandType: String) {
        showSlashCommands = false
        val currentText = contentValue.text
        val selStart = contentValue.selection.start
        val lineStart = currentText.lastIndexOf('\n', (selStart - 1).coerceAtLeast(0)).let { if (it == -1) 0 else it + 1 }
        // Replace the "/" on current line
        val beforeLine = currentText.substring(0, lineStart)
        val afterCursor = currentText.substring(selStart)

        val snippet = when (commandType) {
            "h1" -> "# "
            "h2" -> "## "
            "h3" -> "### "
            "bullet" -> "• "
            "numbered" -> "1. "
            "todo" -> "[ ] "
            "quote" -> "> "
            "code" -> "```kotlin\n\n```\n"
            "divider" -> "---\n"
            "table" -> "| Column 1 | Column 2 |\n|---|---|\n| Item 1 | Item 2 |\n"
            "link" -> "[["
            else -> ""
        }
        val newText = beforeLine + snippet + afterCursor
        notifyContentChange(TextFieldValue(newText, TextRange(beforeLine.length + snippet.length)))
    }

    val selectionColors = TextSelectionColors(
        handleColor = colors.accent,
        backgroundColor = colors.accent.copy(alpha = 0.35f)
    )

    CompositionLocalProvider(LocalTextSelectionColors provides selectionColors) {
        Column(
            modifier = modifier
                .fillMaxSize()
                .background(colors.background)
        ) {
            // Top Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = colors.textPrimary
                    )
                }

                // Title or Autosave status indicator
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    val (statusText, statusColor) = when (saveStatus) {
                        "saving" -> Pair(strings.saving, colors.accent)
                        "unsaved" -> Pair(strings.unsaved, Color(0xFFE57373))
                        "error" -> Pair(strings.saveError, Color(0xFFE57373))
                        else -> Pair(strings.saved, colors.textSecondary)
                    }
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .background(statusColor, CircleShape)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = statusText,
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = statusColor,
                            fontWeight = FontWeight.Medium
                        )
                    )
                }

                // Favorite Toggle
                IconButton(onClick = { onToggleFavorite(note.id) }, modifier = Modifier.size(36.dp)) {
                    Icon(
                        if (note.isFavorite) Icons.Default.Star else Icons.Outlined.Star,
                        contentDescription = "Favorite",
                        tint = if (note.isFavorite) colors.accent else colors.textSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Focus Mode Toggle
                IconButton(onClick = { isFocusMode = !isFocusMode }, modifier = Modifier.size(36.dp)) {
                    Icon(
                        if (isFocusMode) Icons.Default.FullscreenExit else Icons.Default.Fullscreen,
                        contentDescription = strings.focusMode,
                        tint = if (isFocusMode) colors.accent else colors.textSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Reading Mode Toggle
                IconButton(onClick = { isReadingMode = !isReadingMode }, modifier = Modifier.size(36.dp)) {
                    Icon(
                        if (isReadingMode) Icons.Default.Edit else Icons.Default.MenuBook,
                        contentDescription = if (isReadingMode) strings.editMode else strings.readingMode,
                        tint = if (isReadingMode) colors.accent else colors.textSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Revisions History
                IconButton(onClick = { showRevisionsDialog = true }, modifier = Modifier.size(36.dp)) {
                    Icon(
                        Icons.Default.History,
                        contentDescription = strings.historyRevisions,
                        tint = colors.textSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Attachments
                IconButton(onClick = { showAttachmentsSheet = true }, modifier = Modifier.size(36.dp)) {
                    Icon(
                        Icons.Default.AttachFile,
                        contentDescription = strings.attachments,
                        tint = if (attachments.isNotEmpty()) colors.accent else colors.textSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                }

                // More Menu
                Box {
                    IconButton(onClick = { showMoreMenu = true }, modifier = Modifier.size(36.dp)) {
                        Icon(
                            Icons.Default.MoreVert,
                            contentDescription = "More",
                            tint = colors.textSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    DropdownMenu(
                        expanded = showMoreMenu,
                        onDismissRequest = { showMoreMenu = false },
                        modifier = Modifier.background(colors.panelBackground)
                    ) {
                        DropdownMenuItem(
                            text = { Text(strings.exportMarkdown, color = colors.textPrimary) },
                            leadingIcon = { Icon(Icons.Default.Description, contentDescription = null, tint = colors.accent) },
                            onClick = {
                                showMoreMenu = false
                                val md = TextFormatUtils.exportAsMarkdown(note, currentFolder?.name, assignedTags.map { it.name })
                                val sendIntent = Intent().apply {
                                    action = Intent.ACTION_SEND
                                    putExtra(Intent.EXTRA_TEXT, md)
                                    type = "text/plain"
                                }
                                context.startActivity(Intent.createChooser(sendIntent, "Export Markdown"))
                            }
                        )
                        DropdownMenuItem(
                            text = { Text(strings.shareNoteText, color = colors.textPrimary) },
                            leadingIcon = { Icon(Icons.Default.Share, contentDescription = null, tint = colors.accent) },
                            onClick = {
                                showMoreMenu = false
                                val sendIntent = Intent().apply {
                                    action = Intent.ACTION_SEND
                                    putExtra(Intent.EXTRA_TEXT, "${note.title}\n\n${note.content}")
                                    type = "text/plain"
                                }
                                context.startActivity(Intent.createChooser(sendIntent, "Share Note"))
                            }
                        )
                        DropdownMenuItem(
                            text = { Text(strings.duplicateNote, color = colors.textPrimary) },
                            leadingIcon = { Icon(Icons.Default.ContentCopy, contentDescription = null, tint = colors.accent) },
                            onClick = {
                                showMoreMenu = false
                                onDuplicateNote(note)
                            }
                        )
                        DropdownMenuItem(
                            text = { Text(strings.archiveNote, color = colors.textPrimary) },
                            leadingIcon = { Icon(Icons.Default.Archive, contentDescription = null, tint = colors.accent) },
                            onClick = {
                                showMoreMenu = false
                                onArchiveNote(note.id)
                            }
                        )
                        HorizontalDivider(color = colors.border)
                        DropdownMenuItem(
                            text = { Text(strings.moveToTrash, color = Color(0xFFE57373)) },
                            leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = Color(0xFFE57373)) },
                            onClick = {
                                showMoreMenu = false
                                onTrashNote(note.id)
                            }
                        )
                    }
                }
            }

            HorizontalDivider(color = colors.border.copy(alpha = 0.5f))

            // Sub-header with Folder and Tag badges (hidden in Focus mode)
            if (!isFocusMode) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Folder badge
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = colors.cardBackground,
                        border = androidx.compose.foundation.BorderStroke(1.dp, colors.border),
                        modifier = Modifier.clickable { showFolderMenu = true }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(Icons.Default.Folder, contentDescription = null, tint = colors.accent, modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = currentFolder?.name ?: strings.noFolder,
                                style = MaterialTheme.typography.labelSmall.copy(color = colors.textPrimary, fontSize = 11.sp)
                            )
                        }
                    }

                    // Assigned tags
                    assignedTags.forEach { tag ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = colors.panelBackground,
                            border = androidx.compose.foundation.BorderStroke(1.dp, colors.border)
                        ) {
                            Text(
                                text = "#${tag.name}",
                                style = MaterialTheme.typography.labelSmall.copy(color = colors.textSecondary, fontSize = 11.sp),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    // Add Tag Button
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = colors.cardBackground,
                        modifier = Modifier.clickable { showTagDialog = true }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, tint = colors.accent, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(2.dp))
                            Text(
                                text = strings.assignTags,
                                style = MaterialTheme.typography.labelSmall.copy(color = colors.accent, fontSize = 11.sp)
                            )
                        }
                    }
                }
            }

            // Main Editor / Reader Area
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                if (isReadingMode) {
                    // Rendered Reading Mode View
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(horizontal = 20.dp, vertical = 16.dp)
                    ) {
                        Text(
                            text = title.ifBlank { strings.untitledPlaceholder },
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = colors.textPrimary,
                                letterSpacing = (-0.5).sp
                            )
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        HorizontalDivider(color = colors.border)
                        Spacer(modifier = Modifier.height(14.dp))

                        // Render formatted Markdown paragraphs & interactive checkboxes
                        RenderedMarkdownContent(
                            content = contentValue.text,
                            colors = colors,
                            onToggleChecklist = { lineIdx ->
                                val toggled = TextFormatUtils.toggleChecklistLine(contentValue.text, lineIdx)
                                notifyContentChange(TextFieldValue(toggled, TextRange(toggled.length)))
                            },
                            onLinkClick = { targetTitle ->
                                onOpenLinkedNote(targetTitle)
                            }
                        )

                        // Outgoing & Incoming Links at end of Reading Mode
                        if (outgoingLinks.isNotEmpty() || incomingLinks.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(24.dp))
                            HorizontalDivider(color = colors.border)
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = strings.internalLinks.uppercase(),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = colors.textSecondary,
                                    letterSpacing = 0.5.sp
                                )
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            val allLinkedNoteIds = (outgoingLinks.map { it.targetNoteId } + incomingLinks.map { it.sourceNoteId }).distinct()
                            allLinkedNoteIds.forEach { linkedId ->
                                val targetNote = allNotes.find { it.id == linkedId }
                                if (targetNote != null) {
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = colors.cardBackground,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 3.dp)
                                            .clickable { onOpenLinkedNote(targetNote.title) }
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(10.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(Icons.Default.Link, contentDescription = null, tint = colors.accent, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(targetNote.title, color = colors.textPrimary, style = MaterialTheme.typography.bodyMedium)
                                        }
                                    }
                                }
                            }
                        }
                    }
                } else {
                    // Active Writing Mode
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(horizontal = 20.dp, vertical = 14.dp)
                    ) {
                        // Title Field
                        BasicTextField(
                            value = title,
                            onValueChange = { newTitle ->
                                title = newTitle
                                val updated = note.copy(title = newTitle, content = contentValue.text, folderId = selectedFolderId)
                                onSaveNote(updated)
                            },
                            textStyle = TextStyle(
                                color = colors.textPrimary,
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Bold,
                                lineHeight = 30.sp
                            ),
                            cursorBrush = SolidColor(colors.accent),
                            singleLine = true,
                            decorationBox = { innerTextField ->
                                if (title.isEmpty()) {
                                    Text(
                                        text = strings.untitledPlaceholder,
                                        style = TextStyle(
                                            color = colors.textSecondary.copy(alpha = 0.5f),
                                            fontSize = 24.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                }
                                innerTextField()
                            },
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // Body Field
                        val bodyFontSize = when (settings.fontSize) {
                            "small" -> 14.sp
                            "large" -> 18.sp
                            else -> 16.sp
                        }
                        val bodyFontFamily = when (settings.editorFontFamily) {
                            "serif" -> FontFamily.Serif
                            "mono" -> FontFamily.Monospace
                            else -> FontFamily.SansSerif
                        }

                        BasicTextField(
                            value = contentValue,
                            onValueChange = { newVal ->
                                notifyContentChange(newVal)
                            },
                            textStyle = TextStyle(
                                color = colors.textPrimary,
                                fontSize = bodyFontSize,
                                fontFamily = bodyFontFamily,
                                lineHeight = (bodyFontSize.value * 1.5).sp
                            ),
                            cursorBrush = SolidColor(colors.accent),
                            decorationBox = { innerTextField ->
                                if (contentValue.text.isEmpty()) {
                                    Text(
                                        text = strings.editorPlaceholder,
                                        style = TextStyle(
                                            color = colors.textSecondary.copy(alpha = 0.5f),
                                            fontSize = bodyFontSize,
                                            lineHeight = (bodyFontSize.value * 1.5).sp
                                        )
                                    )
                                }
                                innerTextField()
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(600.dp)
                        )
                    }

                    // Slash Commands Palette Popup
                    if (showSlashCommands) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(start = 20.dp, bottom = 60.dp)
                        ) {
                            SlashCommandPalette(
                                colors = colors,
                                onSelect = { cmd -> executeSlashCommand(cmd) }
                            )
                        }
                    }

                    // Internal Link Autocomplete Popup
                    if (showLinkAutocomplete) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(start = 20.dp, bottom = 60.dp)
                        ) {
                            LinkAutocompletePalette(
                                notes = allNotes.filter { it.id != note.id },
                                colors = colors,
                                onSelect = { noteTitle ->
                                    showLinkAutocomplete = false
                                    insertTextAtCursor("$noteTitle]]")
                                }
                            )
                        }
                    }
                }
            }

            // Compact Formatting Toolbar (Always visible in editing mode)
            if (!isReadingMode) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(colors.panelBackground)
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { applyUndo() }, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Default.Undo, contentDescription = "Undo", tint = colors.textSecondary, modifier = Modifier.size(18.dp))
                    }
                    IconButton(onClick = { applyRedo() }, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Default.Redo, contentDescription = "Redo", tint = colors.textSecondary, modifier = Modifier.size(18.dp))
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    Box(modifier = Modifier.width(1.dp).height(20.dp).background(colors.border))
                    Spacer(modifier = Modifier.width(4.dp))

                    EditorToolbarButton(label = "H1") { insertAtLineStart("# ") }
                    EditorToolbarButton(label = "H2") { insertAtLineStart("## ") }
                    EditorToolbarButton(label = "H3") { insertAtLineStart("### ") }

                    IconButton(onClick = { wrapSelection("**") }, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Default.FormatBold, contentDescription = "Bold", tint = colors.textSecondary, modifier = Modifier.size(18.dp))
                    }
                    IconButton(onClick = { wrapSelection("*") }, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Default.FormatItalic, contentDescription = "Italic", tint = colors.textSecondary, modifier = Modifier.size(18.dp))
                    }
                    IconButton(onClick = { wrapSelection("~~") }, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Default.FormatStrikethrough, contentDescription = "Strike", tint = colors.textSecondary, modifier = Modifier.size(18.dp))
                    }
                    IconButton(onClick = { insertAtLineStart("[ ] ") }, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Default.CheckBox, contentDescription = "Checklist", tint = colors.accent, modifier = Modifier.size(18.dp))
                    }
                    IconButton(onClick = { insertAtLineStart("• ") }, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Default.FormatListBulleted, contentDescription = "Bullet List", tint = colors.textSecondary, modifier = Modifier.size(18.dp))
                    }
                    IconButton(onClick = { insertAtLineStart("1. ") }, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Default.FormatListNumbered, contentDescription = "Numbered List", tint = colors.textSecondary, modifier = Modifier.size(18.dp))
                    }
                    IconButton(onClick = { insertAtLineStart("> ") }, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Default.FormatQuote, contentDescription = "Quote", tint = colors.textSecondary, modifier = Modifier.size(18.dp))
                    }
                    IconButton(onClick = { wrapSelection("`") }, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Default.Code, contentDescription = "Code", tint = colors.textSecondary, modifier = Modifier.size(18.dp))
                    }
                    IconButton(onClick = { insertTextAtCursor("\n---\n") }, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Default.HorizontalRule, contentDescription = "Divider", tint = colors.textSecondary, modifier = Modifier.size(18.dp))
                    }
                    IconButton(onClick = { insertTextAtCursor("\n| Column 1 | Column 2 |\n|---|---|\n| Value 1 | Value 2 |\n") }, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Default.TableChart, contentDescription = "Table", tint = colors.textSecondary, modifier = Modifier.size(18.dp))
                    }
                    IconButton(onClick = { insertTextAtCursor("[[") }, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Default.Link, contentDescription = "Internal Link", tint = colors.accent, modifier = Modifier.size(18.dp))
                    }
                }
            }

            // Bottom Statistics & Word Count Bar (hidden in Focus mode)
            if (!isFocusMode) {
                HorizontalDivider(color = colors.border)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(colors.cardBackground)
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "$wordCount ${strings.words} • $charCount ${strings.chars} • $readingTime",
                        style = MaterialTheme.typography.labelSmall.copy(color = colors.textSecondary)
                    )
                    Text(
                        text = "${strings.modified} ${TextFormatUtils.formatDate(note.updatedAt)}",
                        style = MaterialTheme.typography.labelSmall.copy(color = colors.textSecondary.copy(alpha = 0.7f))
                    )
                }
            }
        }
    }

    // Revision History Dialog
    RevisionHistoryDialog(
        isOpen = showRevisionsDialog,
        note = note,
        revisions = revisions,
        onDismiss = { showRevisionsDialog = false },
        onRestoreRevision = onRestoreRevision
    )

    // Attachments Sheet
    AttachmentsSheet(
        isOpen = showAttachmentsSheet,
        attachments = attachments,
        onDismiss = { showAttachmentsSheet = false },
        onAddAttachment = onAddAttachment,
        onDeleteAttachment = onDeleteAttachment
    )

    // Folder selection dialog
    if (showFolderMenu) {
        AlertDialog(
            onDismissRequest = { showFolderMenu = false },
            title = { Text(strings.folders, color = colors.textPrimary) },
            text = {
                LazyColumn(modifier = Modifier.fillMaxWidth()) {
                    item {
                        Text(
                            text = strings.noFolder,
                            color = colors.accent,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedFolderId = null
                                    onSaveNote(note.copy(folderId = null))
                                    showFolderMenu = false
                                }
                                .padding(vertical = 10.dp)
                        )
                    }
                    items(folders, key = { it.id }) { f ->
                        Text(
                            text = f.name,
                            color = colors.textPrimary,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedFolderId = f.id
                                    onSaveNote(note.copy(folderId = f.id))
                                    showFolderMenu = false
                                }
                                .padding(vertical = 10.dp)
                        )
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showFolderMenu = false }) {
                    Text(strings.cancel, color = colors.textSecondary)
                }
            },
            containerColor = colors.panelBackground
        )
    }

    // Tag assignment dialog
    if (showTagDialog) {
        var currentTags by remember { mutableStateOf(noteTagIds.toSet()) }
        AlertDialog(
            onDismissRequest = { showTagDialog = false },
            title = { Text(strings.assignTags, color = colors.textPrimary) },
            text = {
                if (tags.isEmpty()) {
                    Text(strings.noTagsYet, color = colors.textSecondary)
                } else {
                    LazyColumn(modifier = Modifier.fillMaxWidth()) {
                        items(tags, key = { it.id }) { t ->
                            val isChecked = currentTags.contains(t.id)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        currentTags = if (isChecked) currentTags - t.id else currentTags + t.id
                                    }
                                    .padding(vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = isChecked,
                                    onCheckedChange = { chk ->
                                        currentTags = if (chk) currentTags + t.id else currentTags - t.id
                                    },
                                    colors = CheckboxDefaults.colors(
                                        checkedColor = colors.accent,
                                        uncheckedColor = colors.textSecondary
                                    )
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("#${t.name}", color = colors.textPrimary)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onUpdateNoteTags(note.id, currentTags.toList())
                        showTagDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = colors.accent, contentColor = colors.background)
                ) {
                    Text(strings.done)
                }
            },
            dismissButton = {
                TextButton(onClick = { showTagDialog = false }) {
                    Text(strings.cancel, color = colors.textSecondary)
                }
            },
            containerColor = colors.panelBackground
        )
    }
}

@Composable
fun EditorToolbarButton(
    label: String,
    onClick: () -> Unit
) {
    val colors = LocalTumbaColors.current
    Surface(
        shape = RoundedCornerShape(4.dp),
        color = colors.cardBackground,
        modifier = Modifier
            .padding(horizontal = 2.dp)
            .clickable { onClick() }
    ) {
        Text(
            text = label,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Bold,
                color = colors.textPrimary,
                fontSize = 11.sp
            )
        )
    }
}

@Composable
fun SlashCommandPalette(
    colors: com.example.ui.theme.TumbaColors,
    onSelect: (String) -> Unit
) {
    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = colors.cardBackground),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = SolidColor(colors.accent.copy(alpha = 0.5f))
        )
    ) {
        Column(modifier = Modifier.padding(6.dp).width(200.dp)) {
            val commands = listOf(
                Pair("h1", "Heading 1 (/h1)"),
                Pair("h2", "Heading 2 (/h2)"),
                Pair("todo", "Checklist (/todo)"),
                Pair("bullet", "Bullet List (/bullet)"),
                Pair("quote", "Quote (/quote)"),
                Pair("code", "Code Block (/code)"),
                Pair("table", "Table (/table)"),
                Pair("link", "Internal Link (/link)")
            )
            commands.forEach { (cmd, label) ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelect(cmd) }
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = label,
                        style = MaterialTheme.typography.bodySmall.copy(color = colors.textPrimary)
                    )
                }
            }
        }
    }
}

@Composable
fun LinkAutocompletePalette(
    notes: List<Note>,
    colors: com.example.ui.theme.TumbaColors,
    onSelect: (String) -> Unit
) {
    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = colors.cardBackground),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = SolidColor(colors.accent.copy(alpha = 0.5f))
        )
    ) {
        Column(modifier = Modifier.padding(6.dp).width(220.dp)) {
            Text(
                text = "LINK TO NOTE",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = colors.textSecondary,
                    fontSize = 10.sp
                ),
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
            )
            notes.take(6).forEach { note ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelect(note.title) }
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Link, contentDescription = null, tint = colors.accent, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = note.title.ifBlank { "Untitled Note" },
                        style = MaterialTheme.typography.bodySmall.copy(color = colors.textPrimary),
                        maxLines = 1,
                        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
fun RenderedMarkdownContent(
    content: String,
    colors: com.example.ui.theme.TumbaColors,
    onToggleChecklist: (Int) -> Unit,
    onLinkClick: (String) -> Unit
) {
    val lines = content.lines()
    var checklistCounter = 0

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        lines.forEach { line ->
            val trimmed = line.trimStart()
            when {
                trimmed.startsWith("### ") -> {
                    Text(
                        text = trimmed.removePrefix("### "),
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = colors.textPrimary
                        )
                    )
                }
                trimmed.startsWith("## ") -> {
                    Text(
                        text = trimmed.removePrefix("## "),
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = colors.textPrimary
                        )
                    )
                }
                trimmed.startsWith("# ") -> {
                    Text(
                        text = trimmed.removePrefix("# "),
                        style = MaterialTheme.typography.headlineSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = colors.textPrimary
                        )
                    )
                }
                trimmed.startsWith("[ ] ") || trimmed.startsWith("[x] ") -> {
                    val isChecked = trimmed.startsWith("[x] ")
                    val text = if (isChecked) trimmed.removePrefix("[x] ") else trimmed.removePrefix("[ ] ")
                    val currentIdx = checklistCounter++
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onToggleChecklist(currentIdx) }
                            .padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            if (isChecked) Icons.Default.CheckBox else Icons.Default.CheckBoxOutlineBlank,
                            contentDescription = null,
                            tint = if (isChecked) colors.accent else colors.textSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = text,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = if (isChecked) colors.textSecondary else colors.textPrimary,
                                textDecoration = if (isChecked) androidx.compose.ui.text.style.TextDecoration.LineThrough else null
                            )
                        )
                    }
                }
                trimmed.startsWith("> ") -> {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(colors.cardBackground, RoundedCornerShape(4.dp))
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Box(modifier = Modifier.width(3.dp).height(20.dp).background(colors.accent))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = trimmed.removePrefix("> "),
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                                color = colors.textSecondary
                            )
                        )
                    }
                }
                trimmed.startsWith("```") -> {
                    // Code block
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = colors.panelBackground,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = line,
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontFamily = FontFamily.Monospace,
                                color = colors.accent
                            ),
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                }
                trimmed == "---" -> {
                    HorizontalDivider(color = colors.border, modifier = Modifier.padding(vertical = 6.dp))
                }
                else -> {
                    // Check for internal links in regular paragraph
                    RenderParagraphWithLinks(text = line, colors = colors, onLinkClick = onLinkClick)
                }
            }
        }
    }
}

@Composable
fun RenderParagraphWithLinks(
    text: String,
    colors: com.example.ui.theme.TumbaColors,
    onLinkClick: (String) -> Unit
) {
    if (text.isBlank()) {
        Spacer(modifier = Modifier.height(4.dp))
        return
    }

    // Detect internal links [[Title]]
    val parts = mutableListOf<Pair<String, Boolean>>()
    val regex = Regex("\\[\\[([^\\]]+)\\]\\]")
    var lastIndex = 0

    regex.findAll(text).forEach { match ->
        if (match.range.first > lastIndex) {
            parts.add(Pair(text.substring(lastIndex, match.range.first), false))
        }
        parts.add(Pair(match.groupValues[1], true))
        lastIndex = match.range.last + 1
    }
    if (lastIndex < text.length) {
        parts.add(Pair(text.substring(lastIndex), false))
    }

    if (parts.any { it.second }) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            parts.forEach { (part, isLink) ->
                if (isLink) {
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = colors.accent.copy(alpha = 0.2f),
                        modifier = Modifier
                            .clickable { onLinkClick(part) }
                            .padding(horizontal = 2.dp)
                    ) {
                        Text(
                            text = part,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = colors.accent,
                                fontWeight = FontWeight.Bold,
                                textDecoration = androidx.compose.ui.text.style.TextDecoration.Underline
                            ),
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                        )
                    }
                } else {
                    Text(
                        text = part,
                        style = MaterialTheme.typography.bodyMedium.copy(color = colors.textPrimary)
                    )
                }
            }
        }
    } else {
        Text(
            text = text,
            style = MaterialTheme.typography.bodyMedium.copy(
                color = colors.textPrimary,
                lineHeight = 22.sp
            )
        )
    }
}
